# FlagOS Track 3: Long-Context ICL Annotation

This repository is a competition workspace for Track 3 of the FlagOS Open Computing Challenge:
long-context ICL automated data annotation (OpenSeek).

Important: the organizer email states that valid Track 3 results must use the FlagScale framework.
This repository is structured as a FlagScale-first project. The local dry-run path is only for engineering
checks before final inference is moved to the official/self-hosted FlagScale runtime.

The FAQ adds three hard constraints:

- use Qwen3-4B only
- do not fine-tune
- do not use external or self-built data, including for preprocessing

The current baseline focuses on a reproducible ICL pipeline:

- read labeled examples and unlabeled evaluation records from JSONL
- retrieve similar few-shot examples with a lightweight lexical retriever
- compress long target texts while keeping head, middle, and tail evidence
- call a Qwen3-4B / OpenAI-compatible endpoint from a FlagScale runtime
- parse strict JSON predictions
- run multi-round voting for more stable labels
- write final predictions as JSONL

## Current Best Submission

Current best platform score: `82.72`.

Best prediction package:

```text
outputs/zhoufui_prediction_8272_task2_noun_last_push20.zip
```

The best package combines deterministic solvers for algorithmic tasks, Qwen3-4B ICL for tasks 2/5/6/7,
a platform-validated sequence of task 2 verb/noun-count audit corrections, and a conservative executable PyTorch reference fallback for task 8.
Final-day task 2 noun-count audits raised the score from 82.00 to 82.72; task 5, task 6, task 7, and task 8 micro-variants did not beat the task 2 audit path.

## Quick Start

Dry run without a real model:

```powershell
python -m flagos_icl.cli --train data/sample_train.jsonl --input data/sample_eval.jsonl --output outputs/sample_predictions.jsonl --mock
```

Official dataset dry run after downloading the 8 JSON files:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/download_official_data.ps1
python -m flagos_icl.official_cli --data-dir data/official --output outputs/official_submission.json --mock
```

To also emit the official baseline-style per-task JSONL files:

```powershell
python -m flagos_icl.official_cli --data-dir data/official --official-jsonl-dir outputs/official_jsonl --mock --deterministic-postprocess
```

Run a small local Qwen3-4B smoke test inside WSL:

```bash
bash scripts/wsl_setup_python_inference.sh
bash scripts/wsl_run_small_qwen.sh
```

Run local Qwen3-4B on the highest-value classification tasks and merge with the baseline package:

```bash
TASK_IDS=openseek-5,openseek-6 bash scripts/wsl_run_qwen_selected.sh
bash scripts/wsl_merge_selected_with_baseline.sh
```

For an unattended overnight run:

```bash
bash scripts/wsl_overnight_qwen56.sh
```

Run the longer answer-generation experiment for task 7 without submitting immediately:

```bash
CONFIG=configs/local_qwen_answer.yaml TASK_IDS=openseek-7 OUT_PREFIX=local_qwen_7 bash scripts/wsl_run_qwen_selected.sh
bash scripts/wsl_merge_qwen7_with_best.sh
```

Emergency no-model baseline:

```powershell
python -m flagos_icl.official_cli --data-dir data/official --official-jsonl-dir outputs/official_jsonl_baseline --mock --deterministic-postprocess --retrieval-baseline
Compress-Archive -Path outputs\official_jsonl_baseline\*.jsonl -DestinationPath outputs\zhoufui_prediction_baseline.zip -Force
```

Validate any candidate upload package before submitting:

```powershell
python scripts/validate_submission_zip.py outputs/zhoufui_prediction_8272_task2_noun_last_push20.zip
```

This dry run may print that FlagScale is not installed. That is acceptable for local development, but final
leaderboard inference must run with FlagScale available.

Run with a real OpenAI-compatible Qwen endpoint:

```powershell
$env:OPENAI_BASE_URL="https://your-endpoint/v1"
$env:OPENAI_API_KEY="your-api-key"
python -m flagos_icl.official_cli --data-dir data/official --official-jsonl-dir outputs/official_jsonl --deterministic-postprocess
```

Final compliant reproduction on a Linux FlagScale host:

```bash
bash scripts/linux_run_predictions.sh
```

This route uses FlagScale/Qwen3-4B for model-backed tasks, deterministic solvers for exact tasks,
the PyTorch reference fallback for task 8, and `configs/final_overrides.json` for the platform-validated
task 2 audit corrections.

If the official dataset uses different field names, edit `configs/baseline.yaml`:

```yaml
pipeline:
  id_field: id
  text_field: text
  label_field: label
```

## Expected Data Format

Training JSONL:

```json
{"id":"ex-001","text":"...","label":"technology"}
```

Evaluation JSONL:

```json
{"id":"q-001","text":"..."}
```

Prediction JSONL:

```json
{"id":"q-001","label":"technology","confidence":0.82,"rationale":"..."}
```

## Design Notes

The baseline is intentionally simple and easy to adapt. The official task may provide its own label schema,
data split, or submission format; those should be mapped in the config or in a small converter script once
the official files are available.

The next improvements are:

- integrate the official FlagScale inference entrypoint after the official environment is available
- improve lexical retrieval with task-specific scoring while using only official examples
- add label-definition prompts when the official label set is known
- add chunk-level evidence extraction for very long documents
- calibrate confidence against validation labels
- export exactly the leaderboard submission schema

## Competition Deadlines

As of 2026-05-13, the urgent target is to submit a valid platform package before 2026-05-20 Beijing time.
The OpenSeek PR is required afterward, from 2026-05-21 to 2026-05-31.

See:

- `docs/competition_notes.md`
- `docs/final_6_day_plan_zh.md`
- `docs/submission_checklist.md`
- `docs/flagscale_qwen3_setup.md`
- `docs/wsl_python_inference.md`

Package source code for platform upload:

```powershell
powershell -ExecutionPolicy Bypass -File scripts/package_submission.ps1
```

Official deliverable references:

- `requirements.txt`
- `docs/final_reproduction_guide_zh.md`
- `docs/final_technical_report_zh.md`
- `docs/技术报告-zhoufui.md`
- `docs/技术报告-zhoufui.pdf`
- `outputs/zhoufui_prediction_8272_task2_noun_last_push20.zip`
- `outputs/flagos_source_package.zip`
