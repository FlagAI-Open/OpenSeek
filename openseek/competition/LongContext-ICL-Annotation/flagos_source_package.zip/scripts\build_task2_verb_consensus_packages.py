from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"
TASK2_DATA = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]
TASK2_FILE = "openseek-2-v1.jsonl"

CANDIDATES = [
    ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_cot_verbs_selected.zip",
    ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_strict_verbs_selected.zip",
]


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: str(json.loads(line)["prediction"]).strip()
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        }


def _read_rows(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _int_or_none(value: str) -> int | None:
    match = re.search(r"-?\d+", str(value))
    if not match:
        return None
    return int(match.group(0))


def _load_verb_ids() -> set[str]:
    data = json.loads(TASK2_DATA.read_text(encoding="utf-8"))
    return {
        str(item["id"])
        for item in data["test_samples"]
        if "count the number of verbs" in str(item["input"]).lower()
    }


def _write_zip(base_zip: Path, out_zip: Path, task2_rows: list[dict[str, str]]) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t2_verb_consensus_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in task2_rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _build_rows(base_rows: list[dict[str, str]], replacements: dict[str, str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in base_rows:
        sample_id = row["test_sample_id"]
        rows.append({"test_sample_id": sample_id, "prediction": replacements.get(sample_id, str(row["prediction"]))})
    return rows


def main() -> int:
    missing = [path for path in [BASE_ZIP, *CANDIDATES] if not path.exists()]
    if missing:
        print("Missing required files:")
        for path in missing:
            print(f"  {path}")
        print("\nRun first:")
        print("  cd /mnt/c/Users/Fe/Desktop/web3/FlagOS")
        print("  bash scripts/wsl_run_task2_now.sh")
        return 2

    verb_ids = _load_verb_ids()
    base_rows = _read_rows(BASE_ZIP, TASK2_FILE)
    base_task = {row["test_sample_id"]: str(row["prediction"]).strip() for row in base_rows}
    candidate_maps = [_read_task(path, TASK2_FILE) for path in CANDIDATES]

    agree_all: dict[str, str] = {}
    agree_delta1: dict[str, str] = {}

    for sample_id in sorted(verb_ids):
        base_int = _int_or_none(base_task.get(sample_id, ""))
        values = [_int_or_none(candidate.get(sample_id, "")) for candidate in candidate_maps]
        if base_int is None or any(value is None for value in values):
            continue
        assert values[0] is not None and values[1] is not None
        if values[0] != values[1]:
            continue
        candidate_int = values[0]
        if candidate_int == base_int:
            continue
        if not (0 <= candidate_int <= 6):
            continue
        if abs(candidate_int - base_int) > 2:
            continue
        agree_all[sample_id] = str(candidate_int)
        if abs(candidate_int - base_int) <= 1:
            agree_delta1[sample_id] = str(candidate_int)

    packages = {
        "safe_delta1": agree_delta1,
        "all_agree": agree_all,
    }

    for suffix, replacements in packages.items():
        out_zip = ROOT / "outputs" / f"zhoufui_prediction_task2_verb_consensus_{suffix}.zip"
        _write_zip(BASE_ZIP, out_zip, _build_rows(base_rows, replacements))
        print(f"{out_zip}: {len(replacements)} replacements")
        for sample_id, value in sorted(replacements.items())[:40]:
            print(f"  {sample_id}: {base_task[sample_id]} => {value}")
        subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)

    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_task2_verb_consensus_safe_delta1.zip")
    print("2. outputs\\zhoufui_prediction_task2_verb_consensus_all_agree.zip only if #1 improves")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
