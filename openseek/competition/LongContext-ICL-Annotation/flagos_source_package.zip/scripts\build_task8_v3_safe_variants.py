from __future__ import annotations

import argparse
import json
import re
import zipfile
from pathlib import Path


TASK8_FILE = "openseek-8-v1.jsonl"

BINOMIAL_SAFE = '''def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    and_result = torch.bitwise_and(input, other)
    trials = total_count.to(torch.float32) if torch.is_tensor(total_count) else torch.as_tensor(total_count, device=and_result.device, dtype=torch.float32)
    if logits is not None:
        dist = torch.distributions.Binomial(total_count=trials, logits=logits)
    else:
        p = probs
        if p is None:
            if and_result.dtype == torch.bool:
                p = and_result.to(torch.float32)
            else:
                p = and_result.to(torch.float32)
                max_value = torch.clamp(torch.max(torch.abs(p)), min=1.0)
                p = torch.clamp(p / max_value, 0.0, 1.0)
        dist = torch.distributions.Binomial(total_count=trials, probs=p)
    return dist.sample().to(and_result.dtype)'''


QR_SAFE = '''def fused_qr_solve(A, b):
    Q, R = torch.linalg.qr(A, mode='reduced')
    rhs = torch.matmul(Q.mT, b)
    return torch.linalg.solve_triangular(R, rhs, upper=True)'''


def _replace_function(code: str, name: str, replacement: str) -> str:
    pattern = re.compile(
        r"def " + re.escape(name) + r"\(.*?\n(?=\ndef |\nclass |\nif not hasattr|\nlinalg = |\n'''\s*$)",
        re.S,
    )
    updated, count = pattern.subn(replacement.rstrip() + "\n", code, count=1)
    if count != 1:
        raise ValueError(f"Could not replace {name}; replacements={count}")
    return updated


def _read_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
        return str(json.loads(line)["prediction"])


def _write_variant(base_zip: Path, out_zip: Path, code: str) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    if out_zip.exists():
        out_zip.unlink()
    with zipfile.ZipFile(base_zip) as source, zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as target:
        for name in sorted(item for item in source.namelist() if item.endswith(".jsonl")):
            if name != TASK8_FILE:
                target.writestr(name, source.read(name))
                continue
            rows = []
            for line in source.read(name).decode("utf-8-sig").splitlines():
                if not line.strip():
                    continue
                row = json.loads(line)
                row["prediction"] = code
                rows.append(row)
            payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows)
            target.writestr(name, payload.encode("utf-8"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build safer task8 v3 variants from the current best v2 package")
    parser.add_argument("--base", default="outputs/zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip")
    parser.add_argument("--out-binomial", default="outputs/zhoufui_prediction_task8_v3_binomial_only_safe.zip")
    parser.add_argument("--out-binomial-qr", default="outputs/zhoufui_prediction_task8_v3_binomial_qr_safe.zip")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    base_zip = Path(args.base)
    code = _read_code(base_zip)
    binomial_code = _replace_function(code, "bitwise_and_binomial", BINOMIAL_SAFE)
    qr_code = _replace_function(binomial_code, "fused_qr_solve", QR_SAFE)
    _write_variant(base_zip, Path(args.out_binomial), binomial_code)
    _write_variant(base_zip, Path(args.out_binomial_qr), qr_code)
    print(f"Wrote {args.out_binomial}")
    print(f"Wrote {args.out_binomial_qr}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
