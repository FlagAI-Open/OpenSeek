from __future__ import annotations

import argparse
import json
import re
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


TASK7 = "openseek-7-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]


def _norm(value: str) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"^(answer|output)\s*:\s*", "", text)
    text = re.sub(r"^(who|what|where|when|which)\s+(is|are|was|were)\s+", "", text)
    text = text.strip(" \t\r\n\"'.?!;:")
    text = re.sub(r"\s+", " ", text)
    return text


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: str(json.loads(line)["prediction"])
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        }


def _read_task_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _write_zip(base_zip: Path, out_zip: Path, task7_rows: list[dict[str, str]]) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_task7_consensus_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK7:
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in task7_rows).encode("utf-8")
            else:
                payload = _read_task_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _build_rows(base_task7: dict[str, str], replacements: dict[str, str]) -> list[dict[str, str]]:
    rows = []
    for sample_id, prediction in base_task7.items():
        rows.append({"test_sample_id": sample_id, "prediction": replacements.get(sample_id, prediction)})
    return rows


def _safe_answer(value: str) -> bool:
    text = _norm(value)
    if not text or text in {"unknown", "none", "n/a"}:
        return False
    if len(text) > 60:
        return False
    if re.search(r"[^a-z0-9 .,&'\"/\-()]", text):
        return False
    if len(text.split()) > 8:
        return False
    return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build task7 consensus packages from multiple candidate zips")
    parser.add_argument("--base", required=True, help="Current best full submission zip")
    parser.add_argument("--out-prefix", required=True, help="Output prefix, for example outputs/task7_consensus")
    parser.add_argument("candidates", nargs="+", help="Candidate full or selected zips containing openseek-7-v1.jsonl")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    base_zip = Path(args.base)
    out_prefix = Path(args.out_prefix)
    base_task7 = _read_task(base_zip, TASK7)
    candidate_tasks = [_read_task(Path(path), TASK7) for path in args.candidates]

    by_sample: dict[str, list[str]] = defaultdict(list)
    for task in candidate_tasks:
        for sample_id, prediction in task.items():
            by_sample[sample_id].append(prediction)

    consensus2: dict[str, str] = {}
    consensus3: dict[str, str] = {}
    base_suspicious: dict[str, str] = {}
    expansion: dict[str, str] = {}

    for sample_id, base_prediction in base_task7.items():
        options = [_norm(item) for item in by_sample.get(sample_id, []) if _safe_answer(item)]
        if not options:
            continue
        counts = Counter(options)
        answer, count = counts.most_common(1)[0]
        base_norm = _norm(base_prediction)
        if answer == base_norm:
            continue
        if count >= 2:
            consensus2[sample_id] = answer
        if count >= 3:
            consensus3[sample_id] = answer
        if count >= 2 and (len(base_norm) > 45 or re.search(r"[^a-z0-9 .,&'\"/\-()]", base_norm)):
            base_suspicious[sample_id] = answer
        base_tokens = base_norm.split()
        answer_tokens = answer.split()
        if (
            count >= 2
            and 1 <= len(base_tokens) <= 3
            and len(base_tokens) < len(answer_tokens) <= len(base_tokens) + 4
            and (answer_tokens[: len(base_tokens)] == base_tokens or answer_tokens[-len(base_tokens) :] == base_tokens)
        ):
            expansion[sample_id] = answer

    packages = {
        "consensus2": consensus2,
        "consensus3": consensus3,
        "base_suspicious": base_suspicious,
        "expansion": expansion,
    }
    for suffix, replacements in packages.items():
        out_zip = out_prefix.with_name(f"{out_prefix.name}_{suffix}.zip")
        _write_zip(base_zip, out_zip, _build_rows(base_task7, replacements))
        print(f"{out_zip}: {len(replacements)} replacements")
        for sample_id in sorted(replacements)[:30]:
            print(f"  {sample_id}: {base_task7[sample_id]} => {replacements[sample_id]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
