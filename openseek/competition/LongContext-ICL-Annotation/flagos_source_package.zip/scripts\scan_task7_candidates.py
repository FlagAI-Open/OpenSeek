from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path

from flagos_icl.official_data import load_official_task


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_verbconf_task8_torch_ref.zip"
TASK7_PATH = ROOT / "data" / "official" / "openseek-7_jeopardy_answer_generation_all.json"


def main() -> int:
    task = load_official_task(TASK7_PATH)
    with zipfile.ZipFile(BASE_ZIP) as archive:
        preds = {
            json.loads(line)["test_sample_id"]: json.loads(line)["prediction"]
            for line in archive.read("openseek-7-v1.jsonl").decode("utf-8-sig").splitlines()
            if line.strip()
        }
    flagged = []
    for record in task.test_samples:
        text = record.text.replace("\n", " ")
        lower_text = text.lower()
        pred = preds[record.record_id].strip()
        reasons = []
        if len(pred) > 45:
            reasons.append("long")
        if pred and pred in lower_text and len(pred.split()) >= 4:
            reasons.append("copied-long-clue-span")
        if re.search(r"[^a-z0-9 .,&'\"/\-()]", pred.lower()):
            reasons.append("non-ascii-or-symbol")
        if pred in {"unknown", "none", "n/a", ""}:
            reasons.append("empty-like")
        if reasons:
            flagged.append((record.record_id, ",".join(reasons), pred, text))

    print(f"flagged={len(flagged)}")
    for sample_id, reasons, pred, text in flagged:
        print(f"{sample_id}\t{reasons}\t{pred}\t{text[:260]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
