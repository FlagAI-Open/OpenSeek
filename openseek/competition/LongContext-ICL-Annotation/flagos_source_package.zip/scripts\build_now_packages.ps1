$ErrorActionPreference = "Stop"

Write-Host "Building task2 verb consensus packages..."
python scripts\build_task2_verb_consensus_packages.py

Write-Host ""
Write-Host "Building task7 extended consensus packages..."
python scripts\build_task7_extended_packages.py
