from __future__ import annotations

import json
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_verbconf_task8_torch_ref.zip"
V2_ZIP = ROOT / "outputs" / "zhoufui_prediction_task5_v2_mix.zip"
DIAG_PATH = ROOT / "outputs" / "local_qwen_5_v2_diagnostics.json"
OUT_DIR = ROOT / "outputs" / "official_jsonl_task5_v2_conservative"
OUT_ZIP = ROOT / "outputs" / "zhoufui_prediction_task5_v2_conservative_mix.zip"


SAD_TO_NOT_SAD_RATIONALE_MARKERS = (
    "not personal",
    "not expressing sadness",
    "not genuine sadness",
    "no clear sadness",
    "no clear distress",
    "not sadness",
    "not sad",
    "neutral",
    "positive",
    "joke",
    "sarcasm",
    "quote",
    "humor",
    "tv show",
    "plot",
    "sports update",
)

NOT_SAD_TO_SAD_TEXT_MARKERS = (
    "#sad",
    "condolence",
    "solemn",
    "stayed in bed",
    "cut me out",
    "you're no one to me",
    "i despair",
    "induce panic",
    "can not do it",
)

OVERTRIGGER_MARKERS = (
    "#dark",
    "#blues",
    "#lost",
    "gloomy truth",
    "doom and gloom",
    "dark of night",
)


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: json.loads(line)["prediction"]
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        }


def _read_diagnostics() -> dict[str, dict[str, object]]:
    blocks = json.loads(DIAG_PATH.read_text(encoding="utf-8"))
    for block in blocks:
        if block.get("task_id") == "openseek-5":
            return {item["test_sample_id"]: item for item in block["diagnostics"]}
    raise ValueError("openseek-5 diagnostics not found")


def _accept(base: str, candidate: str, diag: dict[str, object]) -> bool:
    if base == candidate:
        return False
    rationale = str(diag.get("rationale", "")).lower()
    prediction = str(diag.get("prediction", ""))
    textish = f"{rationale} {prediction}".lower()
    confidence = float(diag.get("confidence", 0.0) or 0.0)
    if confidence < 0.85:
        return False
    if any(marker in rationale for marker in OVERTRIGGER_MARKERS):
        return False
    if base == "Sad" and candidate == "Not sad":
        return any(marker in rationale for marker in SAD_TO_NOT_SAD_RATIONALE_MARKERS)
    if base == "Not sad" and candidate == "Sad":
        return any(marker in textish for marker in NOT_SAD_TO_SAD_TEXT_MARKERS)
    return False


def main() -> int:
    base_task5 = _read_task(BASE_ZIP, "openseek-5-v1.jsonl")
    v2_task5 = _read_task(V2_ZIP, "openseek-5-v1.jsonl")
    diagnostics = _read_diagnostics()
    accepted = {
        sample_id: candidate
        for sample_id, candidate in v2_task5.items()
        if sample_id in base_task5 and _accept(base_task5[sample_id], candidate, diagnostics.get(sample_id, {}))
    }

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE_ZIP) as source:
        for name in source.namelist():
            payload = source.read(name)
            if name == "openseek-5-v1.jsonl":
                rows = []
                for line in payload.decode("utf-8-sig").splitlines():
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    sample_id = row["test_sample_id"]
                    if sample_id in accepted:
                        row["prediction"] = accepted[sample_id]
                    rows.append(row)
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            (OUT_DIR / name).write_bytes(payload)

    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT_DIR.glob("*.jsonl")):
            archive.write(path, arcname=path.name)

    print(f"Wrote {OUT_ZIP}")
    print(f"Accepted task5 v2 replacements: {len(accepted)}")
    for sample_id in sorted(accepted):
        diag = diagnostics[sample_id]
        print(f"{sample_id}\t{base_task5[sample_id]}\t=>\t{accepted[sample_id]}\t{diag.get('rationale', '')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
