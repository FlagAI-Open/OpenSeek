from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_extension.zip"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

# Manual micro-extension v2 on top of the 81.42 package.
# Rule: when a caption already has an action participle and also contains a
# reduced passive/participle phrase like "filled/surrounded/decorated", official
# examples often count both verbal forms.
SAFE_SUBSET = {
    "openseek-2-3f9e9782b2254c789c253560b9bf851f": "2",  # ride + decorated
    "openseek-2-96b38cc1ada94446aa258ac016695f7f": "2",  # cutting + surrounded
}

FULL_SET = {
    **SAFE_SUBSET,
    "openseek-2-4832beb04403416ea03488651dab41d1": "2",  # sitting + surrounded
    "openseek-2-b643b8103f1a4127a8707bb354e1afd7": "2",  # standing + filled
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _write_package(out_zip: Path, replacements: dict[str, str]) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t2_manual_micro_v2_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in _read_task2_rows(BASE_ZIP):
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}: {len(replacements)} replacements")
    for sid, value in replacements.items():
        print(f"  {sid} => {value}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)


def main() -> int:
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v2_safe.zip", SAFE_SUBSET)
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v2_full.zip", FULL_SET)
    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_task2_manual_micro_v2_safe.zip")
    print("2. outputs\\zhoufui_prediction_task2_manual_micro_v2_full.zip only if #1 improves")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
