#!/usr/bin/env bash
set -euo pipefail

# Merge Qwen task 2 plus Qwen task 5/6 into the deterministic/baseline package.

BASELINE_DIR="${BASELINE_DIR:-outputs/official_jsonl_baseline}"
QWEN2_DIR="${QWEN2_DIR:-outputs/local_qwen_2_jsonl}"
QWEN56_DIR="${QWEN56_DIR:-outputs/local_qwen_56_jsonl}"
MERGED_DIR="${MERGED_DIR:-outputs/official_jsonl_qwen2_qwen56_mix}"
OUT_ZIP="${OUT_ZIP:-outputs/zhoufui_prediction_qwen2_qwen56_mix.zip}"

rm -rf "$MERGED_DIR"
mkdir -p "$MERGED_DIR"

cp "$BASELINE_DIR"/*.jsonl "$MERGED_DIR"/
cp "$QWEN56_DIR"/*.jsonl "$MERGED_DIR"/
cp "$QWEN2_DIR"/*.jsonl "$MERGED_DIR"/

rm -f "$OUT_ZIP"
cd "$MERGED_DIR"
zip -r "../$(basename "$OUT_ZIP")" ./*.jsonl
cd - >/dev/null

echo "Merged package: $OUT_ZIP"
ls -lh "$OUT_ZIP"
echo "Line counts:"
wc -l "$MERGED_DIR"/*.jsonl
