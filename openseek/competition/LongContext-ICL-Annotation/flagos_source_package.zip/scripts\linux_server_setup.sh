#!/usr/bin/env bash
set -euo pipefail

# Run this on a Linux GPU server with Docker + NVIDIA Container Toolkit installed.
# Recommended GPU for final run: A100 80GB or H100 80GB.

MODEL_DIR="${MODEL_DIR:-/nfs/Qwen3-4B}"
IMAGE="flagrelease-registry.cn-beijing.cr.aliyuncs.com/flagrelease/flagrelease:nv_vllm085_gemscbbf39"

echo "[1/4] Pulling FlagOS Nvidia image"
docker pull "${IMAGE}"

echo "[2/4] Preparing model directory: ${MODEL_DIR}"
mkdir -p "${MODEL_DIR}"

echo "[3/4] Downloading Qwen3-4B from ModelScope"
python3 -m pip install -U modelscope
modelscope download --model Qwen/Qwen3-4B --local_dir "${MODEL_DIR}"

echo "[4/4] Starting container"
docker rm -f flagos 2>/dev/null || true
docker run --rm --init --detach \
  --net=host --uts=host --ipc=host \
  --security-opt=seccomp=unconfined \
  --privileged=true \
  --ulimit stack=67108864 \
  --ulimit memlock=-1 \
  --ulimit nofile=1048576:1048576 \
  --shm-size=32G \
  -v /nfs:/nfs \
  --gpus all \
  --name flagos \
  "${IMAGE}" \
  sleep infinity

echo "Container is running. Enter with:"
echo "docker exec -it flagos bash"
echo "Then start service with:"
echo "flagscale serve qwen3"
