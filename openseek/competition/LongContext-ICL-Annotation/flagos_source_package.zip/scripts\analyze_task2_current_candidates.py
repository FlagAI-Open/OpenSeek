from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
CURRENT_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
COT_ZIP = ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_cot_verbs_selected.zip"
STRICT_ZIP = ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_strict_verbs_selected.zip"
TASK2_DATA = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"
TASK2_FILE = "openseek-2-v1.jsonl"


def read_task2(zip_path: Path) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: str(json.loads(line)["prediction"]).strip()
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        }


def int_or_none(value: str) -> int | None:
    match = re.search(r"-?\d+", str(value))
    return int(match.group(0)) if match else None


def main() -> int:
    current = read_task2(CURRENT_ZIP)
    cot = read_task2(COT_ZIP)
    strict = read_task2(STRICT_ZIP)
    data = json.loads(TASK2_DATA.read_text(encoding="utf-8"))
    inputs = {item["id"]: item["input"] for item in data["test_samples"]}

    agree_safe: list[tuple[str, int, int, str]] = []
    for sample_id, current_value in current.items():
        base = int_or_none(current_value)
        cot_value = int_or_none(cot.get(sample_id, ""))
        strict_value = int_or_none(strict.get(sample_id, ""))
        if base is None or cot_value is None or strict_value is None:
            continue
        if cot_value == strict_value and cot_value != base and 0 <= cot_value <= 6 and abs(cot_value - base) <= 1:
            text = inputs.get(sample_id, "").replace("\n", " ")
            agree_safe.append((sample_id, base, cot_value, text[:240]))

    print(f"agree_safe_vs_current: {len(agree_safe)}")
    for sample_id, base, candidate, preview in agree_safe:
        print(f"{sample_id}: {base} -> {candidate} | {preview}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
