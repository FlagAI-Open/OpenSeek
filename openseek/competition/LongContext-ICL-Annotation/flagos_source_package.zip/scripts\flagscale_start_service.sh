#!/usr/bin/env bash
set -euo pipefail

# Start the official FlagScale service for Qwen3-4B.
# Run this on the Linux GPU host after installing/cloning FlagScale and preparing llm_config.yaml.

FLAGSCALE_DIR="${FLAGSCALE_DIR:-$HOME/FlagScale}"
LLM_CONFIG_PATH="${LLM_CONFIG_PATH:-$(pwd)}"
LLM_CONFIG_NAME="${LLM_CONFIG_NAME:-llm_config}"
ACTION="${ACTION:-run}"

if [[ ! -f "${FLAGSCALE_DIR}/run.py" ]]; then
  echo "Cannot find FlagScale run.py at: ${FLAGSCALE_DIR}/run.py" >&2
  echo "Set FLAGSCALE_DIR to the cloned FlagScale repository." >&2
  exit 2
fi

if [[ ! -f "${LLM_CONFIG_PATH}/${LLM_CONFIG_NAME}.yaml" ]]; then
  echo "Cannot find config: ${LLM_CONFIG_PATH}/${LLM_CONFIG_NAME}.yaml" >&2
  echo "Create llm_config.yaml according to the official OpenSeek/FlagScale deployment docs." >&2
  exit 2
fi

echo "FlagScale dir: ${FLAGSCALE_DIR}"
echo "Config path: ${LLM_CONFIG_PATH}"
echo "Config name: ${LLM_CONFIG_NAME}"
echo "Action: ${ACTION}"

cd "${FLAGSCALE_DIR}"
python run.py --config-path "${LLM_CONFIG_PATH}" --config-name "${LLM_CONFIG_NAME}" action="${ACTION}"
