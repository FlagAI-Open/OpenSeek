from __future__ import annotations

import argparse
import shutil
import tempfile
import zipfile
from pathlib import Path


TASK_FILES = {str(index): f"openseek-{index}-v1.jsonl" for index in range(1, 9)}


def _read_jsonl_from_source(source: Path, task_file: str) -> bytes:
    if source.is_dir():
        path = source / task_file
        if not path.exists():
            raise FileNotFoundError(f"{path} does not exist")
        return path.read_bytes()
    with zipfile.ZipFile(source) as archive:
        try:
            return archive.read(task_file)
        except KeyError as exc:
            raise FileNotFoundError(f"{source} does not contain {task_file}") from exc


def _parse_replace(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("replacement must look like TASK=ZIP_OR_DIR, for example 7=outputs/run.zip")
    task, source = value.split("=", 1)
    task = task.strip().removeprefix("openseek-").removesuffix("-v1").removesuffix(".jsonl")
    if task not in TASK_FILES:
        raise argparse.ArgumentTypeError(f"unknown task {task}; expected 1..8")
    return task, Path(source.strip())


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Blend per-task JSONL files from multiple OpenSeek submission packages")
    parser.add_argument("--base", required=True, help="Base submission zip or JSONL directory")
    parser.add_argument("--out", required=True, help="Output zip path")
    parser.add_argument(
        "--replace",
        action="append",
        default=[],
        type=_parse_replace,
        help="Replace one task from a zip/dir, e.g. --replace 7=outputs/task7_candidate.zip",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    base = Path(args.base)
    out = Path(args.out)
    replacements = dict(args.replace)
    out.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="flagos_blend_") as tmp_name:
        tmp = Path(tmp_name)
        for task, task_file in TASK_FILES.items():
            source = replacements.get(task, base)
            (tmp / task_file).write_bytes(_read_jsonl_from_source(Path(source), task_file))
        if out.exists():
            out.unlink()
        shutil.make_archive(str(out.with_suffix("")), "zip", tmp)
        created = out.with_suffix(".zip")
        if created != out:
            if out.exists():
                out.unlink()
            created.replace(out)
    print(f"Wrote blended package: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
