#!/usr/bin/env bash
set -euo pipefail

# Tiny local Qwen3-4B smoke test for 8GB WSL GPUs.
# This is not a submission package. It only checks whether the local GPU can load
# Qwen3-4B in 4-bit mode and complete one short-context sample.

if [[ ! -d ".venv-wsl" ]]; then
  echo "Missing .venv-wsl. Run: bash scripts/wsl_setup_python_inference.sh" >&2
  exit 2
fi

source .venv-wsl/bin/activate
export PYTHONPATH="${PYTHONPATH:-src}"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

if [[ -z "${LOCAL_QWEN3_4B_PATH:-}" && -f "models/Qwen3-4B/config.json" ]]; then
  export LOCAL_QWEN3_4B_PATH="models/Qwen3-4B"
fi
export LOCAL_QWEN3_4B_PATH="${LOCAL_QWEN3_4B_PATH:-Qwen/Qwen3-4B}"

echo "Using Qwen3-4B path: ${LOCAL_QWEN3_4B_PATH}"
echo "Running one-sample tiny smoke test on openseek-5"

python -m flagos_icl.official_cli \
  --config configs/local_qwen_wsl_tiny.yaml \
  --data-dir data/official \
  --output outputs/local_qwen_tiny_submission.json \
  --diagnostics outputs/local_qwen_tiny_diagnostics.json \
  --official-jsonl-dir outputs/local_qwen_tiny_jsonl \
  --task-ids openseek-5 \
  --max-samples-per-task 1

echo "Tiny smoke test outputs:"
ls -lh outputs/local_qwen_tiny_submission.json outputs/local_qwen_tiny_diagnostics.json
