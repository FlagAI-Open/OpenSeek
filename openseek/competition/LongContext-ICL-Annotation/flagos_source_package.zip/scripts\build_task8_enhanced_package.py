from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path

from flagos_icl.task8_torch_reference import REFERENCE_CODE


TASK8_FILE = "openseek-8-v1.jsonl"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build a full submission zip with the current task8 reference code")
    parser.add_argument(
        "--base",
        default="outputs/zhoufui_prediction_task7_multi_consensus3.zip",
        help="Full submission zip used as the base for tasks 1-7",
    )
    parser.add_argument(
        "--out",
        default="outputs/zhoufui_prediction_task7_c3_task8_semantic_fix.zip",
        help="Output full submission zip",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    root = Path(__file__).resolve().parents[1]
    base_zip = root / args.base
    out_zip = root / args.out
    task8_path = root / "data" / "official" / "openseek-8_kernel_generation.json"

    if not base_zip.exists():
        raise FileNotFoundError(base_zip)

    task8 = json.loads(task8_path.read_text(encoding="utf-8"))
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    if out_zip.exists():
        out_zip.unlink()

    with zipfile.ZipFile(base_zip) as source, zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as target:
        for name in sorted(item for item in source.namelist() if item.endswith(".jsonl")):
            if name == TASK8_FILE:
                continue
            target.writestr(name, source.read(name))

        rows = [
            {"test_sample_id": item["id"], "prediction": REFERENCE_CODE}
            for item in task8["test_samples"]
        ]
        payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows)
        target.writestr(TASK8_FILE, payload.encode("utf-8"))

    print(f"Wrote {out_zip}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
