from __future__ import annotations

import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK7_FILE = "openseek-7-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

PREFIX_SOURCE = ROOT / "outputs" / "zhoufui_prediction_task7_c3_stack_prefix_expansion.zip"
SAFE_SOURCE = ROOT / "outputs" / "zhoufui_prediction_task7_c3_stack_safe_string.zip"


def _norm(value: str) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"^(answer|output)\s*:\s*", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" \t\r\n\"'.?!;:")


def _read_rows(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    return {str(row["test_sample_id"]): str(row["prediction"]) for row in _read_rows(zip_path, task_file)}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _write_zip(base_zip: Path, out_zip: Path, task7_rows: list[dict[str, str]]) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_task7_current_micro_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK7_FILE:
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in task7_rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _rows_from(base_rows: list[dict[str, str]], replacements: dict[str, str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in base_rows:
        sample_id = str(row["test_sample_id"])
        rows.append({"test_sample_id": sample_id, "prediction": replacements.get(sample_id, str(row["prediction"]))})
    return rows


def main() -> int:
    required = [BASE_ZIP, PREFIX_SOURCE, SAFE_SOURCE]
    missing = [path for path in required if not path.exists()]
    if missing:
        print("Missing required files:")
        for path in missing:
            print(f"  {path}")
        return 2

    base_rows = _read_rows(BASE_ZIP, TASK7_FILE)
    base_task = {str(row["test_sample_id"]): str(row["prediction"]) for row in base_rows}
    prefix_task = _read_task(PREFIX_SOURCE, TASK7_FILE)
    safe_task = _read_task(SAFE_SOURCE, TASK7_FILE)

    prefix_only: dict[str, str] = {}
    and_cleanup: dict[str, str] = {}

    for sample_id, base_prediction in base_task.items():
        base_norm = _norm(base_prediction)

        prefix_prediction = prefix_task.get(sample_id)
        if prefix_prediction is not None:
            prefix_norm = _norm(prefix_prediction)
            base_tokens = base_norm.split()
            prefix_tokens = prefix_norm.split()
            if (
                base_tokens
                and prefix_norm != base_norm
                and len(prefix_tokens) > len(base_tokens)
                and len(prefix_tokens) <= len(base_tokens) + 5
                and prefix_tokens[: len(base_tokens)] == base_tokens
            ):
                prefix_only[sample_id] = prefix_norm

        safe_prediction = safe_task.get(sample_id)
        if safe_prediction is not None:
            safe_norm = _norm(safe_prediction)
            if "and/or" in base_norm and safe_norm == base_norm.replace("and/or", "and"):
                and_cleanup[sample_id] = safe_norm

    packages = {
        "prefix_only": prefix_only,
        "prefix_plus_and_cleanup": {**prefix_only, **and_cleanup},
    }

    for suffix, replacements in packages.items():
        out_zip = ROOT / "outputs" / f"zhoufui_prediction_8185_task7_safe_micro_{suffix}.zip"
        _write_zip(BASE_ZIP, out_zip, _rows_from(base_rows, replacements))
        print(f"{out_zip}: {len(replacements)} replacements")
        for sample_id, value in sorted(replacements.items()):
            print(f"  {sample_id}: {base_task[sample_id]} => {value}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
