from __future__ import annotations

"""Build a historical guarded task8 out= support probe on the 81.85 base.

Unlike the earlier v5 out_tuple probe, this variant preserves the baseline path
when out is None and only passes out= to PyTorch when the caller provides it.
"""

import ast
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK8_FILE = "openseek-8-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]


REPLACEMENTS = {
    """def max(input, dim=None, keepdim=False, *, out=None):
    return torch.max(input) if dim is None else torch.max(input, dim=dim, keepdim=keepdim)""": """def max(input, dim=None, keepdim=False, *, out=None):
    if dim is None:
        result = torch.max(input)
        if out is not None:
            out.copy_(result)
            return out
        return result
    if out is not None:
        return torch.max(input, dim=dim, keepdim=keepdim, out=out)
    return torch.max(input, dim=dim, keepdim=keepdim)""",
    """def min(input, dim=None, keepdim=False, *, out=None):
    return torch.min(input) if dim is None else torch.min(input, dim=dim, keepdim=keepdim)""": """def min(input, dim=None, keepdim=False, *, out=None):
    if dim is None:
        result = torch.min(input)
        if out is not None:
            out.copy_(result)
            return out
        return result
    if out is not None:
        return torch.min(input, dim=dim, keepdim=keepdim, out=out)
    return torch.min(input, dim=dim, keepdim=keepdim)""",
    """def gelu_min(input, approximate='none', dim=None, keepdim=False, out=None):
    y = F.gelu(input, approximate=approximate)
    return torch.min(y) if dim is None else torch.min(y, dim=dim, keepdim=keepdim)""": """def gelu_min(input, approximate='none', dim=None, keepdim=False, out=None):
    y = F.gelu(input, approximate=approximate)
    if dim is None:
        result = torch.min(y)
        if out is not None:
            out.copy_(result)
            return out
        return result
    if out is not None:
        return torch.min(y, dim=dim, keepdim=keepdim, out=out)
    return torch.min(y, dim=dim, keepdim=keepdim)""",
    """def min_gelu(input, dim=None, keepdim=False, approximate='none', out=None):
    y = F.gelu(input, approximate=approximate)
    return torch.min(y) if dim is None else torch.min(y, dim=dim, keepdim=keepdim)""": """def min_gelu(input, dim=None, keepdim=False, approximate='none', out=None):
    y = F.gelu(input, approximate=approximate)
    if dim is None:
        result = torch.min(y)
        if out is not None:
            out.copy_(result)
            return out
        return result
    if out is not None:
        return torch.min(y, dim=dim, keepdim=keepdim, out=out)
    return torch.min(y, dim=dim, keepdim=keepdim)""",
    """def qr(A, mode='reduced', *, out=None):
    return torch.linalg.qr(A, mode=mode)""": """def qr(A, mode='reduced', *, out=None):
    if out is not None:
        return torch.linalg.qr(A, mode=mode, out=out)
    return torch.linalg.qr(A, mode=mode)""",
    """def lu(A, *, pivot=True, out=None):
    return torch.linalg.lu(A, pivot=pivot)""": """def lu(A, *, pivot=True, out=None):
    if out is not None:
        return torch.linalg.lu(A, pivot=pivot, out=out)
    return torch.linalg.lu(A, pivot=pivot)""",
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task8_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        first_line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
    return str(json.loads(first_line)["prediction"])


def _read_task8_ids(zip_path: Path) -> list[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            str(json.loads(line)["test_sample_id"])
            for line in archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _apply_replacements(code: str) -> str:
    result = code
    for old, new in REPLACEMENTS.items():
        if old not in result:
            raise ValueError(f"Old function not found:\n{old}")
        result = result.replace(old, new)
    ast.parse(result)
    return result


def _write_package(out_zip: Path, task8_code: str) -> None:
    task8_ids = _read_task8_ids(BASE_ZIP)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v7_guarded_out_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK8_FILE:
                rows = [{"test_sample_id": sample_id, "prediction": task8_code} for sample_id in task8_ids]
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def main() -> int:
    code = _apply_replacements(_read_task8_code(BASE_ZIP))
    _write_package(ROOT / "outputs" / "zhoufui_prediction_8185_task8_v7_guarded_out_tuple.zip", code)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
