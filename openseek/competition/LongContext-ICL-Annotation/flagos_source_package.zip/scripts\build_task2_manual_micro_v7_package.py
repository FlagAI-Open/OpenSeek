from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v6_safe.zip"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

# Manual micro-extension v7 on top of the 81.82 v6_safe package.
# Keep this as a single-sample probe: "holding" is clearly verbal, and official
# examples often count reduced participles such as "wrapped" as verbs.
WRAPPED_ONLY = {
    "openseek-2-8248fce4c112460b9138be5bf46841f9": "2",  # holding + wrapped
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _write_package(out_zip: Path, replacements: dict[str, str]) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t2_manual_micro_v7_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in _read_task2_rows(BASE_ZIP):
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}: {len(replacements)} replacements")
    for sid, value in replacements.items():
        print(f"  {sid} => {value}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)


def main() -> int:
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip", WRAPPED_ONLY)
    print("\nSuggested next submission:")
    print("outputs\\zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip")
    print("This is equivalent in changed records to v6_full, but explicitly based on the 81.82 v6_safe package.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
