from __future__ import annotations

"""Build historical task8 math-semantic probes on the 81.85 base package."""

import ast
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK8_FILE = "openseek-8-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]


REPLACEMENTS = {
    "spectral_norm_eig_only": {
        """def spectral_norm_eig(A, *, out=None):
    return _out(torch.linalg.matrix_norm(A, ord=2), out)""": """def spectral_norm_eig(A, *, out=None):
    eigenvalues = torch.linalg.eigvals(A)
    result = torch.max(torch.abs(eigenvalues), dim=-1).values
    return _out(result, out)""",
    },
    "matrix_power_eig_only": {
        """def matrix_power_eig(A, k, *, out=None):
    return _out(torch.linalg.matrix_power(A, int(k)), out)""": """def matrix_power_eig(A, k, *, out=None):
    eigenvalues, eigenvectors = torch.linalg.eig(A)
    power = k.item() if torch.is_tensor(k) and k.numel() == 1 else k
    powered = eigenvalues ** power
    result = eigenvectors @ torch.diag_embed(powered) @ torch.linalg.inv(eigenvectors)
    if not torch.is_complex(A) and torch.max(torch.abs(result.imag)) < 1e-6:
        result = result.real
    return _out(result, out)""",
    },
    "fused_qr_solve_only": {
        """def fused_qr_solve(A, b):
    return torch.linalg.lstsq(A, b).solution""": """def fused_qr_solve(A, b):
    Q, R = torch.linalg.qr(A, mode='reduced')
    return torch.linalg.solve_triangular(R, Q.mH @ b, upper=True)""",
    },
    "bitwise_binomial_safe_only": {
        """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    return torch.bitwise_and(input, other)""": """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    and_result = torch.bitwise_and(input, other)
    trials = total_count.to(torch.float32) if torch.is_tensor(total_count) else torch.as_tensor(total_count, device=and_result.device, dtype=torch.float32)
    if logits is not None:
        dist = torch.distributions.Binomial(total_count=trials, logits=logits)
    else:
        p = probs
        if p is None:
            p = and_result.to(torch.float32)
            if and_result.dtype != torch.bool:
                max_value = torch.clamp(torch.max(torch.abs(p)), min=1.0)
                p = torch.clamp(p / max_value, 0.0, 1.0)
        dist = torch.distributions.Binomial(total_count=trials, probs=p)
    return dist.sample().to(and_result.dtype)""",
    },
}


PRIORITY = [
    "spectral_norm_eig_only",
    "matrix_power_eig_only",
    "fused_qr_solve_only",
    "bitwise_binomial_safe_only",
]


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task8_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        first_line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
    return str(json.loads(first_line)["prediction"])


def _read_task8_ids(zip_path: Path) -> list[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            str(json.loads(line)["test_sample_id"])
            for line in archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _apply_replacements(code: str, replacements: dict[str, str]) -> str:
    result = code
    for old, new in replacements.items():
        if old not in result:
            raise ValueError(f"Old function not found:\n{old}")
        result = result.replace(old, new)
    ast.parse(result)
    return result


def _write_package(out_zip: Path, task8_code: str) -> None:
    task8_ids = _read_task8_ids(BASE_ZIP)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v6_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK8_FILE:
                rows = [
                    {"test_sample_id": sample_id, "prediction": task8_code}
                    for sample_id in task8_ids
                ]
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def main() -> int:
    base_code = _read_task8_code(BASE_ZIP)
    for name in PRIORITY:
        code = _apply_replacements(base_code, REPLACEMENTS[name])
        _write_package(ROOT / "outputs" / f"zhoufui_prediction_8185_task8_v6_{name}.zip", code)

    print("\nSuggested order for tomorrow:")
    print("1. outputs\\zhoufui_prediction_8185_task8_v6_spectral_norm_eig_only.zip")
    print("2. outputs\\zhoufui_prediction_8185_task8_v6_matrix_power_eig_only.zip")
    print("3. outputs\\zhoufui_prediction_8185_task8_v6_fused_qr_solve_only.zip")
    print("4. outputs\\zhoufui_prediction_8185_task8_v6_bitwise_binomial_safe_only.zip")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
