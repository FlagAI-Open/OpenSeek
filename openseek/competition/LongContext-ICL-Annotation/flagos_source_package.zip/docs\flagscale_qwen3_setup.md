# FlagScale Qwen3-4B Setup

## Allowed Model

The Track 3 FAQ only allows Qwen3-4B. Do not use any other model for inference,
preprocessing, extraction, filtering, or intermediate labeling.

Official model sources:

- HuggingFace: https://huggingface.co/Qwen/Qwen3-4B
- ModelScope: https://modelscope.cn/models/Qwen/Qwen3-4B

## FlagOS / FlagScale Nvidia Route

The official OpenSeek baseline README lists the required environment as `openai`, `torch`,
and `flagScale`, then deploys the model by running FlagScale's `run.py` with an
`llm_config.yaml` file. The final reproduction path for this repository follows that route.

For Nvidia hardware, the closest competition-aligned package is:

- https://huggingface.co/FlagRelease/Qwen3-4B-FlagOS-Nvidia

It states that Qwen3-4B is integrated with FlagScale and provides a prebuilt Docker image
for Nvidia H100 deployment.

### Download Docker Image

```bash
docker pull flagrelease-registry.cn-beijing.cr.aliyuncs.com/flagrelease/flagrelease:nv_vllm085_gemscbbf39
```

### Download Qwen3-4B Weights

```bash
pip install modelscope
modelscope download --model Qwen/Qwen3-4B --local_dir /nfs/Qwen3-4B
```

### Start Container

```bash
docker run --rm --init --detach \
  --net=host --uts=host --ipc=host \
  --security-opt=seccomp=unconfined \
  --privileged=true \
  --ulimit stack=67108864 \
  --ulimit memlock=-1 \
  --ulimit nofile=1048576:1048576 \
  --shm-size=32G \
  -v /nfs:/nfs \
  --gpus all \
  --name flagos \
  flagrelease-registry.cn-beijing.cr.aliyuncs.com/flagrelease/flagrelease:nv_vllm085_gemscbbf39 \
  sleep infinity
```

```bash
docker exec -it flagos bash
```

### Serve

Official OpenSeek-style service launch:

```bash
cd FlagScale
python run.py --config-path .. --config-name llm_config action=run
```

Stop service:

```bash
cd FlagScale
python run.py --config-path .. --config-name llm_config action=stop
```

This repository wraps the same command with:

```bash
export FLAGSCALE_DIR="$HOME/FlagScale"
export LLM_CONFIG_PATH="/path/to/config-dir"
export LLM_CONFIG_NAME="llm_config"
bash scripts/flagscale_start_service.sh
```

Legacy/container quick command, if available in the image:

```bash
flagscale serve qwen3
```

## Third-Party GPU Recommendation

Use a Linux GPU instance with Docker and NVIDIA Container Toolkit.

Recommended choices:

- Best reliability: H100 80GB
- Good balance: A100 80GB
- Budget test: RTX 4090 24GB

Qwen3-4B itself is small, but this challenge uses long-context ICL and thousands of requests.
A100 80GB or H100 80GB is safer for the final run. RTX 4090 may work for cheaper testing,
but long-context settings may require lowering max context, batch size, or concurrency.

## Windows WSL2 Local Smoke Test

This repository can also be smoke-tested on a Windows laptop with WSL2, Docker Desktop,
and an NVIDIA GPU. This path is useful for validating the local container/GPU toolchain,
but it is not the recommended path for the final full-context inference run when the GPU
has limited memory.

Validated local baseline:

```text
Windows + WSL2 Ubuntu
NVIDIA GeForce RTX 5060 Laptop GPU
GPU memory: about 8 GB
Docker Desktop WSL integration: enabled
Docker GPU container: validated with nvidia/cuda:12.4.1-base-ubuntu22.04
```

WSL checks:

```bash
cd /mnt/c/Users/Fe/Desktop/web3/FlagOS
uname -a
nvidia-smi
```

Docker Desktop settings:

```text
Settings -> Resources -> WSL Integration
Enable integration with the Ubuntu WSL distro.
```

If Docker image pulls need a local Clash Verge proxy, use the real Clash HTTP/mixed port.
On the validated laptop the working port was `7897`:

```text
Settings -> Resources -> Proxies

Docker Desktop proxy:
HTTP:  http://127.0.0.1:7897
HTTPS: http://127.0.0.1:7897

Containers proxy:
Same as host proxy

Bypass:
localhost,127.0.0.1,host.docker.internal
```

Docker GPU check:

```bash
docker run --rm --gpus=all nvidia/cuda:12.4.1-base-ubuntu22.04 nvidia-smi
```

Expected result: the container prints the same NVIDIA GPU through `nvidia-smi`.

Important limitation: this validates the WSL2/Docker/NVIDIA stack only. The final
Qwen3-4B long-context ICL run should still use a larger Linux GPU server when possible,
because the competition workload uses long prompts and many requests.

## Helper Scripts

This repository includes:

```bash
bash scripts/linux_server_setup.sh
bash scripts/linux_run_predictions.sh
```

`linux_server_setup.sh` pulls the FlagOS Nvidia Docker image, downloads Qwen3-4B from ModelScope,
and starts the `flagos` container.

`linux_run_predictions.sh` calls the local OpenAI-compatible endpoint and writes:

```text
outputs/zhoufui_prediction_final.zip
```

## Connect This Repository

Once the FlagScale service exposes an OpenAI-compatible endpoint, set:

```bash
export OPENAI_BASE_URL="http://127.0.0.1:9010/v1"
export OPENAI_API_KEY="EMPTY"
```

Then run:

```bash
bash scripts/linux_run_predictions.sh
```

Equivalent expanded command:

```bash
PYTHONPATH=src python -m flagos_icl.official_cli \
  --config configs/baseline.yaml \
  --data-dir data/official \
  --output outputs/official_submission.json \
  --diagnostics outputs/official_diagnostics.json \
  --official-jsonl-dir outputs/official_jsonl \
  --deterministic-postprocess
```

Before the final run, smoke-test the endpoint:

```bash
python scripts/flagscale_api_test.py \
  --base-url "$OPENAI_BASE_URL" \
  --api-key "$OPENAI_API_KEY" \
  --model Qwen3-4B \
  --output outputs/flagscale_logs/api_test.json
```

If the service uses another port or model name, update `configs/baseline.yaml`.

## Current Local Machine

This Windows workspace can validate data format and output files. It is not enough for final competition
inference unless it has a working FlagScale Qwen3-4B runtime.
