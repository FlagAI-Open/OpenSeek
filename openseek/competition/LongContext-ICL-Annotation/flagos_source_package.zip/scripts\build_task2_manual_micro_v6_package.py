from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v5_full.zip"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

# Manual micro-extension v6 on top of 81.77.
# SAFE: two independent action participles, both supported by official examples.
# - "standing and smiling" examples are 2.
# - "flying ... landing" / "walking ... approaching" examples are 2+.
SAFE_SUBSET = {
    "openseek-2-ddbc0fc5552b4231aeac09b3732ddc34": "2",  # smiling + standing
    "openseek-2-8d96baaf69fc47f5ae2c122a36718076": "2",  # approaching + landing
}

# FULL adds one reduced participle phrase. This is plausible but less certain.
FULL_SET = {
    **SAFE_SUBSET,
    "openseek-2-8248fce4c112460b9138be5bf46841f9": "2",  # holding + wrapped
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _write_package(out_zip: Path, replacements: dict[str, str]) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t2_manual_micro_v6_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in _read_task2_rows(BASE_ZIP):
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}: {len(replacements)} replacements")
    for sid, value in replacements.items():
        print(f"  {sid} => {value}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)


def main() -> int:
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v6_safe.zip", SAFE_SUBSET)
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v6_full.zip", FULL_SET)
    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_task2_manual_micro_v6_safe.zip")
    print("2. outputs\\zhoufui_prediction_task2_manual_micro_v6_full.zip only if #1 improves")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
