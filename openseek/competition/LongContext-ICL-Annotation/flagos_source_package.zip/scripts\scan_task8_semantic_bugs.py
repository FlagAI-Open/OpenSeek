from __future__ import annotations

"""Systematically scan task8 reference code for semantic bugs.

For each test sample, extract the Math/order description and compare
against the reference implementation. Flag suspicious mismatches.
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"


def _get_ref() -> str:
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    match = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    return match.group(1)


def _get_func_body(ref: str, func_name: str) -> str | None:
    """Extract a function body from the reference code."""
    escaped = re.escape(func_name)
    pattern = rf"def {escaped}\([^)]*\):.*?(?=\n(?:def |class |@|#|if __name__|\Z))"
    m = re.search(pattern, ref, re.DOTALL)
    return m.group(0) if m else None


def _extract_math(text: str) -> str:
    """Extract the Math section from a test sample."""
    m = re.search(r"Math:\s*(.*?)(?:\nother:|\nAfter generation|$)", text, re.DOTALL)
    return m.group(1).strip() if m else ""


def _extract_order(text: str) -> list[str]:
    """Extract described operation order from Math section."""
    # Look for patterns like "A -> B -> C" or describe order in text
    order = []
    # Check for arrow notation
    arrows = re.findall(r"(\w+(?:\s*\([^)]*\))?)\s*->\s*(\w+(?:\s*\([^)]*\))?)", text)
    for a, b in arrows:
        if a not in order:
            order.append(a)
        if b not in order:
            order.append(b)
    return order


def _parse_wrapper_name(text: str) -> str | None:
    """Extract function name from Wrapper Entry Information."""
    m = re.search(r"Wrapper Entry Information:\s*(?:def\s+)?([\w.]+)", text)
    return m.group(1) if m else None


def _count_ignored_params(func_body: str, params: list[str]) -> list[str]:
    """Check which parameters from the signature are not used in the body."""
    ignored = []
    for param in params:
        # Simple check: is the param name mentioned in the body?
        if param not in func_body:
            ignored.append(param)
    return ignored


def main() -> int:
    ref = _get_ref()
    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))

    findings: list[dict] = []

    for sample in task8["test_samples"]:
        sid = sample["id"]
        text = sample["input"]
        func_name = _parse_wrapper_name(text)
        if not func_name or func_name.startswith("linalg."):
            continue

        func_body = _get_func_body(ref, func_name)
        if not func_body:
            continue

        math = _extract_math(text)
        flags = []

        # ── Check 1: order described in Math vs implementation ──
        if "->" in math or " then " in math.lower():
            # Extract described order
            order_words = re.findall(r"(\w+(?:_\w+)*)", math)
            impl_order = re.findall(r"(\w+(?:_\w+)*)", func_body)
            # Check if key operations appear in reversed order
            # This is a heuristic - flag if suspicious
            pass

        # ── Check 2: parameters completely ignored ──
        sig_match = re.search(
            rf"def {re.escape(func_name)}\(([^)]*)\)",
            ref.replace(" ", " "),  # normalize
            re.DOTALL,
        )
        if sig_match:
            sig = sig_match.group(1)
            params = [p.strip().split("=")[0].split(":")[0].strip()
                      for p in sig.split(",") if p.strip()]
            # Remove self, *, **kwargs patterns
            params = [p for p in params if p and not p.startswith("*")]
            # Find params NOT used in body (excluding common ones)
            ignored = []
            for p in params:
                if p in ("input", "other", "out", "dim", "keepdim"):
                    continue  # common params, often used implicitly
                # Check if param appears in body
                if p.replace("_", "") not in func_body.replace("_", ""):
                    ignored.append(p)
            if ignored:
                flags.append(f"IGNORED_PARAMS: {', '.join(ignored)}")

        # ── Check 3: out parameter handling ──
        if "out=None" in func_body or "*, out=None" in func_body:
            if "_out(" not in func_body:
                flags.append("OUT_NOT_USED: accepts out= but doesn't use _out()")
            if "return torch.max" in func_body or "return torch.min" in func_body:
                if "dim" in func_body:
                    flags.append("MAX_MIN_TUPLE: max/min with dim returns (values,indices)")

        # ── Check 4: known operation pairs that might be reversed ──
        # Check for specific patterns
        op_pairs = [
            (r"F\.softmax\(torch\.log\(", "softmax(log(x))", "log(softmax(x))"),
            (r"torch\.log\(F\.softmax\(", "log(softmax(x))", "softmax(log(x))"),
            (r"F\.dropout\(.*F\.hardshrink", "dropout(hardshrink(x))", "hardshrink(dropout(x))"),
            (r"F\.hardshrink\(.*F\.dropout", "hardshrink(dropout(x))", "dropout(hardshrink(x))"),
        ]
        for pattern, order_a, order_b in op_pairs:
            if re.search(pattern, func_body):
                flags.append(f"ORDER_SUSPECT: found {order_a}, check if Math expects {order_b}")

        # ── Check 5: hardcoded constants that might need to be parameters ──
        hardcoded = []
        if "upper=True" in func_body and "upper" not in sig_match.group(1) if sig_match else "":
            hardcoded.append("upper=True")
        if hardcoded:
            flags.append(f"HARDCODED: {', '.join(hardcoded)}")

        if flags:
            findings.append({
                "sample_id": sid,
                "func_name": func_name,
                "flags": flags,
                "math": math[:200],
                "func_preview": func_body[:300],
            })

    # ── Output ──
    print(f"Scanned {len(task8['test_samples'])} test samples")
    print(f"Flagged {len(findings)} functions\n")

    # Group by flag type
    by_flag: dict[str, list] = {}
    for f in findings:
        for flag in f["flags"]:
            flag_type = flag.split(":")[0]
            by_flag.setdefault(flag_type, []).append(f)

    for flag_type, items in sorted(by_flag.items()):
        print(f"=== {flag_type} ({len(items)} functions) ===")
        for item in items:
            print(f"  {item['func_name']} | {item['sample_id']}")
            if "IGNORED_PARAMS" in str(item["flags"]):
                for f in item["flags"]:
                    if f.startswith("IGNORED_PARAMS"):
                        print(f"    {f}")
            if "OUT_NOT_USED" in str(item["flags"]):
                for f in item["flags"]:
                    if f.startswith("OUT_NOT_USED"):
                        print(f"    {f}")
        print()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
