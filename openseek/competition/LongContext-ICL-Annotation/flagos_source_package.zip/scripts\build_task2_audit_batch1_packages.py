from __future__ import annotations

import csv
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
CANDIDATES_TSV = ROOT / "outputs" / "task2_audit_candidates_batch1.tsv"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

TIER1_IDS = {
    "openseek-2-c19f0eae7b494309a0a361e01ce07918",
    "openseek-2-790e2701f6794c3fa52433013f487558",
    "openseek-2-dd17f5da44bf4c6b99e6817ed2f897fb",
    "openseek-2-ce69b89b3f4640c1acd8da2452b3ad37",
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _load_candidates() -> list[dict[str, str]]:
    with CANDIDATES_TSV.open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle, delimiter="\t"))
    required = {"sample_id", "current", "suggested", "confidence", "reason"}
    missing = required - set(rows[0]) if rows else required
    if missing:
        raise ValueError(f"Candidate TSV missing columns: {sorted(missing)}")
    return rows


def _write_package(out_zip: Path, replacements: dict[str, str]) -> None:
    base_rows = _read_task2_rows(BASE_ZIP)
    base_values = {str(row["test_sample_id"]): str(row["prediction"]) for row in base_rows}
    for sample_id in replacements:
        if sample_id not in base_values:
            raise ValueError(f"Candidate sample id not found in base task2 rows: {sample_id}")

    with tempfile.TemporaryDirectory(prefix="flagos_t2_audit_batch1_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in base_rows:
                    sample_id = str(row["test_sample_id"])
                    rows.append(
                        {
                            "test_sample_id": sample_id,
                            "prediction": replacements.get(sample_id, str(row["prediction"])),
                        }
                    )
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}: {len(replacements)} replacements")
    for sample_id, value in replacements.items():
        print(f"  {sample_id}: {base_values[sample_id]} => {value}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)


def main() -> int:
    candidates = _load_candidates()
    all_replacements = {row["sample_id"]: row["suggested"] for row in candidates}
    tier1_replacements = {
        row["sample_id"]: row["suggested"]
        for row in candidates
        if row["sample_id"] in TIER1_IDS
    }

    if len(tier1_replacements) != len(TIER1_IDS):
        missing = sorted(TIER1_IDS - set(tier1_replacements))
        raise ValueError(f"Missing tier1 candidate rows: {missing}")

    _write_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task2_audit_batch1_tier1.zip",
        tier1_replacements,
    )
    _write_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task2_audit_batch1_all8.zip",
        all_replacements,
    )

    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_8185_task2_audit_batch1_tier1.zip")
    print("2. outputs\\zhoufui_prediction_8185_task2_audit_batch1_all8.zip only if #1 is non-negative")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
