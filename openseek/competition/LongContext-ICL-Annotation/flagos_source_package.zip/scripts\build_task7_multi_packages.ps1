param(
    [string]$Base = "outputs\zhoufui_prediction_task2_verbconf_task8_torch_ref.zip",
    [string]$OutPrefix = "outputs\zhoufui_prediction_task7_multi"
)

$ErrorActionPreference = "Stop"

$Candidates = @(
    "outputs\zhoufui_prediction_local_qwen_7_v2_selected.zip",
    "outputs\zhoufui_prediction_local_qwen_7_v3_selected.zip",
    "outputs\zhoufui_prediction_local_qwen_7_v4_selected.zip",
    "outputs\zhoufui_prediction_local_qwen_7_v5_selected.zip"
)

if (-not (Test-Path -LiteralPath $Base)) {
    throw "Missing base package: $Base"
}

foreach ($candidate in $Candidates) {
    if (-not (Test-Path -LiteralPath $candidate)) {
        throw "Missing task7 candidate: $candidate"
    }
}

python scripts\build_task7_consensus_packages.py `
    --base $Base `
    --out-prefix $OutPrefix `
    @Candidates

$Packages = @(
    "${OutPrefix}_consensus3.zip",
    "${OutPrefix}_expansion.zip",
    "${OutPrefix}_base_suspicious.zip",
    "${OutPrefix}_consensus2.zip"
)

foreach ($package in $Packages) {
    python scripts\validate_submission_zip.py $package
}

Write-Host ""
Write-Host "Suggested submission order for the next contest day:"
Write-Host "1. ${OutPrefix}_consensus3.zip"
Write-Host "2. ${OutPrefix}_expansion.zip"
Write-Host "3. ${OutPrefix}_base_suspicious.zip"
Write-Host "4. ${OutPrefix}_consensus2.zip"
Write-Host ""
Write-Host "Keep the current best if none of these beats 80.82:"
Write-Host $Base
