from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v4_final.zip"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

# Manual micro-extension v5 on top of 81.70.
# SAFE: official examples strongly support counting two action participles:
# - holding + standing examples are consistently 2+.
# - sitting + wearing examples are 2, so sitting + holding should be 2.
SAFE_SUBSET = {
    "openseek-2-35520b2c9818437fac5df8b4502c9386": "2",  # holding + standing
    "openseek-2-8a7e897a64f44e09a95f38681c2e1732": "2",  # is sitting + holding
}

# FULL adds higher-reward but slightly riskier multi-verb clauses.
FULL_SET = {
    **SAFE_SUBSET,
    "openseek-2-87ce38bfd3bf455ca3ed6230892aa6e8": "3",  # made to look + bleeding/stabbed
    "openseek-2-261c262fc2364ebe8f82952062519ea3": "3",  # has + selling + has
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _write_package(out_zip: Path, replacements: dict[str, str]) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t2_manual_micro_v5_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in _read_task2_rows(BASE_ZIP):
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}: {len(replacements)} replacements")
    for sid, value in replacements.items():
        print(f"  {sid} => {value}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)


def main() -> int:
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v5_safe.zip", SAFE_SUBSET)
    _write_package(ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v5_full.zip", FULL_SET)
    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_task2_manual_micro_v5_safe.zip")
    print("2. outputs\\zhoufui_prediction_task2_manual_micro_v5_full.zip only if #1 improves")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
