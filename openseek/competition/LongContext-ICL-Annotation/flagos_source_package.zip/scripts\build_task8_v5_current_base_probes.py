from __future__ import annotations

"""Build task8 v5 probe packages on top of the current 81.82 base.

These packages intentionally use the current best submission as the base so
task8 probes do not accidentally carry older task2/task7 changes.
"""

import ast
import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK8_FILE = "openseek-8-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]


OLD_SOLVE_AND_ADD = """def solve_and_add_scaled_vector(A, b, y, alpha):
    return torch.linalg.solve_triangular(A, b, upper=True) + alpha * y"""

FIX_SOLVE_AND_ADD = """def solve_and_add_scaled_vector(A, b, y, alpha):
    x = torch.linalg.solve_triangular(A, b, upper=True)
    # If b is a matrix of multiple RHS columns and y is a length-n vector,
    # add y as a column vector to each RHS solution.
    if torch.is_tensor(y) and y.dim() == x.dim() - 1 and x.shape[-2] == y.shape[-1]:
        y = y.unsqueeze(-1)
    return x + alpha * y"""


OUT_TUPLE_REPLACEMENTS = {
    """def max(input, dim=None, keepdim=False, *, out=None):
    return torch.max(input) if dim is None else torch.max(input, dim=dim, keepdim=keepdim)""": """def max(input, dim=None, keepdim=False, *, out=None):
    if dim is None:
        result = torch.max(input)
        if out is not None:
            out.copy_(result)
            return out
        return result
    return torch.max(input, dim=dim, keepdim=keepdim, out=out)""",
    """def min(input, dim=None, keepdim=False, *, out=None):
    return torch.min(input) if dim is None else torch.min(input, dim=dim, keepdim=keepdim)""": """def min(input, dim=None, keepdim=False, *, out=None):
    if dim is None:
        result = torch.min(input)
        if out is not None:
            out.copy_(result)
            return out
        return result
    return torch.min(input, dim=dim, keepdim=keepdim, out=out)""",
    """def gelu_min(input, approximate='none', dim=None, keepdim=False, out=None):
    y = F.gelu(input, approximate=approximate)
    return torch.min(y) if dim is None else torch.min(y, dim=dim, keepdim=keepdim)""": """def gelu_min(input, approximate='none', dim=None, keepdim=False, out=None):
    y = F.gelu(input, approximate=approximate)
    if dim is None:
        result = torch.min(y)
        if out is not None:
            out.copy_(result)
            return out
        return result
    return torch.min(y, dim=dim, keepdim=keepdim, out=out)""",
    """def min_gelu(input, dim=None, keepdim=False, approximate='none', out=None):
    y = F.gelu(input, approximate=approximate)
    return torch.min(y) if dim is None else torch.min(y, dim=dim, keepdim=keepdim)""": """def min_gelu(input, dim=None, keepdim=False, approximate='none', out=None):
    y = F.gelu(input, approximate=approximate)
    if dim is None:
        result = torch.min(y)
        if out is not None:
            out.copy_(result)
            return out
        return result
    return torch.min(y, dim=dim, keepdim=keepdim, out=out)""",
    """def qr(A, mode='reduced', *, out=None):
    return torch.linalg.qr(A, mode=mode)""": """def qr(A, mode='reduced', *, out=None):
    return torch.linalg.qr(A, mode=mode, out=out)""",
    """def lu(A, *, pivot=True, out=None):
    return torch.linalg.lu(A, pivot=pivot)""": """def lu(A, *, pivot=True, out=None):
    return torch.linalg.lu(A, pivot=pivot, out=out)""",
}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task8_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        first_line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
    return str(json.loads(first_line)["prediction"])


def _read_task8_ids(zip_path: Path) -> list[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            str(json.loads(line)["test_sample_id"])
            for line in archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _apply_replacements(code: str, replacements: dict[str, str]) -> str:
    result = code
    for old, new in replacements.items():
        if old not in result:
            raise ValueError(f"Old function not found:\n{old}")
        result = result.replace(old, new)
    ast.parse(result)
    return result


def _write_package(out_zip: Path, task8_code: str) -> None:
    task8_ids = _read_task8_ids(BASE_ZIP)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v5_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK8_FILE:
                rows = [
                    {"test_sample_id": sample_id, "prediction": task8_code}
                    for sample_id in task8_ids
                ]
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def main() -> int:
    base_code = _read_task8_code(BASE_ZIP)

    solve_code = _apply_replacements(base_code, {OLD_SOLVE_AND_ADD: FIX_SOLVE_AND_ADD})
    _write_package(ROOT / "outputs" / "zhoufui_prediction_8185_task8_v5_solve_vector_broadcast.zip", solve_code)

    out_code = _apply_replacements(base_code, OUT_TUPLE_REPLACEMENTS)
    _write_package(ROOT / "outputs" / "zhoufui_prediction_8185_task8_v5_out_tuple_support.zip", out_code)

    combined_code = _apply_replacements(solve_code, OUT_TUPLE_REPLACEMENTS)
    _write_package(ROOT / "outputs" / "zhoufui_prediction_8185_task8_v5_solve_plus_out_tuple.zip", combined_code)

    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_8185_task8_v5_solve_vector_broadcast.zip")
    print("2. outputs\\zhoufui_prediction_8185_task8_v5_out_tuple_support.zip")
    print("3. outputs\\zhoufui_prediction_8185_task8_v5_solve_plus_out_tuple.zip only if both prior probes are non-negative")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
