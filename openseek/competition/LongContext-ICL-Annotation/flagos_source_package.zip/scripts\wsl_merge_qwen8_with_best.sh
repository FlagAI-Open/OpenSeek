#!/usr/bin/env bash
set -euo pipefail

# Merge Qwen task 8 into the historical pre-task8 best package.
# Defaults to the older local mix: qwen2 + qwen5/6 + qwen7.

BASE_MIX_DIR="${BASE_MIX_DIR:-outputs/official_jsonl_qwen7_mix_nobom_20260514_233403}"
QWEN8_DIR="${QWEN8_DIR:-outputs/local_qwen_8_jsonl}"
MERGED_DIR="${MERGED_DIR:-outputs/official_jsonl_qwen8_mix}"
OUT_ZIP="${OUT_ZIP:-outputs/zhoufui_prediction_qwen8_mix.zip}"

rm -rf "$MERGED_DIR"
mkdir -p "$MERGED_DIR"

cp "$BASE_MIX_DIR"/*.jsonl "$MERGED_DIR"/
cp "$QWEN8_DIR"/*.jsonl "$MERGED_DIR"/

rm -f "$OUT_ZIP"
cd "$MERGED_DIR"
zip -r "../$(basename "$OUT_ZIP")" ./*.jsonl
cd - >/dev/null

echo "Merged package: $OUT_ZIP"
ls -lh "$OUT_ZIP"
echo "Line counts:"
wc -l "$MERGED_DIR"/*.jsonl
