from __future__ import annotations

import json
import zipfile
from pathlib import Path

from flagos_icl.task8_torch_reference import REFERENCE_CODE


ROOT = Path(__file__).resolve().parents[1]
BEST_ZIP = ROOT / "outputs" / "BEST_69_18.zip"
OUT_DIR = ROOT / "outputs" / "official_jsonl_task8_torch_ref"
OUT_ZIP = ROOT / "outputs" / "zhoufui_prediction_task8_torch_ref.zip"


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BEST_ZIP) as source:
        for name in source.namelist():
            if name == "openseek-8-v1.jsonl":
                continue
            (OUT_DIR / name).write_bytes(source.read(name))

    task8 = json.loads((ROOT / "data" / "official" / "openseek-8_kernel_generation.json").read_text(encoding="utf-8"))
    with (OUT_DIR / "openseek-8-v1.jsonl").open("w", encoding="utf-8", newline="\n") as handle:
        for item in task8["test_samples"]:
            handle.write(json.dumps({"test_sample_id": item["id"], "prediction": REFERENCE_CODE}, ensure_ascii=False) + "\n")

    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT_DIR.glob("*.jsonl")):
            archive.write(path, arcname=path.name)
    print(f"Wrote {OUT_ZIP}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
