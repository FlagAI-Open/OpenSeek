from __future__ import annotations

import json
import math
import re
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_verb_consensus_safe_delta1.zip"
TASK2_DATA = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"
TASK2_FILE = "openseek-2-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

TOKEN_RE = re.compile(r"[a-z]+", re.IGNORECASE)


def _sentence(text: str) -> str:
    match = re.search(r"Sentence: '([^']+)'", text)
    return match.group(1) if match else text


def _is_verb(text: str) -> bool:
    return "count the number of verbs" in text.lower()


def _tokens(text: str) -> Counter[str]:
    stop = {
        "a", "an", "the", "of", "on", "in", "at", "to", "with", "and", "or", "for", "from",
        "by", "near", "next", "front", "top", "it", "its", "this", "that", "there", "some",
        "two", "three", "four", "one", "many",
    }
    return Counter(token.lower() for token in TOKEN_RE.findall(text) if token.lower() not in stop)


def _cosine(left: Counter[str], right: Counter[str]) -> float:
    if not left or not right:
        return 0.0
    dot = sum(value * right.get(key, 0) for key, value in left.items())
    ln = math.sqrt(sum(value * value for value in left.values()))
    rn = math.sqrt(sum(value * value for value in right.values()))
    return dot / (ln * rn) if ln and rn else 0.0


def _load_data() -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    raw = json.loads(TASK2_DATA.read_text(encoding="utf-8"))
    examples: list[dict[str, object]] = []
    tests: list[dict[str, object]] = []
    for item in raw["examples"]:
        if _is_verb(item["input"]):
            sent = _sentence(item["input"])
            examples.append(
                {
                    "id": item["id"],
                    "sentence": sent,
                    "label": int(item["output"][0]),
                    "vector": _tokens(sent),
                }
            )
    for item in raw["test_samples"]:
        if _is_verb(item["input"]):
            sent = _sentence(item["input"])
            tests.append({"id": item["id"], "sentence": sent, "vector": _tokens(sent)})
    return examples, tests


def _nearest(query: Counter[str], examples: list[dict[str, object]], skip_id: str | None = None, k: int = 5):
    scored = []
    for ex in examples:
        if skip_id is not None and ex["id"] == skip_id:
            continue
        scored.append((_cosine(query, ex["vector"]), int(ex["label"]), str(ex["sentence"])))
    scored.sort(reverse=True, key=lambda item: item[0])
    return scored[:k]


def _predict(neighbors: list[tuple[float, int, str]], *, min_votes: int, min_margin: int, min_score: float) -> int | None:
    if not neighbors or neighbors[0][0] < min_score:
        return None
    counts = Counter(label for _, label, _ in neighbors)
    ((label, votes), *rest) = counts.most_common()
    second = rest[0][1] if rest else 0
    if votes >= min_votes and votes - second >= min_margin:
        return int(label)
    return None


def _read_rows(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    return {row["test_sample_id"]: str(row["prediction"]).strip() for row in _read_rows(zip_path, task_file)}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _write_zip(base_zip: Path, out_zip: Path, replacements: dict[str, str]) -> None:
    base_rows = _read_rows(base_zip, TASK2_FILE)
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t2_knn_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in base_rows:
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _validate(path: Path) -> None:
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(path)], check=True)


def main() -> int:
    if not BASE_ZIP.exists():
        raise FileNotFoundError(BASE_ZIP)
    examples, tests = _load_data()
    base = _read_task(BASE_ZIP, TASK2_FILE)

    specs = {
        "knn5_votes5_score35": {"k": 5, "min_votes": 5, "min_margin": 5, "min_score": 0.35},
        "knn7_votes6_score30": {"k": 7, "min_votes": 6, "min_margin": 5, "min_score": 0.30},
        "knn9_votes7_score30": {"k": 9, "min_votes": 7, "min_margin": 5, "min_score": 0.30},
    }

    print(f"Verb examples: {len(examples)}")
    print(f"Verb tests: {len(tests)}")
    for name, spec in specs.items():
        correct = 0
        predicted = 0
        for ex in examples:
            neighbors = _nearest(ex["vector"], examples, skip_id=str(ex["id"]), k=spec["k"])
            pred = _predict(
                neighbors,
                min_votes=spec["min_votes"],
                min_margin=spec["min_margin"],
                min_score=spec["min_score"],
            )
            if pred is None:
                continue
            predicted += 1
            if pred == int(ex["label"]):
                correct += 1
        precision = correct / predicted if predicted else 0.0
        coverage = predicted / len(examples)
        print(f"\n{name}: example precision={precision:.4f}, coverage={coverage:.4f}, predicted={predicted}")

        replacements: dict[str, str] = {}
        for test in tests:
            neighbors = _nearest(test["vector"], examples, k=spec["k"])
            pred = _predict(
                neighbors,
                min_votes=spec["min_votes"],
                min_margin=spec["min_margin"],
                min_score=spec["min_score"],
            )
            if pred is None:
                continue
            current = base.get(str(test["id"]))
            if current is None or str(pred) == current:
                continue
            if 0 <= pred <= 6:
                replacements[str(test["id"])] = str(pred)

        out = ROOT / "outputs" / f"zhoufui_prediction_task2_{name}.zip"
        _write_zip(BASE_ZIP, out, replacements)
        print(f"{out}: {len(replacements)} replacements on 81.37")
        for sid, value in sorted(replacements.items())[:40]:
            print(f"  {sid}: {base[sid]} => {value}")
        _validate(out)

    print("\nUse only if example precision is clearly above 0.90 and replacement count is not tiny.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
