#!/usr/bin/env bash
set -euo pipefail

# Run three independent Qwen3-4B task7 prompts for later consensus blending.
# This script uses only the local model and official dataset already in this repo.

run_one() {
  local config="$1"
  local prefix="$2"
  local selected_zip="outputs/zhoufui_prediction_${prefix}_selected.zip"

  if [[ -f "${selected_zip}" && "${FORCE_RERUN:-0}" != "1" ]]; then
    echo "Skip existing ${selected_zip}"
    return
  fi

  echo "=== Running ${prefix} with ${config} ==="
  CONFIG="${config}" \
  TASK_IDS=openseek-7 \
  OUT_PREFIX="${prefix}" \
  bash scripts/wsl_run_qwen_selected.sh
}

cd "$(dirname "$0")/.."

run_one configs/local_qwen_answer_v3_no_examples.yaml local_qwen_7_v3
run_one configs/local_qwen_answer_v4_compact_examples.yaml local_qwen_7_v4
run_one configs/local_qwen_answer_v5_wordplay_strict.yaml local_qwen_7_v5

echo "Task7 multi-run complete. Build consensus packages from Windows PowerShell next."
