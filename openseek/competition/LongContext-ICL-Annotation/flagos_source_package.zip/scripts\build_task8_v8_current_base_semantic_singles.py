from __future__ import annotations

"""Build task8 semantic single-point probes on top of the current 81.85 base.

These probes are intentionally narrow:
- softmax_log_single fixes the duplicate softmax_log override so it matches
  the task statement: Softmax(log(input)).
- softmax_log_plus_binomial additionally enables the bitwise_and_binomial
  sampling described by the task statement.

The recommended outputs are row-only packages: only the affected task8 rows are
changed, while all other rows stay byte-for-byte aligned with the current best.
"""

import ast
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK8_FILE = "openseek-8-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]
SOFTMAX_LOG_ID = "openseek-8-829de8149cf149d782ba0cbad32c09b5"
BITWISE_AND_BINOMIAL_ID = "openseek-8-fb3ffb7be7524d2494d8cc837084eb6a"


OLD_SOFTMAX_LOG_OVERRIDE = """def softmax_log(input, dim=-1, dtype=None):
    return torch.log(F.softmax(input, dim=dim, dtype=dtype))"""

FIX_SOFTMAX_LOG = """def softmax_log(input, dim=-1, dtype=None):
    return F.softmax(torch.log(input), dim=dim, dtype=dtype)"""

OLD_BITWISE_AND_BINOMIAL = """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    return torch.bitwise_and(input, other)"""

FIX_BITWISE_AND_BINOMIAL = """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    and_result = torch.bitwise_and(input, other)
    trials = total_count.to(torch.float32) if torch.is_tensor(total_count) else torch.as_tensor(total_count, device=and_result.device, dtype=torch.float32)
    if logits is not None:
        dist = torch.distributions.Binomial(total_count=trials, logits=logits)
    else:
        p = probs
        if p is None:
            p = and_result.to(torch.float32)
            if and_result.dtype != torch.bool:
                max_value = torch.clamp(torch.max(torch.abs(p)), min=1.0)
                p = torch.clamp(p / max_value, 0.0, 1.0)
        dist = torch.distributions.Binomial(total_count=trials, probs=p)
    return dist.sample().to(and_result.dtype)"""


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task8_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        first_line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
    return str(json.loads(first_line)["prediction"])


def _read_task8_ids(zip_path: Path) -> list[str]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            str(json.loads(line)["test_sample_id"])
            for line in archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _replace_once(code: str, old: str, new: str) -> str:
    if code.count(old) != 1:
        raise ValueError(f"Expected exactly one match, found {code.count(old)} for:\n{old}")
    updated = code.replace(old, new)
    ast.parse(updated)
    return updated


def _write_global_package(out_zip: Path, task8_code: str) -> None:
    task8_ids = _read_task8_ids(BASE_ZIP)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v8_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK8_FILE:
                rows = [
                    {"test_sample_id": sample_id, "prediction": task8_code}
                    for sample_id in task8_ids
                ]
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(BASE_ZIP, task_file)
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def _write_rowonly_package(out_zip: Path, replacements_by_id: dict[str, str]) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v8_rowonly_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            payload = _read_payload(BASE_ZIP, task_file)
            if task_file == TASK8_FILE:
                rows: list[dict[str, str]] = []
                for line in payload.decode("utf-8-sig").splitlines():
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    sample_id = str(row["test_sample_id"])
                    if sample_id in replacements_by_id:
                        row["prediction"] = replacements_by_id[sample_id]
                    rows.append(row)
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            (tmp / task_file).write_bytes(payload)

        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def main() -> int:
    base_code = _read_task8_code(BASE_ZIP)

    softmax_code = _replace_once(base_code, OLD_SOFTMAX_LOG_OVERRIDE, FIX_SOFTMAX_LOG)
    _write_global_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task8_v8_softmax_log_single.zip",
        softmax_code,
    )

    softmax_binomial_code = _replace_once(
        softmax_code,
        OLD_BITWISE_AND_BINOMIAL,
        FIX_BITWISE_AND_BINOMIAL,
    )
    _write_global_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task8_v8_softmax_log_plus_binomial.zip",
        softmax_binomial_code,
    )

    _write_rowonly_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task8_v8_softmax_log_rowonly.zip",
        {SOFTMAX_LOG_ID: softmax_code},
    )
    _write_rowonly_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task8_v8_softmax_log_rowonly_plus_binomial_rowonly.zip",
        {
            SOFTMAX_LOG_ID: softmax_code,
            BITWISE_AND_BINOMIAL_ID: softmax_binomial_code,
        },
    )

    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_8185_task8_v8_softmax_log_rowonly.zip")
    print("2. outputs\\zhoufui_prediction_8185_task8_v8_softmax_log_rowonly_plus_binomial_rowonly.zip only if #1 is non-negative")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
