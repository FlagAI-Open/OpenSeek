from __future__ import annotations

"""Scan task8 for tomorrow's semantic fix candidates.

For each test sample, extract Math/Functional Description and flag
potential discrepancies with the reference implementation.
Output a ranked candidate list.
"""

import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"


def _get_ref() -> str:
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    m = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    return m.group(1)


def _get_func_body(ref: str, name: str) -> str:
    escaped = re.escape(name)
    m = re.search(rf"def {escaped}\([^)]*\).*?(?=\n(?:def |class |@|if __name__|\Z))", ref, re.DOTALL)
    return m.group(0) if m else ""


def _extract_section(text: str, section: str) -> str:
    """Extract a named section from the test sample input."""
    m = re.search(rf"{section}:\s*(.*?)(?:\n\w+:|\nAfter generation|$)", text, re.DOTALL)
    return m.group(1).strip() if m else ""


def main() -> int:
    ref = _get_ref()
    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))

    print(f"# Task8 Semantic Fix Candidates for Tomorrow\n")
    print(f"Base: zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip (81.12)\n")

    # Categories to look for
    high_conf: list[dict] = []
    mid_conf: list[dict] = []
    low_conf: list[dict] = []

    for sample in task8["test_samples"]:
        sid = sample["id"]
        text = sample["input"]

        # Extract function name
        m = re.search(r"Wrapper Entry Information:\s*(?:def\s+)?([\w.]+)", text)
        if not m:
            continue
        fname = m.group(1)
        if fname.startswith("linalg."):
            continue  # skip linalg namespace methods for now

        func_body = _get_func_body(ref, fname)
        if not func_body:
            continue

        math = _extract_section(text, "Math")
        func_desc = _extract_section(text, "Functional Description")
        other_info = _extract_section(text, "other")
        wrapper = _extract_section(text, "Wrapper Entry Information")

        flags = []
        evidence = []

        # ── Check 1: explicit order in Math/Description vs implementation ──
        # Look for patterns like "X then Y" or "X followed by Y" or X -> Y -> Z
        order_patterns = re.findall(
            r"(?:first|then|followed by|applies?|performs?)\s+(\w+(?:\s+\w+){0,3})",
            func_desc + " " + math,
            re.IGNORECASE,
        )
        # Check for arrow notation
        arrows = re.findall(r"(\w+)\s*->\s*(\w+)", func_desc + " " + math)
        if arrows:
            described_order = " -> ".join(a[0] for a in arrows) + " -> " + arrows[-1][1]
            evidence.append(f"Described order: {described_order}")

        # ── Check 2: explicit formula that might mismatch ──
        formulas = re.findall(r"\\text\{([^}]+)\}", math)
        if formulas:
            for f in formulas:
                evidence.append(f"Math formula: {f}")

        # ── Check 3: parameters mentioned as required but not in body ──
        sig_match = re.search(rf"def {re.escape(fname)}\(([^)]*)\)", ref)
        if sig_match:
            sig = sig_match.group(1)
            params = [
                p.strip().split("=")[0].split(":")[0].strip().strip("*")
                for p in sig.split(",")
                if p.strip() and not p.strip().startswith("*")
            ]
            for p in params:
                if p in ("input", "other", "out", "dim", "keepdim", "self"):
                    continue
                if p not in func_body:
                    flags.append(f"PARAM_UNUSED: '{p}' in signature but NOT in body")
                    # Check if param is mentioned in description as important
                    if p in func_desc or p in math:
                        evidence.append(f"Param '{p}' is in description but missing from implementation")

        # ── Check 4: LayerNorm/BatchNorm dimension concerns ──
        if "layer_norm" in func_body.lower() or "batch_norm" in func_body.lower():
            if "normalized_shape" in func_body or "weight" in func_body:
                # Check if the normalization dimension handling looks correct
                pass

        # ── Check 5: return type in wrapper vs implementation ──
        ret_match = re.search(r"->\s*(\S+(?:\s*,\s*\S+)*)", wrapper)
        if ret_match:
            ret_type = ret_match.group(1).strip()
            if "Tuple" in ret_type or "," in ret_type:
                # Returns multiple values - check if implementation does too
                if "return " in func_body and "," not in func_body.split("return ")[-1].split("\n")[0]:
                    if "torch.max" not in func_body and "torch.min" not in func_body:
                        flags.append(f"RETURN_TYPE: wrapper says '{ret_type}' but impl returns single value")

        # Determine confidence
        if flags:
            item = {
                "func_name": fname,
                "sample_id": sid,
                "flags": flags,
                "evidence": evidence,
                "func_preview": func_body[:250],
                "math": math[:200],
                "desc": func_desc[:300],
            }

            if any("PARAM_UNUSED" in f for f in flags):
                high_conf.append(item)
            elif any("RETURN_TYPE" in f for f in flags):
                mid_conf.append(item)
            else:
                low_conf.append(item)

    # ── Output ──
    def print_candidates(items: list[dict], label: str) -> None:
        print(f"\n## {label} ({len(items)} candidates)\n")
        if not items:
            print("  (none)\n")
            return
        for item in items:
            print(f"### {item['func_name']} | {item['sample_id']}")
            print(f"Flags: {', '.join(item['flags'])}")
            if item["evidence"]:
                for e in item["evidence"]:
                    print(f"  Evidence: {e}")
            print(f"  Math: {item['math'][:150]}")
            print(f"  Desc: {item['desc'][:200]}")
            print(f"  Impl: {item['func_preview'][:200]}")
            print()

    print_candidates(high_conf, "HIGH CONFIDENCE — PARAM UNUSED")
    print_candidates(mid_conf, "MEDIUM CONFIDENCE — RETURN TYPE / OTHER")
    print_candidates(low_conf, "LOW CONFIDENCE — NEEDS MANUAL REVIEW")

    # ── Summary ──
    print(f"\n## Summary")
    print(f"Total test samples scanned: {len(task8['test_samples'])}")
    print(f"HIGH: {len(high_conf)}")
    print(f"MEDIUM: {len(mid_conf)}")
    print(f"LOW: {len(low_conf)}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
