from __future__ import annotations

"""Build task8 per-sample prediction packages (conservative + full).

Key requirements:
- Base from current best 81.12 package
- Each per-sample prediction must be complete executable code:
  imports + helpers + target function + namespace/alias
- Conservative: only replace when 100% confident (all deps internal & traceable)
- Full: replace all extractable samples, fallback to full reference for edge cases
"""

import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"

BASE_IMPORTS = (
    "import math\n"
    "from typing import *\n\n"
    "import torch\n"
    "import torch.nn.functional as F\n\n"
)

# ── reference parsing ──────────────────────────────────────────────

def _read_ref_source() -> str:
    """Extract the REFERENCE_CODE string from task8_torch_reference.py."""
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    m = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    if not m:
        raise ValueError("Cannot find REFERENCE_CODE")
    return m.group(1)


def parse_all_functions(ref: str) -> dict[str, str]:
    """Parse all top-level function definitions from the reference code."""
    funcs: dict[str, str] = {}
    lines = ref.split("\n")
    current_name: str | None = None
    current_lines: list[str] = []

    for line in lines:
        m = re.match(r"^def (\w+)\(.*", line)
        if m:
            if current_name and current_lines:
                funcs[current_name] = "\n".join(current_lines)
            current_name = m.group(1)
            current_lines = [line]
        elif current_name:
            if re.match(r"^(def |class |if __name__)", line):
                if current_lines:
                    funcs[current_name] = "\n".join(current_lines)
                m2 = re.match(r"^def (\w+)\(.*", line)
                if m2:
                    current_name = m2.group(1)
                    current_lines = [line]
                else:
                    current_name = None
                    current_lines = []
            else:
                current_lines.append(line)

    if current_name and current_lines:
        funcs[current_name] = "\n".join(current_lines)
    return funcs


def parse_linalg_class(ref: str) -> str:
    """Extract the _LinalgNamespace class definition."""
    m = re.search(r"class _LinalgNamespace:.*?(?=\n\n\n|\nif not hasattr|\Z)", ref, re.DOTALL)
    return m.group(0).strip() if m else ""


def parse_module_level_code(ref: str) -> str:
    """Extract module-level setup code (linalg instance, aliases, permute_copy hook)."""
    # Everything after the last function/class definition that isn't a def/class
    lines = ref.split("\n")
    module_lines: list[str] = []
    in_module = False
    for line in lines:
        if line.startswith("linalg = _LinalgNamespace()"):
            in_module = True
        if in_module:
            module_lines.append(line)
    return "\n".join(module_lines) if module_lines else ""


# ── dependency resolution ──────────────────────────────────────────

# Functions defined in the reference that are "helpers" (start with _)
# These are always included when depended on.
HELPER_FUNCTIONS = {"_out", "_norm_shape", "_rms_norm", "_bn", "_linear_last", "_special"}

# Public functions that may be called by other public functions.
# When a target function calls one of these, we include it as a dependency.
CROSS_CALLABLE = {
    "fused_bmm_rmsnorm_gelu_dropout",  # called by _sub variant
    "permute_copy",                     # may be referenced
    "softmax_log",                     # may be cross-referenced
    "solve",                           # used by linalg.solve
}


def _find_calls(func_body: str, all_func_names: set[str]) -> set[str]:
    """Find which reference-defined functions are called in func_body."""
    called: set[str] = set()
    for name in all_func_names:
        if name == "solve":
            # Only match 'solve(' not 'solve_triangular' etc.
            if re.search(rf"\bsolve\(", func_body):
                called.add(name)
        else:
            if re.search(rf"\b{re.escape(name)}\b", func_body):
                called.add(name)
    return called


def resolve_dependencies(target: str, all_funcs: dict[str, str]) -> set[str]:
    """Get the full transitive closure of dependencies for a target function."""
    all_names = set(all_funcs.keys())
    resolved: set[str] = set()
    queue = [target]

    while queue:
        current = queue.pop(0)
        if current in resolved:
            continue
        resolved.add(current)
        body = all_funcs.get(current, "")
        for called in _find_calls(body, all_names):
            if called not in resolved and called not in queue:
                # Include if it's a helper or in the cross-callable set
                if called in HELPER_FUNCTIONS or called in CROSS_CALLABLE:
                    queue.append(called)

    return resolved


def resolve_class_dependencies(target_method: str, all_funcs: dict[str, str]) -> set[str]:
    """Resolve deps for a linalg method — needs the full class plus solve helper."""
    deps: set[str] = set()
    # The linalg class methods call 'solve' and '_out'
    if "solve" in all_funcs:
        deps.add("solve")
    if "_out" in all_funcs:
        deps.add("_out")
    return deps


# ── code assembly ──────────────────────────────────────────────────

def assemble_code(
    func_name: str,
    all_funcs: dict[str, str],
    ref: str,
    *,
    conservative: bool = False,
) -> str | None:
    """Assemble complete executable code for a single function.

    Returns None if the code cannot be assembled (conservative mode) or
    falls back to full reference (full mode).
    """
    # ── linalg methods ──────────────────────────────────────────────
    if func_name.startswith("linalg."):
        if conservative:
            return None  # too complex for conservative
        method = func_name.split(".", 1)[1]
        class_code = parse_linalg_class(ref)
        module_code = parse_module_level_code(ref)
        deps = resolve_class_dependencies(method, all_funcs)
        dep_code = "\n\n".join(all_funcs[d] for d in sorted(deps) if d in all_funcs)
        parts = [BASE_IMPORTS]
        if dep_code:
            parts.append(dep_code)
        parts.append(class_code)
        if module_code:
            parts.append(module_code)
        return "\n\n".join(parts)

    # ── regular functions ──────────────────────────────────────────
    if func_name not in all_funcs:
        return None if conservative else None  # will fallback in caller

    deps = resolve_dependencies(func_name, all_funcs)

    # In conservative mode, verify all deps are internal & traceable
    if conservative:
        # Check for any external references in the combined code
        combined_test = "\n\n".join(all_funcs[d] for d in deps if d in all_funcs)
        # Check for torch.distributions reference (needs extra handling)
        if "torch.distributions" in combined_test:
            return None
        # linalg usage check
        if re.search(r"\blinalg\.", combined_test):
            return None

    # Build: sorted helpers first, then target
    ordered = sorted(d for d in deps if d in all_funcs and d != func_name)
    ordered.append(func_name)
    func_code = "\n\n".join(all_funcs[n] for n in ordered if n in all_funcs)

    # Check for permute_copy module-level code
    extra_code = ""
    if "permute_copy" in deps:
        extra_code = parse_module_level_code(ref)

    parts = [BASE_IMPORTS, func_code]
    if extra_code:
        parts.append(extra_code)
    return "\n\n".join(parts)


# ── wrapper name extraction ────────────────────────────────────────

def extract_func_name(text: str) -> str | None:
    """Extract function name from test sample input."""
    # Special cases from functional description
    desc = text.split("Functional Description:", 1)[-1].split("Wrapper Entry Information:", 1)[0]
    if "Returns the mean value" in desc:
        return "mean"
    if "solution of a square system of linear equations" in desc:
        return "linalg.solve"

    m = re.search(r"Wrapper Entry Information:\s*(?:def\s+)?([\w.]+)", text)
    if not m:
        return None
    name = m.group(1)
    if name == "torch.permute_copy":
        return "permute_copy"
    return name


# ── package building ───────────────────────────────────────────────

def build_package(
    out_path: Path,
    base_zip: Path,
    task8_data: dict,
    ref: str,
    all_funcs: dict[str, str],
    *,
    conservative: bool,
) -> tuple[int, int]:
    """Build a full submission zip. Returns (per_sample_count, fallback_count)."""
    out_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="flagos_t8_ps_") as tmp_name:
        tmp = Path(tmp_name)
        with zipfile.ZipFile(base_zip) as source:
            for name in source.namelist():
                if name == "openseek-8-v1.jsonl":
                    continue
                (tmp / name).write_bytes(source.read(name))

        per_sample = 0
        fallback = 0
        full_ref = ref.strip()
        t8_rows: list[dict[str, str]] = []

        for item in task8_data["test_samples"]:
            sid = item["id"]
            func_name = extract_func_name(item["input"])
            code = None

            if func_name:
                code = assemble_code(func_name, all_funcs, ref, conservative=conservative)

            if code is None:
                code = full_ref
                fallback += 1
            else:
                per_sample += 1

            t8_rows.append({"test_sample_id": sid, "prediction": code})

        payload = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in t8_rows).encode("utf-8")
        (tmp / "openseek-8-v1.jsonl").write_bytes(payload)

        if out_path.exists():
            out_path.unlink()
        created = shutil.make_archive(str(out_path.with_suffix("")), "zip", tmp)
        Path(created).replace(out_path)

    return per_sample, fallback


# ── pre-submission validation ──────────────────────────────────────

def validate_code_ast(code: str, label: str) -> list[str]:
    """Try to compile the code; return list of error messages (empty = ok)."""
    errors: list[str] = []
    try:
        compile(code, f"<{label}>", "exec")
    except SyntaxError as e:
        errors.append(f"SyntaxError: {e}")
    return errors


def validate_target_present(code: str, func_name: str, label: str) -> list[str]:
    """Check that the target function name appears as a 'def' in the code."""
    errors: list[str] = []
    if func_name.startswith("linalg."):
        method = func_name.split(".", 1)[1]
        if f"def {method}" not in code:
            errors.append(f"{label}: linalg method 'def {method}' not found in output")
    else:
        if f"def {func_name}" not in code:
            errors.append(f"{label}: target function 'def {func_name}' not found in output")
    return errors


def validate_fused_helpers(code: str, func_name: str, label: str) -> list[str]:
    """For fused_* functions, check that called helpers are present."""
    errors: list[str] = []
    # Check common helpers that fused functions depend on
    helper_checks = [
        ("_out(", "_out helper called but not defined"),
        ("_norm_shape(", "_norm_shape helper called but not defined"),
        ("_rms_norm(", "_rms_norm helper called but not defined"),
        ("_bn(", "_bn helper called but not defined"),
        ("_linear_last(", "_linear_last helper called but not defined"),
    ]
    for call_pattern, msg in helper_checks:
        if call_pattern in code:
            if f"def {call_pattern[:-1]}" not in code:
                errors.append(f"{label}: {msg}")
    return errors


def verify_tasks_1_7(zip_path: Path, base_zip: Path) -> list[str]:
    """Verify tasks 1-7 match the base package exactly."""
    errors: list[str] = []
    task_files = [f"openseek-{i}-v1.jsonl" for i in range(1, 8)]
    with zipfile.ZipFile(base_zip) as bz, zipfile.ZipFile(zip_path) as tz:
        for tf in task_files:
            base_data = bz.read(tf)
            test_data = tz.read(tf)
            if base_data != test_data:
                errors.append(f"tasks-1-7 mismatch: {tf} differs from base")
    return errors


def run_pre_submission_checks(
    zip_path: Path,
    task8_data: dict,
    all_funcs: dict[str, str],
    ref: str,
) -> bool:
    """Run all pre-submission checks. Returns True if all pass."""
    all_ok = True
    errors: list[str] = []

    # Check 1: tasks 1-7 match base
    errs = verify_tasks_1_7(zip_path, BASE_ZIP)
    if errs:
        errors.extend(errs)
        print(f"  FAIL: tasks 1-7 mismatch ({len(errs)} files differ)")
        all_ok = False
    else:
        print(f"  PASS: tasks 1-7 match base")

    # Check 2: read back task8 predictions and validate each
    with zipfile.ZipFile(zip_path) as zf:
        t8_data = zf.read("openseek-8-v1.jsonl").decode("utf-8")
    predictions = {
        json.loads(line)["test_sample_id"]: json.loads(line)["prediction"]
        for line in t8_data.splitlines() if line.strip()
    }

    ast_errors = 0
    target_errors = 0
    helper_errors = 0
    full_ref_count = 0

    for item in task8_data["test_samples"]:
        sid = item["id"]
        code = predictions.get(sid, "")
        func_name = extract_func_name(item["input"]) or "unknown"

        # Is it full reference fallback?
        if code.strip() == ref.strip():
            full_ref_count += 1
            continue

        # AST check
        ast_errs = validate_code_ast(code, sid)
        if ast_errs:
            ast_errors += 1
            if ast_errors <= 5:
                for e in ast_errs:
                    errors.append(e)

        # Target function present
        tgt_errs = validate_target_present(code, func_name, sid)
        if tgt_errs:
            target_errors += 1
            if target_errors <= 5:
                errors.extend(tgt_errs)

        # Fused helper check
        hlp_errs = validate_fused_helpers(code, func_name, sid)
        if hlp_errs:
            helper_errors += 1
            if helper_errors <= 5:
                errors.extend(hlp_errs)

    per_sample_count = len(predictions) - full_ref_count
    print(f"  per_sample={per_sample_count} fallback={full_ref_count}")
    print(f"  AST errors: {ast_errors}")
    print(f"  target missing: {target_errors}")
    print(f"  helper missing: {helper_errors}")

    if ast_errors > 0 or target_errors > 0:
        all_ok = False
        print(f"  FAIL: {ast_errors + target_errors} validation errors")
    else:
        print(f"  PASS: all per-sample predictions validated")

    if errors:
        print("  First errors:")
        for e in errors[:10]:
            print(f"    {e}")

    return all_ok


# ── main ────────────────────────────────────────────────────────────

def main() -> int:
    ref = _read_ref_source()
    all_funcs = parse_all_functions(ref)
    print(f"Parsed {len(all_funcs)} functions from reference")

    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))
    n_total = len(task8["test_samples"])

    # ── conservative ────────────────────────────────────────────────
    print("\n=== conservative ===")
    out_conservative = ROOT / "outputs" / "zhoufui_prediction_task8_per_sample_conservative.zip"
    ps, fb = build_package(
        out_conservative, BASE_ZIP, task8, ref, all_funcs, conservative=True
    )
    print(f"  per_sample={ps} fallback={fb}/{n_total}")

    import subprocess
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_conservative)])
    run_pre_submission_checks(out_conservative, task8, all_funcs, ref)

    # ── full ───────────────────────────────────────────────────────
    print("\n=== full ===")
    out_full = ROOT / "outputs" / "zhoufui_prediction_task8_per_sample_full.zip"
    ps, fb = build_package(
        out_full, BASE_ZIP, task8, ref, all_funcs, conservative=False
    )
    print(f"  per_sample={ps} fallback={fb}/{n_total}")

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_full)])
    run_pre_submission_checks(out_full, task8, all_funcs, ref)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
