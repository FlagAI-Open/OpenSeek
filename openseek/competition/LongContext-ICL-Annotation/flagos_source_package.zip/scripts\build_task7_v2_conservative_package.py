from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_verbconf_task8_torch_ref.zip"
V2_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_v2_mix.zip"
OUT_DIR = ROOT / "outputs" / "official_jsonl_task7_v2_conservative"
OUT_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_v2_conservative_mix.zip"


def _clean(value: str) -> str:
    return re.sub(r"\s+", " ", value.strip().lower())


def _is_safe_expansion(base: str, candidate: str) -> bool:
    base = _clean(base)
    candidate = _clean(candidate)
    if not base or not candidate or base == candidate:
        return False
    if len(base) < 3:
        return False
    if len(candidate) > 60:
        return False
    if re.search(r"[^a-z0-9 .,&'\"/\-()]", candidate):
        return False
    base_tokens = base.split()
    cand_tokens = candidate.split()
    if len(base_tokens) > 3:
        return False
    if len(cand_tokens) <= len(base_tokens) or len(cand_tokens) > len(base_tokens) + 3:
        return False
    if cand_tokens[: len(base_tokens)] == base_tokens:
        return True
    if cand_tokens[-len(base_tokens) :] == base_tokens:
        return True
    return False


def _is_format_fix(base: str, candidate: str) -> bool:
    base = _clean(base)
    candidate = _clean(candidate)
    if not candidate or len(candidate) > 40:
        return False
    if re.search(r"[^a-z0-9 .,&'\"/\-()]", candidate):
        return False
    if "and/or" in base and " and " in candidate:
        return True
    if len(base) > 50 and len(candidate.split()) <= 4:
        return True
    if re.search(r"[^a-z0-9 .,&'\"/\-()]", base) and re.fullmatch(r"[a-z0-9 .,&'\"/\-()]+", candidate):
        return True
    return False


def _read_task7(zip_path: Path) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: json.loads(line)["prediction"]
            for line in archive.read("openseek-7-v1.jsonl").decode("utf-8-sig").splitlines()
            if line.strip()
        }


def main() -> int:
    base_task7 = _read_task7(BASE_ZIP)
    v2_task7 = _read_task7(V2_ZIP)
    accepted = {
        sample_id: candidate
        for sample_id, candidate in v2_task7.items()
        if sample_id in base_task7
        and (_is_safe_expansion(base_task7[sample_id], candidate) or _is_format_fix(base_task7[sample_id], candidate))
    }

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE_ZIP) as source:
        for name in source.namelist():
            payload = source.read(name)
            if name == "openseek-7-v1.jsonl":
                rows = []
                for line in payload.decode("utf-8-sig").splitlines():
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    sample_id = row["test_sample_id"]
                    if sample_id in accepted:
                        row["prediction"] = accepted[sample_id]
                    rows.append(row)
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            (OUT_DIR / name).write_bytes(payload)

    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT_DIR.glob("*.jsonl")):
            archive.write(path, arcname=path.name)

    print(f"Wrote {OUT_ZIP}")
    print(f"Accepted task7 v2 replacements: {len(accepted)}")
    for sample_id in sorted(accepted):
        print(f"{sample_id}\t{base_task7[sample_id]}\t=>\t{accepted[sample_id]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
