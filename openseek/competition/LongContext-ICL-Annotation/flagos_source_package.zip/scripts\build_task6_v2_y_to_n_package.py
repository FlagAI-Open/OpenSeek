from __future__ import annotations

import json
import re
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_verbconf_task8_torch_ref.zip"
V2_ZIP = ROOT / "outputs" / "zhoufui_prediction_task6_v2_mix.zip"
OUT_DIR = ROOT / "outputs" / "official_jsonl_task6_v2_y_to_n"
OUT_ZIP = ROOT / "outputs" / "zhoufui_prediction_task6_v2_y_to_n_mix.zip"


def _coerce_task6(value: str) -> str:
    text = str(value).strip()
    if text in {"Y", "N"}:
        return text
    match = re.search(r'"output"\s*:\s*"([YN])"', text)
    if match:
        return match.group(1)
    lowered = text.lower()
    if lowered.startswith("y"):
        return "Y"
    if lowered.startswith("n"):
        return "N"
    return text


def _read_task6(zip_path: Path) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: _coerce_task6(json.loads(line)["prediction"])
            for line in archive.read("openseek-6-v1.jsonl").decode("utf-8-sig").splitlines()
            if line.strip()
        }


def main() -> int:
    base_task6 = _read_task6(BASE_ZIP)
    v2_task6 = _read_task6(V2_ZIP)
    accepted = {
        sample_id: "N"
        for sample_id, candidate in v2_task6.items()
        if base_task6.get(sample_id) == "Y" and candidate == "N"
    }

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(BASE_ZIP) as source:
        for name in source.namelist():
            payload = source.read(name)
            if name == "openseek-6-v1.jsonl":
                rows = []
                for line in payload.decode("utf-8-sig").splitlines():
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    sample_id = row["test_sample_id"]
                    if sample_id in accepted:
                        row["prediction"] = accepted[sample_id]
                    rows.append(row)
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            (OUT_DIR / name).write_bytes(payload)

    if OUT_ZIP.exists():
        OUT_ZIP.unlink()
    with zipfile.ZipFile(OUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(OUT_DIR.glob("*.jsonl")):
            archive.write(path, arcname=path.name)

    print(f"Wrote {OUT_ZIP}")
    print(f"Accepted task6 Y->N replacements: {len(accepted)}")
    for sample_id in sorted(accepted):
        print(sample_id)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
