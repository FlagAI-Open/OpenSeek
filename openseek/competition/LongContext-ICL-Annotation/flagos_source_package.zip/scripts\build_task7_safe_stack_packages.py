from __future__ import annotations

import argparse
import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path


TASK7 = "openseek-7-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]


def _norm(value: str) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"^(answer|output)\s*:\s*", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip(" \t\r\n\"'.?!;:")


def _strip_article(value: str) -> str:
    return re.sub(r"^(a|an|the)\s+", "", _norm(value))


def _read_task(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_task_map(zip_path: Path, task_file: str) -> dict[str, str]:
    return {str(row["test_sample_id"]): str(row["prediction"]) for row in _read_task(zip_path, task_file)}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _write_zip(base_zip: Path, out_zip: Path, task7_rows: list[dict[str, str]]) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_task7_safe_stack_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK7:
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in task7_rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _rows_from(base_rows: list[dict[str, str]], replacements: dict[str, str]) -> list[dict[str, str]]:
    return [
        {
            "test_sample_id": str(row["test_sample_id"]),
            "prediction": replacements.get(str(row["test_sample_id"]), str(row["prediction"])),
        }
        for row in base_rows
    ]


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build conservative task7 stacks on top of consensus3")
    parser.add_argument("--base", required=True, help="Best full package before task7 multi-run")
    parser.add_argument("--anchor", required=True, help="Known best task7 package, usually consensus3")
    parser.add_argument("--expansion", required=True, help="Expansion-only task7 package")
    parser.add_argument("--consensus2", required=True, help="Consensus2 task7 package")
    parser.add_argument("--out-prefix", required=True, help="Output prefix")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    base_zip = Path(args.base)
    anchor_zip = Path(args.anchor)
    expansion_zip = Path(args.expansion)
    consensus2_zip = Path(args.consensus2)
    out_prefix = Path(args.out_prefix)

    base_task = _read_task_map(base_zip, TASK7)
    anchor_rows = _read_task(anchor_zip, TASK7)
    anchor_task = {str(row["test_sample_id"]): str(row["prediction"]) for row in anchor_rows}
    expansion_task = _read_task_map(expansion_zip, TASK7)
    consensus2_task = _read_task_map(consensus2_zip, TASK7)

    prefix_expansion: dict[str, str] = {}
    article_strip: dict[str, str] = {}
    slash_cleanup: dict[str, str] = {}

    for sample_id, expanded in expansion_task.items():
        if _norm(anchor_task.get(sample_id, "")) != _norm(base_task.get(sample_id, "")):
            continue
        old = _norm(base_task.get(sample_id, ""))
        new = _norm(expanded)
        old_tokens = old.split()
        new_tokens = new.split()
        if old_tokens and len(new_tokens) > len(old_tokens) and new_tokens[: len(old_tokens)] == old_tokens:
            prefix_expansion[sample_id] = expanded

    for sample_id, candidate in consensus2_task.items():
        old = anchor_task.get(sample_id, "")
        if _norm(candidate) == _strip_article(old) and _norm(candidate) != _norm(old):
            article_strip[sample_id] = candidate
        if "and/or" in _norm(old) and _norm(candidate) == _norm(old).replace("and/or", "and"):
            slash_cleanup[sample_id] = candidate

    packages = {
        "prefix_expansion": prefix_expansion,
        "article_strip": article_strip,
        "safe_string": {**prefix_expansion, **article_strip, **slash_cleanup},
    }
    for suffix, replacements in packages.items():
        stacked = dict(anchor_task)
        stacked.update(replacements)
        out_zip = out_prefix.with_name(f"{out_prefix.name}_{suffix}.zip")
        _write_zip(anchor_zip, out_zip, _rows_from(anchor_rows, stacked))
        print(f"{out_zip}: {len(replacements)} added replacements on top of anchor")
        for sample_id, value in sorted(replacements.items()):
            print(f"  {sample_id}: {anchor_task[sample_id]} => {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
