from __future__ import annotations

"""Build a one-row task8 bitwise_and_binomial probe on the 81.85 base.

The earlier binomial probes rewrote every task8 row because the shared fallback
code changed. This package keeps the current best byte-aligned everywhere except
for the single sample whose wrapper is bitwise_and_binomial.
"""

import ast
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task2_manual_micro_v7_wrapped_only.zip"
TASK8_FILE = "openseek-8-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]
BITWISE_AND_BINOMIAL_ID = "openseek-8-fb3ffb7be7524d2494d8cc837084eb6a"


OLD_BITWISE_AND_BINOMIAL = """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    return torch.bitwise_and(input, other)"""

FIX_BITWISE_AND_BINOMIAL = """def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    and_result = torch.bitwise_and(input, other)
    trials = total_count.to(torch.float32) if torch.is_tensor(total_count) else torch.as_tensor(total_count, device=and_result.device, dtype=torch.float32)
    if logits is not None:
        dist = torch.distributions.Binomial(total_count=trials, logits=logits)
    else:
        p = probs
        if p is None:
            p = and_result.to(torch.float32)
            if and_result.dtype != torch.bool:
                max_value = torch.clamp(torch.max(torch.abs(p)), min=1.0)
                p = torch.clamp(p / max_value, 0.0, 1.0)
        dist = torch.distributions.Binomial(total_count=trials, probs=p)
    return dist.sample().to(and_result.dtype)"""


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task8_code(zip_path: Path) -> str:
    with zipfile.ZipFile(zip_path) as archive:
        first_line = archive.read(TASK8_FILE).decode("utf-8-sig").splitlines()[0]
    return str(json.loads(first_line)["prediction"])


def _replace_once(code: str, old: str, new: str) -> str:
    if code.count(old) != 1:
        raise ValueError(f"Expected exactly one match, found {code.count(old)} for:\n{old}")
    updated = code.replace(old, new)
    ast.parse(updated)
    return updated


def _write_rowonly_package(out_zip: Path, replacement_id: str, replacement_code: str) -> None:
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v9_binomial_rowonly_") as tmp_name:
        tmp = Path(tmp_name)
        changed = 0
        for task_file in TASK_FILES:
            payload = _read_payload(BASE_ZIP, task_file)
            if task_file == TASK8_FILE:
                rows: list[dict[str, str]] = []
                for line in payload.decode("utf-8-sig").splitlines():
                    if not line.strip():
                        continue
                    row = json.loads(line)
                    if str(row["test_sample_id"]) == replacement_id:
                        row["prediction"] = replacement_code
                        changed += 1
                    rows.append(row)
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            (tmp / task_file).write_bytes(payload)

        if changed != 1:
            raise ValueError(f"Expected exactly one changed row, got {changed}")
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    print(f"Wrote {out_zip}")


def main() -> int:
    base_code = _read_task8_code(BASE_ZIP)
    binomial_code = _replace_once(base_code, OLD_BITWISE_AND_BINOMIAL, FIX_BITWISE_AND_BINOMIAL)
    _write_rowonly_package(
        ROOT / "outputs" / "zhoufui_prediction_8185_task8_v9_bitwise_binomial_rowonly.zip",
        BITWISE_AND_BINOMIAL_ID,
        binomial_code,
    )
    print("\nSuggested next task8 probe:")
    print("outputs\\zhoufui_prediction_8185_task8_v9_bitwise_binomial_rowonly.zip")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
