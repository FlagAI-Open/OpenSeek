#!/usr/bin/env bash
set -euo pipefail

# Run from the repository root inside WSL.
# Downloads Qwen3-4B from ModelScope into a local directory used by the smoke-test runner.

source .venv-wsl/bin/activate

MODEL_DIR="${LOCAL_QWEN3_4B_PATH:-models/Qwen3-4B}"
mkdir -p "$MODEL_DIR"

modelscope download \
  --model Qwen/Qwen3-4B \
  --local_dir "$MODEL_DIR"

test -f "$MODEL_DIR/config.json"
echo "Qwen3-4B is ready at: $MODEL_DIR"
