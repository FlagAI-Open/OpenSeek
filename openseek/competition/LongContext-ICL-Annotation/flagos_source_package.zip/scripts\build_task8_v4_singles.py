from __future__ import annotations

"""Build task8 v4 single-function probe packages.

Strategy: one function per package, probe individually.
Priority order: spectral_norm_eig > least_squares_qr > determinant pair.

Only spectral_norm_eig has a genuine output difference vs the current
implementation (max(abs(eigenvalues)) can differ from matrix_norm(A, ord=2)).
"""

import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"


# ── fixed implementations ──────────────────────────────────────────

FIX_SPECTRAL_NORM_EIG = (
    "def spectral_norm_eig(A, *, out=None):\n"
    "    eigenvalues = torch.linalg.eigvals(A)\n"
    "    # ||A||_2 = max(|lambda|) for eigenvalues lambda of A\n"
    "    spec_norm = torch.max(torch.abs(eigenvalues))\n"
    "    return _out(spec_norm, out)"
)

FIX_LEAST_SQUARES_QR = (
    "def least_squares_qr(A, b, *, mode='reduced', out=None):\n"
    "    Q, R = torch.linalg.qr(A, mode=mode)\n"
    "    # x = R^{-1} Q^H b  (handles b as vector or matrix)\n"
    "    return _out(torch.linalg.solve_triangular(R, Q.mH @ b, upper=True), out)"
)

FIX_DETERMINANT_VIA_QR = (
    "def determinant_via_qr(A, *, mode='reduced', out=None):\n"
    "    Q, R = torch.linalg.qr(A, mode=mode)\n"
    "    diag_R = torch.diagonal(R, dim1=-2, dim2=-1)\n"
    "    det_r = torch.prod(diag_R, dim=-1)\n"
    "    det_q = torch.linalg.det(Q)\n"
    "    return _out(det_q * det_r, out)"
)

FIX_DETERMINANT_LU = (
    "def determinant_lu(A, *, pivot=True, out=None):\n"
    "    P, L, U = torch.linalg.lu(A, pivot=pivot)\n"
    "    diag_U = torch.diagonal(U, dim1=-2, dim2=-1)\n"
    "    det_u = torch.prod(diag_U, dim=-1)\n"
    "    if pivot:\n"
    "        det_p = torch.linalg.det(P)\n"
    "        return _out(det_p * det_u, out)\n"
    "    return _out(det_u, out)"
)

OLD_SPECTRAL_NORM_EIG = (
    "def spectral_norm_eig(A, *, out=None):\n"
    "    return _out(torch.linalg.matrix_norm(A, ord=2), out)"
)

OLD_LEAST_SQUARES_QR = (
    "def least_squares_qr(A, b, *, mode='reduced', out=None):\n"
    "    return _out(torch.linalg.lstsq(A, b).solution, out)"
)

OLD_DETERMINANT_VIA_QR = (
    "def determinant_via_qr(A, *, mode='reduced', out=None):\n"
    "    return _out(torch.linalg.det(A), out)"
)

OLD_DETERMINANT_LU = (
    "def determinant_lu(A, *, pivot=True, out=None):\n"
    "    return _out(torch.linalg.det(A), out)"
)

# Packages in submission priority order
PACKAGES = [
    ("spectral_norm_eig_only", [("spectral_norm_eig", OLD_SPECTRAL_NORM_EIG, FIX_SPECTRAL_NORM_EIG)]),
    ("least_squares_qr_only", [("least_squares_qr", OLD_LEAST_SQUARES_QR, FIX_LEAST_SQUARES_QR)]),
    ("determinant_pair", [
        ("determinant_via_qr", OLD_DETERMINANT_VIA_QR, FIX_DETERMINANT_VIA_QR),
        ("determinant_lu", OLD_DETERMINANT_LU, FIX_DETERMINANT_LU),
    ]),
]


# ── helpers ────────────────────────────────────────────────────────

def _get_ref() -> str:
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    m = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    if not m:
        raise ValueError("Cannot find REFERENCE_CODE")
    return m.group(1)


def _make_zip(out_path: Path, base_zip: Path, task8_rows: list[dict[str, str]]) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v4s_") as tmp_name:
        tmp = Path(tmp_name)
        with zipfile.ZipFile(base_zip) as source:
            for name in source.namelist():
                if name == "openseek-8-v1.jsonl":
                    continue
                (tmp / name).write_bytes(source.read(name))
        payload = "".join(
            json.dumps(r, ensure_ascii=False) + "\n" for r in task8_rows
        ).encode("utf-8")
        (tmp / "openseek-8-v1.jsonl").write_bytes(payload)
        if out_path.exists():
            out_path.unlink()
        created = shutil.make_archive(str(out_path.with_suffix("")), "zip", tmp)
        Path(created).replace(out_path)


# ── main ───────────────────────────────────────────────────────────

def main() -> int:
    ref = _get_ref()
    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))
    import ast, subprocess

    for pkg_name, replacements in PACKAGES:
        print(f"\n=== {pkg_name} ===")
        fixed_ref = ref
        for func_name, old, new in replacements:
            if old not in fixed_ref:
                print(f"  ERROR: old function not found: {func_name}")
                continue
            fixed_ref = fixed_ref.replace(old, new)
            print(f"  Patched: {func_name}")

        # AST verify
        try:
            ast.parse(fixed_ref)
            print("  AST: OK")
        except SyntaxError as e:
            print(f"  AST FAIL: {e}")
            continue

        rows = [
            {"test_sample_id": item["id"], "prediction": fixed_ref}
            for item in task8["test_samples"]
        ]

        out_path = ROOT / "outputs" / f"zhoufui_prediction_task8_v4_{pkg_name}.zip"
        _make_zip(out_path, BASE_ZIP, rows)
        print(f"  Wrote {out_path}")

        subprocess.run([
            "python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_path)
        ])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
