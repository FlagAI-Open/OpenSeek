# WSL Python Inference Fallback

This is a fallback path for the local RTX 5060 Laptop GPU with 8GB VRAM when Docker images cannot be pulled.

It is useful for generating better-than-mock predictions, but the competition FAQ still requires final
reproduction through FlagScale. Keep Docker/FlagScale notes in the report and ask the organizer for a valid
FlagScale image if the published registry is unreachable.

## Setup

In Ubuntu:

```bash
cd /mnt/c/Users/Fe/Desktop/web3/FlagOS
bash scripts/wsl_setup_python_inference.sh
```

If WSL has not been installed on Windows yet, install Ubuntu first from an elevated PowerShell:

```powershell
wsl --install Ubuntu
```

Then reboot if Windows asks for it, open Ubuntu, create the Linux user, and run the setup command above.

## Small-Batch Qwen3 Smoke Test

For an 8GB laptop GPU, do not start with the full dataset. First run a 4-bit, short-context smoke test:

```bash
cd /mnt/c/Users/Fe/Desktop/web3/FlagOS
bash scripts/wsl_run_small_qwen.sh
```

The script runs 3 test samples each for tasks 2, 5, 6, 7, and 8, while still using deterministic answers for
tasks 1, 3, and 4 when those tasks are selected.

Output files:

```text
outputs/local_qwen_smoke_submission.json
outputs/local_qwen_smoke_diagnostics.json
outputs/local_qwen_smoke_jsonl/
outputs/zhoufui_prediction_local_qwen_smoke.zip
```

If memory is insufficient, lower these values in `configs/local_qwen_wsl.yaml`:

- `max_context_chars`
- `k_examples`
- `max_tokens`

If HuggingFace access fails with `Can't load the configuration of 'Qwen/Qwen3-4B'`, download the model from
ModelScope first:

```bash
cd /mnt/c/Users/Fe/Desktop/web3/FlagOS
bash scripts/wsl_download_qwen3_model.sh
bash scripts/wsl_run_small_qwen.sh
```

## Constraints

- Use Qwen3-4B only.
- Do not fine-tune.
- Do not use external or self-built data.
- Use short context and one sample at a time on 8GB VRAM.
