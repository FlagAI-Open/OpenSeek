from __future__ import annotations

import argparse
import json
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LEDGER = ROOT / "docs" / "score_ledger.json"
OFFICIAL_DIR = ROOT / "data" / "official"


def _rooted(path: str) -> Path:
    candidate = Path(path)
    return candidate if candidate.is_absolute() else ROOT / candidate


def _read_zip_records(zip_path: Path) -> dict[str, dict[str, str]]:
    records: dict[str, dict[str, str]] = {}
    with zipfile.ZipFile(zip_path) as archive:
        for name in sorted(item for item in archive.namelist() if item.endswith(".jsonl")):
            task_records: dict[str, str] = {}
            for line in archive.read(name).decode("utf-8-sig").splitlines():
                if not line.strip():
                    continue
                row = json.loads(line)
                task_records[str(row["test_sample_id"])] = str(row["prediction"])
            records[name] = task_records
    return records


def _load_text_lookup() -> dict[str, str]:
    lookup: dict[str, str] = {}
    for path in OFFICIAL_DIR.glob("openseek-*.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        for key in ("examples", "test_samples"):
            for row in data.get(key, []):
                if "id" in row and "input" in row:
                    lookup[str(row["id"])] = " ".join(str(row["input"]).split())
    return lookup


def _diff_counts(base_zip: Path, candidate_zip: Path) -> tuple[Counter[str], list[dict[str, str]]]:
    base = _read_zip_records(base_zip)
    candidate = _read_zip_records(candidate_zip)
    counts: Counter[str] = Counter()
    changes: list[dict[str, str]] = []
    for task_file in sorted(set(base) | set(candidate)):
        base_records = base.get(task_file, {})
        cand_records = candidate.get(task_file, {})
        for sample_id in sorted(set(base_records) | set(cand_records)):
            before = base_records.get(sample_id, "<missing>")
            after = cand_records.get(sample_id, "<missing>")
            if before == after:
                continue
            counts[task_file] += 1
            changes.append(
                {
                    "task_file": task_file,
                    "sample_id": sample_id,
                    "before": before,
                    "after": after,
                }
            )
    return counts, changes


def _fmt_score(value: Any) -> str:
    return "pending" if value is None else f"{float(value):.2f}"


def _preview(value: str, limit: int = 120) -> str:
    compact = value.replace("\n", "\\n")
    if len(compact) <= limit:
        return compact
    return compact[:limit] + "..."


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Analyze platform score ledger against package diffs.")
    parser.add_argument("--ledger", default=str(DEFAULT_LEDGER), help="Path to score ledger JSON.")
    parser.add_argument("--show", type=int, default=3, help="Changed samples to show per experiment.")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    ledger_path = _rooted(args.ledger)
    ledger = json.loads(ledger_path.read_text(encoding="utf-8"))
    text_lookup = _load_text_lookup()
    entries = ledger["experiments"]
    by_package = {entry["package"]: entry for entry in entries}

    current_best = ledger.get("current_best", {})
    goal = float(ledger.get("goal_score", 95.0))
    best_score = float(current_best.get("score", 0.0))
    print(f"Goal: {goal:.2f}")
    print(f"Current best: {_fmt_score(best_score)} | {current_best.get('package', '<unknown>')}")
    print(f"Gap: {goal - best_score:.2f}\n")

    rows: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []
    for entry in entries:
        base_package = entry.get("base_package")
        if not base_package:
            continue
        base_entry = by_package.get(base_package)
        if not base_entry:
            continue
        base_score = base_entry.get("score")
        score = entry.get("score")
        base_zip = _rooted(base_package)
        candidate_zip = _rooted(entry["package"])
        if not base_zip.exists() or not candidate_zip.exists():
            continue
        counts, changes = _diff_counts(base_zip, candidate_zip)
        total_changed = sum(counts.values())
        item = {
            "entry": entry,
            "base": base_entry,
            "counts": counts,
            "changes": changes,
            "total_changed": total_changed,
        }
        if score is None or base_score is None:
            pending.append(item)
        else:
            delta = float(score) - float(base_score)
            item["delta"] = delta
            item["delta_per_change"] = delta / total_changed if total_changed else 0.0
            rows.append(item)

    print("Scored Experiments")
    for item in rows:
        entry = item["entry"]
        counts = ", ".join(f"{task}:{count}" for task, count in sorted(item["counts"].items()))
        print(
            f"- {_fmt_score(item['base']['score'])} -> {_fmt_score(entry['score'])} "
            f"({item['delta']:+.2f}, {item['total_changed']} changed, "
            f"{item['delta_per_change']:+.4f}/change)"
        )
        print(f"  {entry['package']}")
        print(f"  changes: {counts or 'none'}")

    print("\nPending Probes")
    for item in pending:
        entry = item["entry"]
        counts = ", ".join(f"{task}:{count}" for task, count in sorted(item["counts"].items()))
        print(f"- {entry['package']} | {item['total_changed']} changed | {counts or 'none'}")
        for change in item["changes"][: max(0, args.show)]:
            text = text_lookup.get(change["sample_id"], "")
            print(f"  {change['sample_id']}: {_preview(change['before'])} -> {_preview(change['after'])}")
            if text:
                print(f"    {text[:220]}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
