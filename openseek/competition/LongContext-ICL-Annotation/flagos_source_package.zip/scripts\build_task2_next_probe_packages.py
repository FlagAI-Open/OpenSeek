from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_8112 = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"
BASE_8137 = ROOT / "outputs" / "zhoufui_prediction_task2_verb_consensus_safe_delta1.zip"
COT_ZIP = ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_cot_verbs_selected.zip"
STRICT_ZIP = ROOT / "outputs" / "zhoufui_prediction_local_qwen_2_strict_verbs_selected.zip"
TASK2_DATA = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"

TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]
TASK2_FILE = "openseek-2-v1.jsonl"


def _read_rows(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    return {row["test_sample_id"]: str(row["prediction"]).strip() for row in _read_rows(zip_path, task_file)}


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _int_or_none(value: str) -> int | None:
    match = re.search(r"-?\d+", str(value))
    return int(match.group(0)) if match else None


def _load_verb_ids() -> set[str]:
    data = json.loads(TASK2_DATA.read_text(encoding="utf-8"))
    return {
        str(item["id"])
        for item in data["test_samples"]
        if "count the number of verbs" in str(item["input"]).lower()
    }


def _write_zip(base_zip: Path, out_zip: Path, replacements: dict[str, str]) -> None:
    base_rows = _read_rows(base_zip, TASK2_FILE)
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t2_probe_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in base_rows:
                    sid = row["test_sample_id"]
                    rows.append({"test_sample_id": sid, "prediction": replacements.get(sid, str(row["prediction"]))})
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _validate(path: Path) -> None:
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(path)], check=True)


def _safe_transition(base: int, cand: int) -> bool:
    return 0 <= cand <= 6 and abs(cand - base) <= 1


def main() -> int:
    missing = [path for path in [BASE_8112, BASE_8137, COT_ZIP, STRICT_ZIP] if not path.exists()]
    if missing:
        print("Missing required files:")
        for path in missing:
            print(f"  {path}")
        return 2

    verb_ids = _load_verb_ids()
    base_8112 = _read_task(BASE_8112, TASK2_FILE)
    base_8137 = _read_task(BASE_8137, TASK2_FILE)
    cot = _read_task(COT_ZIP, TASK2_FILE)
    strict = _read_task(STRICT_ZIP, TASK2_FILE)

    common_changes: dict[str, tuple[int, int]] = {}
    for sid in verb_ids:
        b = _int_or_none(base_8112.get(sid, ""))
        c = _int_or_none(cot.get(sid, ""))
        s = _int_or_none(strict.get(sid, ""))
        if b is None or c is None or s is None:
            continue
        if c == s and c != b and _safe_transition(b, c):
            common_changes[sid] = (b, c)

    print(f"Common safe changes from 81.12: {len(common_changes)}")
    print("Transitions:", dict(Counter(common_changes.values())))

    # Ablations: these replace the current 81.37 only if their leaderboard score
    # beats it. They intentionally start from the 81.12 base.
    ablation_specs: dict[str, dict[str, str]] = {
        "up_only": {sid: str(c) for sid, (b, c) in common_changes.items() if c > b},
        "down_only": {sid: str(c) for sid, (b, c) in common_changes.items() if c < b},
        "transition_1_to_0": {sid: str(c) for sid, (b, c) in common_changes.items() if (b, c) == (1, 0)},
        "transition_2_to_1": {sid: str(c) for sid, (b, c) in common_changes.items() if (b, c) == (2, 1)},
        "transition_1_to_2": {sid: str(c) for sid, (b, c) in common_changes.items() if (b, c) == (1, 2)},
        "transition_0_to_1": {sid: str(c) for sid, (b, c) in common_changes.items() if (b, c) == (0, 1)},
    }

    for suffix, replacements in ablation_specs.items():
        if not replacements:
            continue
        out = ROOT / "outputs" / f"zhoufui_prediction_task2_probe_{suffix}.zip"
        _write_zip(BASE_8112, out, replacements)
        print(f"{out}: {len(replacements)} replacements from 81.12")
        _validate(out)

    # Extension probes: keep the 81.37 package and add one-prompt-only changes.
    # These are riskier than the common changes and should be tried after ablations.
    cot_only: dict[str, str] = {}
    strict_only: dict[str, str] = {}
    for sid in verb_ids:
        current = _int_or_none(base_8137.get(sid, ""))
        c = _int_or_none(cot.get(sid, ""))
        s = _int_or_none(strict.get(sid, ""))
        base = _int_or_none(base_8112.get(sid, ""))
        if current is None or c is None or s is None or base is None:
            continue
        if c != current and s == current and _safe_transition(current, c):
            cot_only[sid] = str(c)
        if s != current and c == current and _safe_transition(current, s):
            strict_only[sid] = str(s)

    extension_specs = {
        "cot_only_extension": cot_only,
        "strict_only_extension": strict_only,
        "single_prompt_union_extension": {**cot_only, **strict_only},
    }
    for suffix, replacements in extension_specs.items():
        if not replacements:
            continue
        out = ROOT / "outputs" / f"zhoufui_prediction_task2_probe_{suffix}.zip"
        _write_zip(BASE_8137, out, replacements)
        print(f"{out}: {len(replacements)} added replacements on 81.37")
        _validate(out)

    print("\nSuggested next submission order:")
    print("1. outputs\\zhoufui_prediction_task2_probe_down_only.zip")
    print("2. outputs\\zhoufui_prediction_task2_probe_up_only.zip")
    print("3. whichever transition package explains the better one")
    print("4. single-prompt extension packages only after ablation results")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
