from __future__ import annotations

import re
import sys
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont, TTFError
from reportlab.platypus import (
    PageBreak,
    Paragraph,
    Preformatted,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "docs" / "技术报告-zhoufui.md"
DEFAULT_OUTPUT = ROOT / "docs" / "技术报告-zhoufui.pdf"


def register_fonts() -> tuple[str, str]:
    font_candidates = [
        Path(r"C:\Windows\Fonts\NotoSansSC-VF.ttf"),
        Path(r"C:\Windows\Fonts\Deng.ttf"),
        Path(r"C:\Windows\Fonts\Noto Sans SC.ttf"),
        Path(r"C:\Windows\Fonts\Noto Sans SC (TrueType).otf"),
        Path(r"C:\Windows\Fonts\msyh.ttc"),
        Path(r"C:\Windows\Fonts\simhei.ttf"),
    ]
    bold_candidates = [
        Path(r"C:\Windows\Fonts\Dengb.ttf"),
        Path(r"C:\Windows\Fonts\simhei.ttf"),
        Path(r"C:\Windows\Fonts\msyhbd.ttc"),
        Path(r"C:\Windows\Fonts\Noto Sans SC Bold (TrueType).otf"),
    ]

    normal = register_first_supported("ReportCJK", font_candidates)
    bold = register_first_supported("ReportCJKBold", bold_candidates) or normal
    if normal is None:
        raise RuntimeError("No supported Chinese TrueType font found under C:\\Windows\\Fonts.")

    return "ReportCJK", "ReportCJKBold"


def register_first_supported(font_id: str, candidates: list[Path]) -> Path | None:
    for path in candidates:
        if not path.exists():
            continue
        try:
            pdfmetrics.registerFont(TTFont(font_id, str(path)))
            return path
        except TTFError:
            continue
    return None


def escape(text: str) -> str:
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def inline_markup(text: str) -> str:
    text = escape(text)
    text = re.sub(r"`([^`]+)`", r"<font name='Courier'>\1</font>", text)
    text = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", text)
    return text


def build_styles(font_name: str, bold_name: str):
    styles = getSampleStyleSheet()
    styles.add(
        ParagraphStyle(
            name="ReportTitle",
            fontName=bold_name,
            fontSize=22,
            leading=30,
            alignment=TA_CENTER,
            spaceAfter=16,
        )
    )
    styles.add(
        ParagraphStyle(
            name="ReportSubtitle",
            fontName=font_name,
            fontSize=12,
            leading=18,
            alignment=TA_CENTER,
            textColor=colors.HexColor("#333333"),
            spaceAfter=6,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Heading1CJK",
            fontName=bold_name,
            fontSize=15,
            leading=22,
            spaceBefore=10,
            spaceAfter=8,
            keepWithNext=True,
        )
    )
    styles.add(
        ParagraphStyle(
            name="Heading2CJK",
            fontName=bold_name,
            fontSize=12.5,
            leading=18,
            spaceBefore=8,
            spaceAfter=6,
            keepWithNext=True,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BodyCJK",
            fontName=font_name,
            fontSize=10.4,
            leading=17,
            alignment=TA_LEFT,
            firstLineIndent=0,
            spaceAfter=7,
        )
    )
    styles.add(
        ParagraphStyle(
            name="BulletCJK",
            fontName=font_name,
            fontSize=10.2,
            leading=16,
            leftIndent=16,
            firstLineIndent=-10,
            spaceAfter=4,
        )
    )
    styles.add(
        ParagraphStyle(
            name="CodeCJK",
            fontName="Courier",
            fontSize=8.4,
            leading=11.5,
            leftIndent=8,
            rightIndent=8,
            backColor=colors.HexColor("#f4f5f7"),
            borderColor=colors.HexColor("#d8dce3"),
            borderWidth=0.4,
            borderPadding=5,
            spaceBefore=4,
            spaceAfter=8,
        )
    )
    return styles


def flush_paragraph(buffer: list[str], story: list, styles) -> None:
    if not buffer:
        return
    text = " ".join(line.strip() for line in buffer if line.strip())
    if text:
        story.append(Paragraph(inline_markup(text), styles["BodyCJK"]))
    buffer.clear()


def parse_table(lines: list[str], start: int) -> tuple[list[list[str]], int]:
    table_lines = []
    i = start
    while i < len(lines) and lines[i].strip().startswith("|"):
        table_lines.append(lines[i].strip())
        i += 1
    rows = []
    for raw in table_lines:
        cells = [cell.strip() for cell in raw.strip("|").split("|")]
        if all(set(cell) <= {"-", ":", " "} for cell in cells):
            continue
        rows.append(cells)
    return rows, i


def render_table(rows: list[list[str]], story: list, styles, font_name: str, bold_name: str) -> None:
    if not rows:
        return
    max_cols = max(len(r) for r in rows)
    data = []
    for ridx, row in enumerate(rows):
        padded = row + [""] * (max_cols - len(row))
        style = styles["BodyCJK"]
        if ridx == 0:
            style = ParagraphStyle("TableHead", parent=styles["BodyCJK"], fontName=bold_name, textColor=colors.white)
        data.append([Paragraph(inline_markup(cell), style) for cell in padded])

    col_widths = None
    if max_cols == 3:
        col_widths = [4.0 * cm, 5.0 * cm, 7.0 * cm]
    elif max_cols == 2:
        col_widths = [5.0 * cm, 11.0 * cm]

    table = Table(data, colWidths=col_widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(
        TableStyle(
            [
                ("FONTNAME", (0, 0), (-1, -1), font_name),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e79")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#b9c2cc")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f7f9fb")]),
                ("LEFTPADDING", (0, 0), (-1, -1), 5),
                ("RIGHTPADDING", (0, 0), (-1, -1), 5),
                ("TOPPADDING", (0, 0), (-1, -1), 5),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ]
        )
    )
    story.append(table)
    story.append(Spacer(1, 8))


def markdown_to_story(source: Path, styles, font_name: str, bold_name: str) -> list:
    lines = source.read_text(encoding="utf-8").splitlines()
    story: list = []
    paragraph: list[str] = []
    in_code = False
    code_lines: list[str] = []
    title_seen = False
    cover_mode = False
    i = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        if stripped == "<!-- pagebreak -->":
            flush_paragraph(paragraph, story, styles)
            story.append(PageBreak())
            i += 1
            continue

        if stripped.startswith("```"):
            flush_paragraph(paragraph, story, styles)
            if in_code:
                story.append(Preformatted("\n".join(code_lines), styles["CodeCJK"]))
                code_lines.clear()
                in_code = False
            else:
                in_code = True
            i += 1
            continue

        if in_code:
            code_lines.append(line)
            i += 1
            continue

        if not stripped:
            flush_paragraph(paragraph, story, styles)
            i += 1
            continue

        if stripped.startswith("|"):
            flush_paragraph(paragraph, story, styles)
            rows, i = parse_table(lines, i)
            render_table(rows, story, styles, font_name, bold_name)
            continue

        if stripped.startswith("# "):
            flush_paragraph(paragraph, story, styles)
            text = stripped[2:].strip()
            if not title_seen:
                story.append(Spacer(1, 2.0 * cm))
                story.append(Paragraph(inline_markup(text), styles["ReportTitle"]))
                title_seen = True
                cover_mode = True
            else:
                story.append(Paragraph(inline_markup(text), styles["Heading1CJK"]))
            i += 1
            continue

        if stripped.startswith("## "):
            flush_paragraph(paragraph, story, styles)
            cover_mode = False
            story.append(Paragraph(inline_markup(stripped[3:].strip()), styles["Heading1CJK"]))
            i += 1
            continue

        if stripped.startswith("### "):
            flush_paragraph(paragraph, story, styles)
            cover_mode = False
            story.append(Paragraph(inline_markup(stripped[4:].strip()), styles["Heading2CJK"]))
            i += 1
            continue

        if stripped.startswith("- "):
            flush_paragraph(paragraph, story, styles)
            story.append(Paragraph("• " + inline_markup(stripped[2:].strip()), styles["BulletCJK"]))
            i += 1
            continue

        if cover_mode and not stripped.startswith("#"):
            story.append(Paragraph(inline_markup(stripped), styles["ReportSubtitle"]))
            i += 1
            continue

        paragraph.append(line)
        i += 1

    flush_paragraph(paragraph, story, styles)
    return story


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("ReportCJK", 8)
    canvas.setFillColor(colors.HexColor("#555555"))
    canvas.drawString(2 * cm, 1.15 * cm, "FlagOS / OpenSeek LongContext-ICL-Annotation")
    canvas.drawRightString(A4[0] - 2 * cm, 1.15 * cm, f"第 {doc.page} 页")
    canvas.restoreState()


def build_pdf(source: Path, output: Path) -> None:
    font_name, bold_name = register_fonts()
    styles = build_styles(font_name, bold_name)
    story = markdown_to_story(source, styles, font_name, bold_name)

    output.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(output),
        pagesize=A4,
        rightMargin=2 * cm,
        leftMargin=2 * cm,
        topMargin=1.8 * cm,
        bottomMargin=1.8 * cm,
        title="技术报告-zhoufui",
        author="zhoufui",
    )
    doc.build(story, onFirstPage=footer, onLaterPages=footer)


def main() -> int:
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_SOURCE
    output = Path(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_OUTPUT
    build_pdf(source, output)
    print(f"Wrote {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
