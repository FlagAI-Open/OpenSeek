#!/usr/bin/env bash
set -euo pipefail

# Overnight run for the first score-improving package:
# 1. Run local Qwen3-4B on openseek-5 and openseek-6.
# 2. Merge those predictions into the baseline JSONL package.
# 3. Write a timestamped log for review the next morning.

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

mkdir -p outputs/logs
STAMP="$(date +%Y%m%d_%H%M%S)"
LOG="outputs/logs/qwen56_overnight_${STAMP}.log"

echo "Writing log to: $LOG"

{
  echo "Start: $(date)"
  echo "Repository: $ROOT"

  TASK_IDS=openseek-5,openseek-6 OUT_PREFIX=local_qwen_56 bash scripts/wsl_run_qwen_selected.sh

  SELECTED_DIR=outputs/local_qwen_56_jsonl \
  MERGED_DIR=outputs/official_jsonl_qwen56_mix \
  OUT_ZIP=outputs/zhoufui_prediction_qwen56_mix.zip \
    bash scripts/wsl_merge_selected_with_baseline.sh

  echo "Done: $(date)"
  echo "Final package:"
  ls -lh outputs/zhoufui_prediction_qwen56_mix.zip
} 2>&1 | tee "$LOG"
