from __future__ import annotations

import argparse
import json
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]
TASK2_FILE = "openseek-2-v1.jsonl"


PROBES = {
    "top_knot_4to6": {
        "replacements": {
            "openseek-2-292743a4c6804af8af38b6839412c121": "6",
        },
        "note": "man, hair, top, knot, group, fence",
    },
    "noun_safe4": {
        "replacements": {
            "openseek-2-292743a4c6804af8af38b6839412c121": "6",
            "openseek-2-330f61e449cb4bd7a5b7f4ce824b716a": "3",
            "openseek-2-361257474f674da89bb0debafcea7223": "4",
            "openseek-2-b0712af18808431d9ee35b5bc002b4fa": "3",
        },
        "note": "top_knot + blender/stove/flame + traffic/signal/street/night + bed/couch/room",
    },
    "noun_safe5_v2": {
        "replacements": {
            "openseek-2-f4880552d03444ec92910cf37ee88591": "3",
            "openseek-2-79cd7f0a29394ad0b8d699289baf4514": "3",
            "openseek-2-a9a025841f4b4c1c908d29082bc6084d": "3",
            "openseek-2-02f3398e0b244294aacc51b3da43c215": "3",
            "openseek-2-1490c7e9aaf047539905d9508498fefa": "3",
        },
        "note": "dog/boat/paddle + bird/branch/area + zebra/dirt/field + person/sand/water + baby/umbrella/stairs",
    },
    "noun_safe5_v3": {
        "replacements": {
            "openseek-2-4cc871fd5c334ffca6358af1f7ee914a": "3",
            "openseek-2-2a38d08edddb451883f2b83c2d0b3def": "3",
            "openseek-2-b736d7274f694c3a979bc287835f8b18": "3",
            "openseek-2-11e8dd76705844db96f7a445c6be502d": "3",
            "openseek-2-1fe1a81b2474455c8a517342c2edf3ed": "3",
        },
        "note": "engine/train/cars + photo/duck/beak + bunch/salad/sauce + bicyclists/helmets/street + plane/runway/gate",
    },
    "noun_last_push20": {
        "replacements": {
            "openseek-2-1d5713844f21481e8186bea0c3888a86": "4",
            "openseek-2-1a163e6578324fa1a09951a4c7b851e6": "3",
            "openseek-2-98faa6c3673245c18b5a1536b7dfb2e6": "3",
            "openseek-2-807012a4af1b4b3994285439b6c34819": "4",
            "openseek-2-c2d39911e61b40edb623869e9e911fb6": "4",
            "openseek-2-f5f7889db9cb482f81fb069e9157591c": "5",
            "openseek-2-1a87544b74844225b8b84bd4f8c70dc7": "4",
            "openseek-2-4e193e7d64284d3e8bcfc0a3aaed223e": "4",
            "openseek-2-64ab97cb83e44543b803d89f291db57a": "4",
            "openseek-2-836d11acaa674dfd8c61a953ea78531e": "5",
            "openseek-2-cd204c0738244f7daad597e73b29ae48": "4",
            "openseek-2-4d0385ad647b463a94f7b766d7facc58": "4",
            "openseek-2-a1e1621485864a3c87d9523cc3024c90": "5",
            "openseek-2-3fb7b11d48224f66bf0f12b9f0a11d2d": "4",
            "openseek-2-47141cdf6d284a19955942c9cc6c6a1d": "4",
            "openseek-2-4e5cb3df5b76400c832132b1f9bee38d": "4",
            "openseek-2-5e91b016400644e080db28dd68e0abee": "4",
            "openseek-2-852af9ad519448a09c48b425a19637eb": "4",
            "openseek-2-3296baccbfd74b0db6c7ca0511d71748": "4",
            "openseek-2-d06cf1ec1d7344e0b806bd9973a11d8c": "4",
        },
        "note": "final-day wider noun-count push: remaining high-confidence undercounts with compounds, body parts, repeated nouns, and locative nouns",
    },
}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Build a final-day task2 single-row probe on top of the current best.")
    parser.add_argument("--base", required=True, help="Current best submission zip")
    parser.add_argument("--probe", required=True, choices=sorted(PROBES))
    parser.add_argument("--out", required=True, help="Output submission zip")
    return parser


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _read_task2_rows(zip_path: Path) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(TASK2_FILE).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def main() -> int:
    args = build_parser().parse_args()
    base_zip = Path(args.base)
    out_zip = Path(args.out)
    probe = PROBES[args.probe]
    replacements = dict(probe["replacements"])
    base_rows = _read_task2_rows(base_zip)
    base_values = {str(row["test_sample_id"]): str(row["prediction"]) for row in base_rows}
    missing = sorted(set(replacements) - set(base_values))
    if missing:
        raise ValueError(f"Sample ids not found in base package: {missing}")

    with tempfile.TemporaryDirectory(prefix="flagos_final_day_t2_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK2_FILE:
                rows = []
                for row in base_rows:
                    sid = str(row["test_sample_id"])
                    rows.append(
                        {
                            "test_sample_id": sid,
                            "prediction": replacements.get(sid, str(row["prediction"])),
                        }
                    )
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)

        out_zip.parent.mkdir(parents=True, exist_ok=True)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)

    print(f"Wrote {out_zip}")
    for sample_id, replacement in replacements.items():
        print(f"{sample_id}: {base_values[sample_id]} => {replacement}")
    print(f"note: {probe['note']}")
    subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
