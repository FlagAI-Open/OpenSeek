#!/usr/bin/env bash
set -euo pipefail

# Run two task2 verb-only Qwen3-4B prompts. These selected zips are partial
# task2 candidate files used by build_task2_verb_consensus_packages.py.

cd "$(dirname "$0")/.."
source .venv-wsl/bin/activate
export PYTHONPATH="${PYTHONPATH:-src}"

if [[ -z "${LOCAL_QWEN3_4B_PATH:-}" && -f "models/Qwen3-4B/config.json" ]]; then
  export LOCAL_QWEN3_4B_PATH="models/Qwen3-4B"
fi
export LOCAL_QWEN3_4B_PATH="${LOCAL_QWEN3_4B_PATH:-Qwen/Qwen3-4B}"

run_one() {
  local config="$1"
  local prefix="$2"
  local selected_zip="outputs/zhoufui_prediction_${prefix}_selected.zip"
  if [[ -f "${selected_zip}" && "${FORCE_RERUN:-0}" != "1" ]]; then
    echo "Skip existing ${selected_zip}"
    return
  fi
  echo "=== Running ${prefix} with ${config} ==="
  python scripts/run_task2_verb_only.py \
    --config "${config}" \
    --out-prefix "${prefix}" \
    --max-samples "${MAX_SAMPLES:-0}"
}

run_one configs/local_qwen_task2_cot.yaml local_qwen_2_cot_verbs
run_one configs/local_qwen_task2_verb_strict.yaml local_qwen_2_strict_verbs

echo "Task2 verb-only runs complete. Build packages from Windows PowerShell next:"
echo "python scripts/build_task2_verb_consensus_packages.py"
