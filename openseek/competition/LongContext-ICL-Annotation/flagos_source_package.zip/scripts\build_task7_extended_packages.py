from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"
TASK7_FILE = "openseek-7-v1.jsonl"
TASK_FILES = [f"openseek-{index}-v1.jsonl" for index in range(1, 9)]

CANDIDATES: list[tuple[str, Path, bool]] = [
    ("v2", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_v2_selected.zip", False),
    ("v3", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_v3_selected.zip", False),
    ("v4", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_v4_selected.zip", False),
    ("v5", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_v5_selected.zip", False),
    ("category", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_category_first_selected.zip", True),
    ("selfcheck", ROOT / "outputs" / "zhoufui_prediction_local_qwen_7_selfcheck_selected.zip", True),
]


def _norm(value: str) -> str:
    text = str(value).strip().lower()
    text = re.sub(r"^(answer|output)\s*:\s*", "", text)
    text = re.sub(r"^(who|what|where|when|which)\s+(is|are|was|were)\s+", "", text)
    text = text.strip(" \t\r\n\"'.?!;:")
    text = re.sub(r"\s+", " ", text)
    return text


def _safe_answer(value: str) -> bool:
    text = _norm(value)
    if not text or text in {"unknown", "none", "n/a", "null"}:
        return False
    if len(text) > 60 or len(text.split()) > 8:
        return False
    return re.search(r"[^a-z0-9 .,&'\"/\-()]", text) is None


def _read_task(zip_path: Path, task_file: str) -> dict[str, str]:
    with zipfile.ZipFile(zip_path) as archive:
        return {
            json.loads(line)["test_sample_id"]: str(json.loads(line)["prediction"])
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        }


def _read_rows(zip_path: Path, task_file: str) -> list[dict[str, str]]:
    with zipfile.ZipFile(zip_path) as archive:
        return [
            json.loads(line)
            for line in archive.read(task_file).decode("utf-8-sig").splitlines()
            if line.strip()
        ]


def _read_payload(zip_path: Path, task_file: str) -> bytes:
    with zipfile.ZipFile(zip_path) as archive:
        return archive.read(task_file)


def _write_zip(base_zip: Path, out_zip: Path, task7_rows: list[dict[str, str]]) -> None:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_task7_extended_") as tmp_name:
        tmp = Path(tmp_name)
        for task_file in TASK_FILES:
            if task_file == TASK7_FILE:
                payload = "".join(json.dumps(row, ensure_ascii=False) + "\n" for row in task7_rows).encode("utf-8")
            else:
                payload = _read_payload(base_zip, task_file)
            (tmp / task_file).write_bytes(payload)
        if out_zip.exists():
            out_zip.unlink()
        created = shutil.make_archive(str(out_zip.with_suffix("")), "zip", tmp)
        Path(created).replace(out_zip)


def _build_rows(base_rows: list[dict[str, str]], replacements: dict[str, str]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for row in base_rows:
        sample_id = row["test_sample_id"]
        rows.append({"test_sample_id": sample_id, "prediction": replacements.get(sample_id, str(row["prediction"]))})
    return rows


def main() -> int:
    missing = [path for _, path, _ in CANDIDATES if not path.exists()]
    if not BASE_ZIP.exists():
        missing.insert(0, BASE_ZIP)
    if missing:
        print("Missing required files:")
        for path in missing:
            print(f"  {path}")
        print("\nRun first:")
        print("  cd /mnt/c/Users/Fe/Desktop/web3/FlagOS")
        print("  bash scripts/wsl_run_task7_more.sh")
        return 2

    base_rows = _read_rows(BASE_ZIP, TASK7_FILE)
    base_task = {row["test_sample_id"]: str(row["prediction"]) for row in base_rows}
    candidate_maps = [(name, _read_task(path, TASK7_FILE), is_new) for name, path, is_new in CANDIDATES]

    by_sample: dict[str, list[tuple[str, str, bool]]] = defaultdict(list)
    for name, task, is_new in candidate_maps:
        for sample_id, prediction in task.items():
            if _safe_answer(prediction):
                by_sample[sample_id].append((name, _norm(prediction), is_new))

    consensus4: dict[str, str] = {}
    new_confirmed3: dict[str, str] = {}
    new_pair_old_confirmed: dict[str, str] = {}
    new_pair_only: dict[str, str] = {}

    for sample_id, base_prediction in base_task.items():
        items = by_sample.get(sample_id, [])
        if not items:
            continue
        base_norm = _norm(base_prediction)
        counts = Counter(answer for _, answer, _ in items)
        for answer, count in counts.most_common():
            if answer == base_norm:
                break
            supporters = [(name, is_new) for name, value, is_new in items if value == answer]
            new_support = sum(1 for _, is_new in supporters if is_new)
            old_support = sum(1 for _, is_new in supporters if not is_new)
            supporter_names = {name for name, _ in supporters}

            if count >= 4:
                consensus4[sample_id] = answer
            if count >= 3 and new_support >= 1:
                new_confirmed3[sample_id] = answer
            if {"category", "selfcheck"}.issubset(supporter_names) and old_support >= 1:
                new_pair_old_confirmed[sample_id] = answer
            if {"category", "selfcheck"}.issubset(supporter_names):
                new_pair_only[sample_id] = answer
            break

    packages = {
        "consensus4": consensus4,
        "new_confirmed3": new_confirmed3,
        "new_pair_old_confirmed": new_pair_old_confirmed,
        "new_pair_only": new_pair_only,
    }

    for suffix, replacements in packages.items():
        out_zip = ROOT / "outputs" / f"zhoufui_prediction_task7_extended_{suffix}.zip"
        _write_zip(BASE_ZIP, out_zip, _build_rows(base_rows, replacements))
        print(f"{out_zip}: {len(replacements)} replacements")
        for sample_id, value in sorted(replacements.items())[:40]:
            print(f"  {sample_id}: {base_task[sample_id]} => {value}")
        subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_zip)], check=True)

    print("\nSuggested order:")
    print("1. outputs\\zhoufui_prediction_task7_extended_consensus4.zip")
    print("2. outputs\\zhoufui_prediction_task7_extended_new_pair_old_confirmed.zip")
    print("3. outputs\\zhoufui_prediction_task7_extended_new_confirmed3.zip only if #1/#2 improve")
    print("Do not submit new_pair_only unless you intentionally want a high-risk probe.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
