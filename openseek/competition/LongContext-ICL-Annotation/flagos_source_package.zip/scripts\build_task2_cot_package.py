from __future__ import annotations

"""Task2 Chain-of-Thought verb counting improvement.

Strategy: Instead of directly asking Qwen3-4B to count verbs,
ask it to first LIST all verbs, then COUNT them.

Cross-validate on the 2755 official verb examples before building
a submission. Only apply corrections where CoT is consistently better.
"""

import json
import re
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TASK2_DATA = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"

TASK_FILES = [f"openseek-{idx}-v1.jsonl" for idx in range(1, 9)]


def load_task2_data():
    """Load task2 official data, returning verb examples and test samples."""
    data = json.loads(TASK2_DATA.read_text(encoding="utf-8"))
    verb_examples = []
    noun_examples = []
    for e in data["examples"]:
        inp = e["input"]
        label = int(e["output"][0])
        sent_match = re.search(r"Sentence: '([^']+)'", inp)
        sent = sent_match.group(1) if sent_match else ""
        if "verbs" in inp.lower():
            verb_examples.append({"sentence": sent, "label": label})
        else:
            noun_examples.append({"sentence": sent, "label": label})

    test_samples = []
    for s in data["test_samples"]:
        sent_match = re.search(r"Sentence: '([^']+)'", s["input"])
        sent = sent_match.group(1) if sent_match else s["input"]
        is_verb = "verbs" in s["input"].lower()
        test_samples.append({
            "id": s["id"],
            "sentence": sent,
            "task": "verb" if is_verb else "noun",
        })

    return verb_examples, noun_examples, test_samples


def build_cot_prompt(sentence: str, few_shot_examples: list[dict]) -> str:
    """Build a chain-of-thought prompt for verb counting."""
    parts = [
        "Count the number of verbs in the given sentence.",
        "First list every verb you find, then give the total count.",
        "",
    ]

    if few_shot_examples:
        parts.append("Examples:")
        for i, ex in enumerate(few_shot_examples, 1):
            parts.append(f"Example {i}:")
            parts.append(f"Sentence: '{ex['sentence']}'")
            parts.append(f"Verbs: {ex.get('verb_list', '')}")
            parts.append(f"Total verbs: {ex['label']}")
            parts.append("")

    parts.append(f"Sentence: '{sentence}'")
    parts.append("Verbs found (list each verb on a new line, then give count):")

    return "\n".join(parts)


def build_standard_prompt(sentence: str, few_shot_examples: list[dict]) -> str:
    """Build the standard prompt (current approach)."""
    parts = [
        "In this task, you need to count the number of verbs in the given sentence.",
        "",
    ]
    if few_shot_examples:
        parts.append("Examples:")
        for i, ex in enumerate(few_shot_examples, 1):
            parts.append(f"Example {i}:")
            parts.append(f"Sentence: '{ex['sentence']}'")
            parts.append(f"Output: {ex['label']}")
            parts.append("")

    parts.append(f"Sentence: '{sentence}'")
    parts.append("Return only valid JSON with keys: output, confidence, rationale.")

    return "\n".join(parts)


def select_few_shot(
    target_sentence: str,
    verb_examples: list[dict],
    k: int = 6,
) -> list[dict]:
    """Select k most similar verb examples via word overlap."""
    target_words = set(target_sentence.lower().split())
    scored = []
    for ex in verb_examples:
        ex_words = set(ex["sentence"].lower().split())
        overlap = len(target_words & ex_words)
        scored.append((overlap, ex))
    scored.sort(key=lambda x: -x[0])
    return [ex for _, ex in scored[:k]]


def validate_on_examples(
    predictions: dict[str, int],
    verb_examples: list[dict],
) -> dict:
    """If we had predictions on examples, compute accuracy.

    This is a template for cross-validation. Actual inference needs
    Qwen3-4B runs.
    """
    correct = 0
    total = 0
    errors = []
    for ex in verb_examples:
        # predictions would be keyed by sentence
        pred = predictions.get(ex["sentence"])
        if pred is not None:
            total += 1
            if pred == ex["label"]:
                correct += 1
            else:
                errors.append((ex["sentence"], ex["label"], pred))

    return {
        "accuracy": correct / max(total, 1),
        "total": total,
        "correct": correct,
        "errors": errors[:10],
    }


def build_task2_submission(
    corrections: dict[str, str],
    out_path: Path,
    base_zip: Path,
) -> None:
    """Build a full submission zip with task2 corrections applied."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t2_cot_") as tmp_name:
        tmp = Path(tmp_name)
        with zipfile.ZipFile(base_zip) as source:
            for name in source.namelist():
                if name == "openseek-2-v1.jsonl":
                    continue
                (tmp / name).write_bytes(source.read(name))

        # Build corrected task2
        with zipfile.ZipFile(base_zip) as source:
            t2_data = source.read("openseek-2-v1.jsonl").decode("utf-8-sig")
        rows = []
        for line in t2_data.splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            sid = row["test_sample_id"]
            if sid in corrections:
                row["prediction"] = corrections[sid]
            rows.append(row)

        payload = "".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows).encode("utf-8")
        (tmp / "openseek-2-v1.jsonl").write_bytes(payload)

        if out_path.exists():
            out_path.unlink()
        created = shutil.make_archive(str(out_path.with_suffix("")), "zip", tmp)
        Path(created).replace(out_path)


def main() -> int:
    verb_examples, noun_examples, test_samples = load_task2_data()
    print(f"Verb examples: {len(verb_examples)}")
    print(f"Noun examples: {len(noun_examples)}")
    print(f"Test samples: {len(test_samples)}")
    print(f"  Verb test: {sum(1 for t in test_samples if t['task'] == 'verb')}")
    print(f"  Noun test: {sum(1 for t in test_samples if t['task'] == 'noun')}")

    # Show an example CoT prompt
    sample = verb_examples[0]
    few_shot = select_few_shot(sample["sentence"], verb_examples[1:], k=3)
    cot = build_cot_prompt(sample["sentence"], few_shot)
    print("\n=== Example CoT Prompt ===")
    print(cot[:800])

    print("\n=== Cross-Validation Plan ===")
    print("1. Split 2755 verb examples into 5 folds")
    print("2. For each fold, use remaining as few-shot pool")
    print("3. Run Qwen3-4B with CoT prompt on held-out fold")
    print("4. Compare CoT accuracy vs standard prompt accuracy")
    print("5. If CoT is better, apply to verb-count test samples only")
    print("6. Only correct where CoT result differs AND CoT was right on CV")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
