from __future__ import annotations

"""Build task8 v4 linalg shortcut fix packages for tomorrow.

Batch1 (3 fixes): determinant_via_qr, determinant_lu, invert_matrix_lu
Batch2 (4 fixes): least_squares_qr, solve_symmetric_ldl, matrix_power_eig, spectral_norm_eig

Each fix replaces a generic torch.linalg shortcut with the specific
decomposition algorithm described in the official Math section.
"""

import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"

# ── fix implementations ────────────────────────────────────────────

FIX_DETERMINANT_VIA_QR = r'''def determinant_via_qr(A, *, mode='reduced', out=None):
    Q, R = torch.linalg.qr(A, mode=mode)
    diag_R = torch.diagonal(R, dim1=-2, dim2=-1)
    det_r = torch.prod(diag_R, dim=-1)
    # det(Q) = +-1 for orthogonal Q; compute sign from Q
    det_q = torch.linalg.det(Q)
    return _out(det_q * det_r, out)'''


FIX_DETERMINANT_LU = r'''def determinant_lu(A, *, pivot=True, out=None):
    P, L, U = torch.linalg.lu(A, pivot=pivot)
    # det(L) = 1  (unit lower triangular)
    # det(U) = prod(diag(U))
    diag_U = torch.diagonal(U, dim1=-2, dim2=-1)
    det_u = torch.prod(diag_U, dim=-1)
    if pivot:
        # det(P) = +-1 for permutation matrix
        det_p = torch.linalg.det(P)
        return _out(det_p * det_u, out)
    return _out(det_u, out)'''


FIX_INVERT_MATRIX_LU = r'''def invert_matrix_lu(A, *, pivot=True, out=None):
    P, L, U = torch.linalg.lu(A, pivot=pivot)
    n = A.shape[-1]
    I = torch.eye(n, dtype=A.dtype, device=A.device)
    if A.dim() > 2:
        I = I.expand(*A.shape[:-2], n, n)
    # A = P L U  =>  A^{-1} = U^{-1} L^{-1} P^{-1}
    Y = torch.linalg.solve_triangular(U, I, upper=True)       # U^{-1}
    Z = torch.linalg.solve_triangular(L, Y, upper=False, unitriangular=True)  # L^{-1} U^{-1}
    if pivot:
        Z = Z @ P.mT   # P^{-1} = P^T
    return _out(Z, out)'''


FIX_LEAST_SQUARES_QR = r'''def least_squares_qr(A, b, *, mode='reduced', out=None):
    Q, R = torch.linalg.qr(A, mode=mode)
    # x = R^{-1} Q^H b
    return _out(torch.linalg.solve_triangular(R, Q.mH @ b, upper=True), out)'''


FIX_SOLVE_SYMMETRIC_LDL = r'''def solve_symmetric_ldl(A, b, *, hermitian=False, out=None):
    # LDL decomposition: A = L D L^T (or L D L^H for hermitian)
    LD, pivots = torch.linalg.ldl_factor(A, hermitian=hermitian)
    return _out(torch.linalg.ldl_solve(LD, pivots, b), out)'''


FIX_MATRIX_POWER_EIG = r'''def matrix_power_eig(A, k, *, out=None):
    eigenvalues, eigenvectors = torch.linalg.eig(A)
    # A^k = V diag(lambda^k) V^{-1}
    powered_eigvals = eigenvalues ** k
    diag_powered = torch.diag_embed(powered_eigvals)
    result = eigenvectors @ diag_powered @ torch.linalg.inv(eigenvectors)
    return _out(result.real if torch.is_complex(eigenvalues) else result, out)'''


FIX_SPECTRAL_NORM_EIG = r'''def spectral_norm_eig(A, *, out=None):
    eigenvalues = torch.linalg.eigvals(A)
    # ||A||_2 = max(|lambda|) for eigenvalues lambda of A
    spec_norm = torch.max(torch.abs(eigenvalues))
    return _out(spec_norm, out)'''


# ── replacement map ────────────────────────────────────────────────

OLD_FUNCTIONS = {
    "determinant_via_qr": (
        "def determinant_via_qr(A, *, mode='reduced', out=None):\n"
        "    return _out(torch.linalg.det(A), out)"
    ),
    "determinant_lu": (
        "def determinant_lu(A, *, pivot=True, out=None):\n"
        "    return _out(torch.linalg.det(A), out)"
    ),
    "invert_matrix_lu": (
        "def invert_matrix_lu(A, *, pivot=True, out=None):\n"
        "    return _out(torch.linalg.inv(A), out)"
    ),
    "least_squares_qr": (
        "def least_squares_qr(A, b, *, mode='reduced', out=None):\n"
        "    return _out(torch.linalg.lstsq(A, b).solution, out)"
    ),
    "solve_symmetric_ldl": (
        "def solve_symmetric_ldl(A, b, *, hermitian=False, out=None):\n"
        "    return _out(torch.linalg.solve(A, b), out)"
    ),
    "matrix_power_eig": (
        "def matrix_power_eig(A, k, *, out=None):\n"
        "    return _out(torch.linalg.matrix_power(A, int(k)), out)"
    ),
    "spectral_norm_eig": (
        "def spectral_norm_eig(A, *, out=None):\n"
        "    return _out(torch.linalg.matrix_norm(A, ord=2), out)"
    ),
}

FIXES = {
    "determinant_via_qr": FIX_DETERMINANT_VIA_QR,
    "determinant_lu": FIX_DETERMINANT_LU,
    "invert_matrix_lu": FIX_INVERT_MATRIX_LU,
    "least_squares_qr": FIX_LEAST_SQUARES_QR,
    "solve_symmetric_ldl": FIX_SOLVE_SYMMETRIC_LDL,
    "matrix_power_eig": FIX_MATRIX_POWER_EIG,
    "spectral_norm_eig": FIX_SPECTRAL_NORM_EIG,
}

BATCH1 = ["determinant_via_qr", "determinant_lu", "invert_matrix_lu"]
BATCH2 = ["least_squares_qr", "solve_symmetric_ldl", "matrix_power_eig", "spectral_norm_eig"]


# ── helpers ─────────────────────────────────────────────────────────

def _get_ref() -> str:
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    m = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    if not m:
        raise ValueError("Cannot find REFERENCE_CODE")
    return m.group(1)


def _apply_fixes(ref: str, names: list[str]) -> str:
    """Apply fixes to the reference code. Returns modified reference."""
    result = ref
    for name in names:
        old = OLD_FUNCTIONS[name]
        new = FIXES[name]
        if old not in result:
            raise ValueError(f"Old function not found: {name}")
        result = result.replace(old, new)
    return result


def _make_zip(out_path: Path, base_zip: Path, task8_rows: list[dict[str, str]]) -> None:
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_t8_v4_") as tmp_name:
        tmp = Path(tmp_name)
        with zipfile.ZipFile(base_zip) as source:
            for name in source.namelist():
                if name == "openseek-8-v1.jsonl":
                    continue
                (tmp / name).write_bytes(source.read(name))
        payload = "".join(
            json.dumps(r, ensure_ascii=False) + "\n" for r in task8_rows
        ).encode("utf-8")
        (tmp / "openseek-8-v1.jsonl").write_bytes(payload)
        if out_path.exists():
            out_path.unlink()
        created = shutil.make_archive(str(out_path.with_suffix("")), "zip", tmp)
        Path(created).replace(out_path)


# ── main ────────────────────────────────────────────────────────────

def main() -> int:
    ref = _get_ref()
    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))

    for batch_name, batch_funcs in [("batch1", BATCH1), ("batch2", BATCH2)]:
        print(f"\n=== {batch_name}: {batch_funcs} ===")

        fixed_ref = _apply_fixes(ref, batch_funcs)

        # Verify each fix results in compilable code
        import ast
        try:
            ast.parse(fixed_ref)
            print("  AST: OK")
        except SyntaxError as e:
            print(f"  AST ERROR: {e}")
            continue

        rows = [
            {"test_sample_id": item["id"], "prediction": fixed_ref}
            for item in task8["test_samples"]
        ]

        out_path = ROOT / "outputs" / f"zhoufui_prediction_task8_v4_linalg_{batch_name}.zip"
        _make_zip(out_path, BASE_ZIP, rows)
        print(f"  Wrote {out_path}")

        import subprocess
        subprocess.run([
            "python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(out_path)
        ])

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
