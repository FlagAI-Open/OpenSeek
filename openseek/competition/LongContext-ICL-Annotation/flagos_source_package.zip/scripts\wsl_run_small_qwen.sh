#!/usr/bin/env bash
set -euo pipefail

# Run from the repository root inside WSL:
#   cd /mnt/c/Users/Fe/Desktop/web3/FlagOS
#   bash scripts/wsl_run_small_qwen.sh

source .venv-wsl/bin/activate
export PYTHONPATH="${PYTHONPATH:-src}"
if [[ -z "${LOCAL_QWEN3_4B_PATH:-}" && -f "models/Qwen3-4B/config.json" ]]; then
  export LOCAL_QWEN3_4B_PATH="models/Qwen3-4B"
fi
export LOCAL_QWEN3_4B_PATH="${LOCAL_QWEN3_4B_PATH:-Qwen/Qwen3-4B}"

echo "Using Qwen3-4B path: ${LOCAL_QWEN3_4B_PATH}"

python -m flagos_icl.official_cli \
  --config configs/local_qwen_wsl.yaml \
  --data-dir data/official \
  --output outputs/local_qwen_smoke_submission.json \
  --diagnostics outputs/local_qwen_smoke_diagnostics.json \
  --official-jsonl-dir outputs/local_qwen_smoke_jsonl \
  --deterministic-postprocess \
  --task-ids openseek-2,openseek-5,openseek-6,openseek-7,openseek-8 \
  --max-samples-per-task 3

cd outputs/local_qwen_smoke_jsonl
zip -r ../zhoufui_prediction_local_qwen_smoke.zip ./*.jsonl
cd ../..

ls -lh outputs/zhoufui_prediction_local_qwen_smoke.zip
