from __future__ import annotations

"""Build task8 v3 semantic fix packages.

Fixes applied:
- bitwise_and_binomial: add Binomial sampling (was completely missing)
- fused_qr_solve: use QR decomposition + triangular solve (was using lstsq)

Output packages:
- task8_v3_binomial_only.zip
- task8_v3_binomial_qr.zip
"""

import json
import re
import shutil
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REFERENCE_PATH = ROOT / "src" / "flagos_icl" / "task8_torch_reference.py"
TASK8_DATA = ROOT / "data" / "official" / "openseek-8_kernel_generation.json"
BASE_ZIP = ROOT / "outputs" / "zhoufui_prediction_task7_c3_task8_semantic_fix_v2.zip"

TASK_FILES = [f"openseek-{idx}-v1.jsonl" for idx in range(1, 9)]

# ── fix implementations ────────────────────────────────────────────

FIX_BITWISE_AND_BINOMIAL = r'''def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):
    and_result = torch.bitwise_and(input, other)
    info = torch.iinfo(and_result.dtype)
    p = and_result.float() / info.max
    if probs is not None:
        p = probs
    dist = torch.distributions.Binomial(total_count=total_count.float(), probs=p, logits=logits)
    return dist.sample().to(and_result.dtype)'''


FIX_FUSED_QR_SOLVE = r'''def fused_qr_solve(A, b):
    Q, R = torch.linalg.qr(A)
    return torch.linalg.solve_triangular(R, Q.mT @ b, upper=True)'''


# ── helpers ─────────────────────────────────────────────────────────

def _get_current_reference() -> str:
    source = REFERENCE_PATH.read_text(encoding="utf-8")
    match = re.search(r"REFERENCE_CODE = r'''(.*?)'''", source, re.DOTALL)
    if not match:
        raise ValueError("Cannot find REFERENCE_CODE")
    return match.group(1)


def _apply_fix(ref: str, old_func: str, new_func: str) -> str:
    """Replace a function definition in the reference code."""
    if old_func not in ref:
        raise ValueError(f"Function not found in reference:\n{old_func[:80]}...")
    return ref.replace(old_func, new_func)


def _build_task8_rows(task8_data: dict, ref_code: str) -> list[dict[str, str]]:
    """Build task8 JSONL rows using the given reference code."""
    rows = []
    for item in task8_data["test_samples"]:
        rows.append({
            "test_sample_id": item["id"],
            "prediction": ref_code,
        })
    return rows


def _make_zip(out_path: Path, base_zip: Path, task8_rows: list[dict[str, str]]) -> None:
    """Create a full submission zip using base for tasks 1-7 and new task8 rows."""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="flagos_task8_v3_") as tmp_name:
        tmp = Path(tmp_name)
        with zipfile.ZipFile(base_zip) as source:
            for name in source.namelist():
                if name == "openseek-8-v1.jsonl":
                    continue
                (tmp / name).write_bytes(source.read(name))
        payload = "".join(
            json.dumps(row, ensure_ascii=False) + "\n" for row in task8_rows
        ).encode("utf-8")
        (tmp / "openseek-8-v1.jsonl").write_bytes(payload)
        if out_path.exists():
            out_path.unlink()
        created = shutil.make_archive(str(out_path.with_suffix("")), "zip", tmp)
        Path(created).replace(out_path)


# ── main ────────────────────────────────────────────────────────────

def main() -> int:
    base = REFERENCE_PATH.read_text(encoding="utf-8")
    ref = _get_current_reference()
    task8 = json.loads(TASK8_DATA.read_text(encoding="utf-8"))

    # ── binomial-only fix ───────────────────────────────────────────
    old_bitwise = (
        "def bitwise_and_binomial(input, other, total_count, probs=None, logits=None):\n"
        "    return torch.bitwise_and(input, other)"
    )
    ref_binomial = _apply_fix(ref, old_bitwise, FIX_BITWISE_AND_BINOMIAL)
    binomial_rows = _build_task8_rows(task8, ref_binomial)
    out1 = ROOT / "outputs" / "zhoufui_prediction_task8_v3_binomial_only.zip"
    _make_zip(out1, BASE_ZIP, binomial_rows)
    print(f"[1/2] Wrote {out1} (bitwise_and_binomial only)")

    # ── binomial + qr fix ───────────────────────────────────────────
    old_qr = (
        "def fused_qr_solve(A, b):\n"
        "    return torch.linalg.lstsq(A, b).solution"
    )
    ref_both = _apply_fix(ref_binomial, old_qr, FIX_FUSED_QR_SOLVE)
    both_rows = _build_task8_rows(task8, ref_both)
    out2 = ROOT / "outputs" / "zhoufui_prediction_task8_v3_binomial_qr.zip"
    _make_zip(out2, BASE_ZIP, both_rows)
    print(f"[2/2] Wrote {out2} (bitwise_and_binomial + fused_qr_solve)")

    # ── validate ────────────────────────────────────────────────────
    import subprocess
    for pkg in [out1, out2]:
        subprocess.run(["python", str(ROOT / "scripts" / "validate_submission_zip.py"), str(pkg)])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
