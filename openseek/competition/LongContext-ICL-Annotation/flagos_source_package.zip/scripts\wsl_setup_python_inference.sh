#!/usr/bin/env bash
set -euo pipefail

python3 -m venv .venv-wsl
source .venv-wsl/bin/activate
python -m pip install -U pip

# Keep this minimal for 8GB laptop GPUs. Torch wheels are large and may take time.
pip install -U \
  torch \
  transformers \
  accelerate \
  bitsandbytes \
  modelscope \
  sentencepiece \
  protobuf

echo "Environment ready. Activate with:"
echo "source .venv-wsl/bin/activate"
