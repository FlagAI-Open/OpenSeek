from __future__ import annotations

import argparse
import json
import subprocess
import zipfile
from dataclasses import replace
from pathlib import Path

from flagos_icl.config import load_config
from flagos_icl.flagscale_adapter import describe_runtime
from flagos_icl.official_data import load_official_task
from flagos_icl.official_pipeline import OfficialAnnotationPipeline


ROOT = Path(__file__).resolve().parents[1]
TASK2_PATH = ROOT / "data" / "official" / "openseek-2_count_nouns_verbs.json"


def _is_verb_record_text(text: str) -> bool:
    return "count the number of verbs" in text.lower()


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run Qwen3-4B on only task2 verb-count test samples")
    parser.add_argument("--config", required=True, help="Config path")
    parser.add_argument("--out-prefix", required=True, help="Output prefix under outputs/")
    parser.add_argument("--max-samples", type=int, default=0, help="Optional smoke-test limit")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    config = load_config(args.config)
    runtime = describe_runtime(config)
    print(
        "Runtime: "
        f"framework={runtime['framework']}, model={runtime['model_name']}, "
        f"flagscale_available={runtime['flagscale_available']}"
    )
    if config.model.model_name != "Qwen3-4B":
        raise ValueError("Competition constraint: use Qwen3-4B only.")

    task = load_official_task(TASK2_PATH)
    verb_examples = [record for record in task.examples if _is_verb_record_text(record.text)]
    verb_tests = [record for record in task.test_samples if _is_verb_record_text(record.text)]
    if args.max_samples > 0:
        verb_tests = verb_tests[: args.max_samples]
    task = replace(task, examples=verb_examples, test_samples=verb_tests)

    print(f"Verb examples: {len(task.examples)}")
    print(f"Verb test samples: {len(task.test_samples)}")

    runner = OfficialAnnotationPipeline(config)
    task_submission, task_diagnostics = runner.annotate_task(task)

    out_prefix = args.out_prefix
    out_dir = ROOT / "outputs" / f"{out_prefix}_jsonl"
    out_dir.mkdir(parents=True, exist_ok=True)
    jsonl_path = out_dir / "openseek-2-v1.jsonl"
    with jsonl_path.open("w", encoding="utf-8") as file:
        for record in task_submission["records"]:
            file.write(json.dumps(record, ensure_ascii=False) + "\n")

    submission_path = ROOT / "outputs" / f"{out_prefix}_submission.json"
    diagnostics_path = ROOT / "outputs" / f"{out_prefix}_diagnostics.json"
    submission_path.write_text(json.dumps([task_submission], ensure_ascii=False, indent=2), encoding="utf-8")
    diagnostics_path.write_text(json.dumps([task_diagnostics], ensure_ascii=False, indent=2), encoding="utf-8")

    zip_path = ROOT / "outputs" / f"zhoufui_prediction_{out_prefix}_selected.zip"
    if zip_path.exists():
        zip_path.unlink()
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.write(jsonl_path, arcname="openseek-2-v1.jsonl")

    print(f"Wrote {submission_path}")
    print(f"Wrote {diagnostics_path}")
    print(f"Wrote {zip_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
