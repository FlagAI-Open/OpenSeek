#!/usr/bin/env bash
set -euo pipefail

# Run two additional Qwen3-4B task7 prompts for extended consensus.

cd "$(dirname "$0")/.."

run_one() {
  local config="$1"
  local prefix="$2"
  local selected_zip="outputs/zhoufui_prediction_${prefix}_selected.zip"

  if [[ -f "${selected_zip}" && "${FORCE_RERUN:-0}" != "1" ]]; then
    echo "Skip existing ${selected_zip}"
    return
  fi

  echo "=== Running ${prefix} with ${config} ==="
  CONFIG="${config}" \
  TASK_IDS=openseek-7 \
  OUT_PREFIX="${prefix}" \
  bash scripts/wsl_run_qwen_selected.sh
}

run_one configs/local_qwen_task7_category_first.yaml local_qwen_7_category_first
run_one configs/local_qwen_task7_selfcheck.yaml local_qwen_7_selfcheck

echo "Task7 extra runs complete. Build packages from Windows PowerShell next:"
echo "python scripts/build_task7_extended_packages.py"
