#!/usr/bin/env bash
set -euo pipefail

# Merge Qwen task 7 into the current best local package.
# Set BASE_MIX_DIR to choose whether to include qwen2:
#   BASE_MIX_DIR=outputs/official_jsonl_qwen56_mix bash scripts/wsl_merge_qwen7_with_best.sh
#   BASE_MIX_DIR=outputs/official_jsonl_qwen2_qwen56_mix bash scripts/wsl_merge_qwen7_with_best.sh

BASE_MIX_DIR="${BASE_MIX_DIR:-outputs/official_jsonl_qwen2_qwen56_mix}"
QWEN7_DIR="${QWEN7_DIR:-outputs/local_qwen_7_jsonl}"
MERGED_DIR="${MERGED_DIR:-outputs/official_jsonl_qwen7_mix}"
OUT_ZIP="${OUT_ZIP:-outputs/zhoufui_prediction_qwen7_mix.zip}"

rm -rf "$MERGED_DIR"
mkdir -p "$MERGED_DIR"

cp "$BASE_MIX_DIR"/*.jsonl "$MERGED_DIR"/
cp "$QWEN7_DIR"/*.jsonl "$MERGED_DIR"/

rm -f "$OUT_ZIP"
cd "$MERGED_DIR"
zip -r "../$(basename "$OUT_ZIP")" ./*.jsonl
cd - >/dev/null

echo "Merged package: $OUT_ZIP"
ls -lh "$OUT_ZIP"
echo "Line counts:"
wc -l "$MERGED_DIR"/*.jsonl
