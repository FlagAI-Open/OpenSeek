from __future__ import annotations

import argparse
import json
import os
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


def _post_json(url: str, payload: dict[str, Any], api_key: str, timeout: int) -> dict[str, Any]:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.loads(response.read().decode("utf-8"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Smoke-test a FlagScale OpenAI-compatible chat endpoint.")
    parser.add_argument("--base-url", default=os.getenv("OPENAI_BASE_URL", "http://127.0.0.1:9010/v1"))
    parser.add_argument("--api-key", default=os.getenv("OPENAI_API_KEY", "EMPTY"))
    parser.add_argument("--model", default=os.getenv("OPENAI_MODEL", "Qwen3-4B"))
    parser.add_argument("--output", default="outputs/flagscale_logs/api_test.json")
    parser.add_argument("--timeout", type=int, default=120)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    endpoint = args.base_url.rstrip("/") + "/chat/completions"
    payload = {
        "model": args.model,
        "messages": [
            {"role": "system", "content": "You are a concise test assistant."},
            {"role": "user", "content": "Return exactly: flagscale-ok"},
        ],
        "temperature": 0,
        "max_tokens": 16,
    }
    started = time.time()
    try:
        response = _post_json(endpoint, payload, args.api_key, args.timeout)
        ok = "flagscale-ok" in str(response).lower()
        result = {
            "ok": ok,
            "endpoint": endpoint,
            "model": args.model,
            "elapsed_seconds": round(time.time() - started, 3),
            "response": response,
        }
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError) as error:
        result = {
            "ok": False,
            "endpoint": endpoint,
            "model": args.model,
            "elapsed_seconds": round(time.time() - started, 3),
            "error": repr(error),
        }

    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "response"}, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
