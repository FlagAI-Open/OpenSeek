#!/usr/bin/env bash
set -euo pipefail

# Run selected official tasks with the local WSL Qwen3-4B model.
# Examples:
#   TASK_IDS=openseek-5,openseek-6 bash scripts/wsl_run_qwen_selected.sh
#   TASK_IDS=openseek-5 MAX_SAMPLES=20 OUT_PREFIX=test5 bash scripts/wsl_run_qwen_selected.sh

source .venv-wsl/bin/activate
export PYTHONPATH="${PYTHONPATH:-src}"

if [[ -z "${LOCAL_QWEN3_4B_PATH:-}" && -f "models/Qwen3-4B/config.json" ]]; then
  export LOCAL_QWEN3_4B_PATH="models/Qwen3-4B"
fi
export LOCAL_QWEN3_4B_PATH="${LOCAL_QWEN3_4B_PATH:-Qwen/Qwen3-4B}"

TASK_IDS="${TASK_IDS:-openseek-5,openseek-6}"
MAX_SAMPLES="${MAX_SAMPLES:-0}"
OUT_PREFIX="${OUT_PREFIX:-local_qwen_56}"
CONFIG="${CONFIG:-configs/local_qwen_classification.yaml}"

echo "Using Qwen3-4B path: ${LOCAL_QWEN3_4B_PATH}"
echo "Using config: ${CONFIG}"
echo "Running tasks: ${TASK_IDS}"
echo "Max samples per task: ${MAX_SAMPLES}"

python -m flagos_icl.official_cli \
  --config "${CONFIG}" \
  --data-dir data/official \
  --output "outputs/${OUT_PREFIX}_submission.json" \
  --diagnostics "outputs/${OUT_PREFIX}_diagnostics.json" \
  --official-jsonl-dir "outputs/${OUT_PREFIX}_jsonl" \
  --task-ids "${TASK_IDS}" \
  --max-samples-per-task "${MAX_SAMPLES}"

cd "outputs/${OUT_PREFIX}_jsonl"
zip -r "../zhoufui_prediction_${OUT_PREFIX}_selected.zip" ./*.jsonl
cd ../..

ls -lh "outputs/zhoufui_prediction_${OUT_PREFIX}_selected.zip"
