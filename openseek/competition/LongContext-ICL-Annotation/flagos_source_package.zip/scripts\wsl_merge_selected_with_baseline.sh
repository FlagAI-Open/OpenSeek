#!/usr/bin/env bash
set -euo pipefail

# Merge selected task JSONL files into the baseline package.
# Defaults merge outputs/local_qwen_56_jsonl into outputs/official_jsonl_baseline.

BASELINE_DIR="${BASELINE_DIR:-outputs/official_jsonl_baseline}"
SELECTED_DIR="${SELECTED_DIR:-outputs/local_qwen_56_jsonl}"
MERGED_DIR="${MERGED_DIR:-outputs/official_jsonl_qwen56_mix}"
OUT_ZIP="${OUT_ZIP:-outputs/zhoufui_prediction_qwen56_mix.zip}"

rm -rf "$MERGED_DIR"
mkdir -p "$MERGED_DIR"
cp "$BASELINE_DIR"/*.jsonl "$MERGED_DIR"/
cp "$SELECTED_DIR"/*.jsonl "$MERGED_DIR"/

cd "$MERGED_DIR"
zip -r "../$(basename "$OUT_ZIP")" ./*.jsonl
cd - >/dev/null

echo "Merged package: $OUT_ZIP"
ls -lh "$OUT_ZIP"
echo "Line counts:"
wc -l "$MERGED_DIR"/*.jsonl
