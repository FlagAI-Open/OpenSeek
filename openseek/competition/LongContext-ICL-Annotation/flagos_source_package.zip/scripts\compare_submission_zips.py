from __future__ import annotations

import argparse
import json
import zipfile
from pathlib import Path


def _read_zip(path: Path) -> dict[str, dict[str, str]]:
    result: dict[str, dict[str, str]] = {}
    with zipfile.ZipFile(path) as archive:
        for name in sorted(item for item in archive.namelist() if item.endswith(".jsonl")):
            records: dict[str, str] = {}
            for line in archive.read(name).decode("utf-8-sig").splitlines():
                if not line.strip():
                    continue
                record = json.loads(line)
                records[str(record["test_sample_id"])] = str(record["prediction"])
            result[name] = records
    return result


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Compare two OpenSeek submission zip packages")
    parser.add_argument("base_zip", help="Baseline zip path")
    parser.add_argument("candidate_zip", help="Candidate zip path")
    parser.add_argument("--show", type=int, default=3, help="Show this many changed ids per task")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    base = _read_zip(Path(args.base_zip))
    candidate = _read_zip(Path(args.candidate_zip))
    all_names = sorted(set(base) | set(candidate))
    total_changed = 0
    for name in all_names:
        base_records = base.get(name, {})
        candidate_records = candidate.get(name, {})
        ids = sorted(set(base_records) | set(candidate_records))
        changed = [sample_id for sample_id in ids if base_records.get(sample_id) != candidate_records.get(sample_id)]
        total_changed += len(changed)
        print(f"{name}: {len(changed)} changed / {len(ids)} records")
        for sample_id in changed[: max(0, args.show)]:
            before = base_records.get(sample_id, "<missing>").replace("\n", "\\n")
            after = candidate_records.get(sample_id, "<missing>").replace("\n", "\\n")
            print(f"  {sample_id}")
            print(f"    base: {before[:120]}")
            print(f"    cand: {after[:120]}")
    print(f"\nTotal changed records: {total_changed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
