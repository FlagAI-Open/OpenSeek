# 橄榄鲨 LongContext-ICL-Annotation 开源复现包

本包对应 FlagOS 排行榜已评测通过的最高分提交：

- 队伍：橄榄鲨
- 官方成绩：81.72
- 默认预测包：`artifacts/final_prediction.zip`
- 对应提交文件名：`final_submit_20260520_task2_noun_highconf_on_8160.zip`
- 预测包 SHA256：`ec4d57809664d4ba084c374be716f24d579951c4376a5c94232afaff8f436029`

为保证开源 PR 与排行榜成绩一致，默认重建流程只生成 81.72 版本。未在 81.72 主基线上完成官方评测的 Task7 copy-consensus plus2_v3 分支作为可选实验分支保留，但默认不开启，也不计入本包最终成绩。

## 目录结构

```text
.
|-- artifacts/
|   |-- final_prediction.zip                         # 默认最终预测包，匹配官方 81.72 成绩
|   |-- final_submit_20260520_task2_noun_highconf_on_8160.zip
|   |-- base_task2_noun_highconf_8172.zip             # 与 final_prediction.zip 内容一致
|   |-- long_context_evidence_summary.json
|   |-- task2_noun_highconf_summary.json
|-- configs/flagscale/                               # FlagScale 配置模板
|-- docs/experiment_notes/                            # 实验记录
|-- experiments_optional/task7_copy_consensus_plus2_v3/# 未纳入默认最终包的可选实验分支
|-- reports/
|   |-- technical_report_oliveshark.pdf
|   |-- technical_report_oliveshark.md
|-- src/
|   |-- build_final_submission.py                     # 重建默认提交包，可选开启实验分支
|   |-- validate_submission.py                        # 提交格式校验
|   |-- build_long_context_evidence.py                # 30K/16K 长上下文证据链
|   |-- call_flagscale_long_prompt.py                 # FlagScale API 调用工具
|   |-- task2_noun_highconf_rejudge.py                # Task2 高置信 noun 复核实验
|   |-- task7_copy_consensus_rejudge.py               # Task7 多通道复核实验
|   |-- task8_wrapper_repairs.py                      # Task8 通用 wrapper 修复规则
|-- run_rebuild_final.sh                              # 默认重建 81.72 提交包
|-- run_optional_task7_plus2.sh                       # 可选实验分支，不作为最终成绩
|-- start_official_flagscale_service.sh
|-- requirements.txt
```

## 快速校验默认预测包

```bash
python3 src/validate_submission.py artifacts/final_prediction.zip
```

预期结果：`ok: true`，Task1-7 各 500 行，Task8 166 行，无空 prediction。

## 重建排行榜最高分对应包

```bash
bash run_rebuild_final.sh
```

该命令从 `artifacts/base_task2_noun_highconf_8172.zip` 复制并校验得到：

```text
outputs/final_submit_rebuilt.zip
```

默认输出应与 `artifacts/final_prediction.zip` 的 8 个 jsonl 内容一致。zip 文件本身的 SHA 可能因压缩元数据不同而不同，因此以内部 jsonl 字节一致性和 validator 结果作为复现判断。

## 可选 Task7 实验分支

如果需要复现实验阶段的 Task7 copy-consensus plus2_v3，可以运行：

```bash
bash run_optional_task7_plus2.sh
```

该分支来源于 Qwen3-4B 多提示通道复核，Python 仅做格式抽取和一致性门控。它在相邻基线上曾显示正收益，但没有在 81.72 主基线上完成官方评测，因此不作为本开源包默认最终方案。

## 30K / 16K 长上下文证据链

生成每个任务 3 条样本的长上下文证据：

```bash
python3 src/build_long_context_evidence.py --sample-limit 3 --write-prompts \
  --data-dir ../OpenSeek/openseek/competition/LongContext-ICL-Annotation/data \
  --model-dir ../modelscope_cache/Qwen/Qwen3-4B
```

全量生成：

```bash
python3 src/build_long_context_evidence.py --all --write-prompts \
  --data-dir ../OpenSeek/openseek/competition/LongContext-ICL-Annotation/data \
  --model-dir ../modelscope_cache/Qwen/Qwen3-4B
```

证据链记录 token 数、示例 ID、prompt hash、input hash 和 definition hash，用于说明长上下文输入是如何由官方 examples 组织出来的。

## FlagScale / Qwen3-4B 启动

官方环境中推荐设置：

```bash
export QWEN3_PATH=/root/FlagScale/Qwen3-4B
export QWEN3_PORT=9010
bash start_official_flagscale_service.sh
```

启动后可通过 OpenAI-compatible API 调用：

```bash
python3 src/call_flagscale_long_prompt.py \
  --prompt path/to/round1_prompt.txt \
  --api-base http://127.0.0.1:9010/v1 \
  --model /root/FlagScale/Qwen3-4B \
  --out logs/flagscale_round1_call_log.json
```

## 合规边界

- 只使用 OpenSeek 官方数据：`Definition`、`examples`、`test_samples`。
- 不使用外部知识库、搜索引擎、自建训练集或隐藏标签。
- Python 只做格式抽取、一致性门控、公开语义执行检查和打包校验。
- 默认最终包对应官方平台已评测成绩 81.72。
- 可选实验分支必须显式开启，且不作为默认 PR 成绩口径。
