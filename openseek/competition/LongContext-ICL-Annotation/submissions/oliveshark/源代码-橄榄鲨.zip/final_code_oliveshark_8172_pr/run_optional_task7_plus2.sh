#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 src/build_final_submission.py \
  --enable-optional-task7-plus2 \
  --out-zip outputs/optional_task7_plus2_submit.zip \
  --manifest outputs/optional_task7_plus2_manifest.json
python3 src/validate_submission.py outputs/optional_task7_plus2_submit.zip
