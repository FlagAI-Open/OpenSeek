# 2026-05-20 Task7 copy-consensus 分支

## 背景

当前线上最好成绩链路中，Task7 仍是明显低分项。用户要求检查 Task7 是否能产生超过 `final_submit_20260520_task6_jsonY_extra_on_8172.zip` 的方案。

本轮没有使用隐藏答案，也没有引入外部知识库。只使用：

- 当前基准包中的 Task7 预测；
- 官方 Task7 test input；
- Qwen3-4B 的多提示复核结果；
- Python 仅做触发、格式提取和一致性门控。

## 观察

在基准包的 500 条 Task7 预测中，有 54 条预测答案直接出现在题面或类别中。Jeopardy 题里这通常是危险信号，因为线索经常提到一个相关词，再问“this/these”实际指向的对象。

典型例子：

| 题号 | 基准预测 | 多提示一致候选 | 解释 |
|---:|---|---|---|
| 3 | peru | bolivia | Upper Peru 是 Bolivia 的旧称 |
| 36 | gambia | africa | The Gambia 是非洲大陆国家 |
| 49 | son | ibn | Arabic for “son of” 是 ibn |
| 64 | altar stone | stonehenge | Altar Stone 位于 Stonehenge |
| 100 | tri | tristan | 与 Isolde 喝下爱情药的是 Tristan |
| 211 | utilitarianism | jeremy bentham | Father of Utilitarianism |
| 279 | knickerbocker | washington irving | Diedrich Knickerbocker 是 Irving 笔名 |

## 方法

对“当前预测被题面完整包含”的样本，调用四条独立 Qwen3-4B 通道：

1. `zero`：不看当前答案，直接答 Jeopardy；
2. `anticopy`：明确提醒当前候选可能是从题面抄来的干扰项；
3. `slotjson`：要求抽取 answer slot/type，再判断 candidate 是否填槽；
4. `knowledge`：要求用内部知识输出 `best_answer`。

门控规则：

- 候选不能再被题面完整包含；
- 候选不超过 5 个词；
- 候选不能只是把原复制短语扩写一遍；
- 跳过 `ONE WORD ONLY` 这类精确词面题；
- `core_v3`：四通道中至少 3 条一致，或 `zero` 与 `knowledge` 一致；
- `plus2_v3`：在 `core_v3` 基础上，额外接收 `slotjson` 与 `knowledge` 一致且题面属于 `one of these` / `translated from` 的窄模式。

## 候选包

### core_v3

文件：`submissions/final_submit_20260520_task7_copy_consensus_core_v3_on_task6jsonY_8172.zip`

改动 11 条：

- `peru -> bolivia`
- `gambia -> africa`
- `son -> ibn`
- `altar stone -> stonehenge`
- `tri -> tristan`
- `bitter sweet -> noel coward`
- `utilitarianism -> jeremy bentham`
- `schizophrenia -> psychosis`
- `knickerbocker -> washington irving`
- `supai -> havasupai`
- `aha -> american heart association`

预计若 11 条全对，总分约 `+0.275`；若错 2 条，仍约 `+0.175`。

### plus2_v3

文件：`submissions/final_submit_20260520_task7_copy_consensus_plus2_v3_on_task6jsonY_8172.zip`

在 core_v3 上额外改 2 条：

- `dzong -> monastery`
- `aquarius -> water bearer`

预计若 13 条全对，总分约 `+0.325`；若额外 2 条中错 1 条，仍约 `+0.275`。

## 风险

这个分支比 Task6 高置信重判风险更高，因为 Task7 没有本地隐藏答案可估分。公开 examples 上的 copy-trigger 样本很少，不能充分统计验证。但本分支不是普通 prompt 堆叠，而是专门修复“模型抄题面词”的结构性错误；从候选本身看，core_v3 的 11 条比较干净。

提交建议：

1. 若只求稳，提交 `core_v3`。
2. 若目标是冲排名，提交 `plus2_v3`，因为 `monastery` 和 `water bearer` 两条从题面逻辑上也较稳。

## 线上反馈与迁移到 81.72 基线

用户提交反馈：

| 包 | 官方分数 |
|---|---:|
| `final_submit_20260520_task6_jsonY_extra_on_8172.zip` | `81.47` |
| `final_submit_20260520_task7_copy_consensus_plus2_v3_on_task6jsonY_8172.zip` | `81.70` |

结论：`task6_jsonY_extra` 本身回撤，但 Task7 plus2_v3 在同一基线上带来了约 `+0.23` 的真实线上收益。

进一步校验发现：`final_submit_20260520_task6_jsonY_extra_on_8172.zip` 与当前线上最好基线 `final_submit_20260520_task2_noun_highconf_on_8160.zip` 的 `openseek-7-v1.jsonl` 完全一致。因此可以把 Task7 改动迁移到 81.72 基线上，理论上分数约为：

- `81.72 + 0.23 ≈ 81.95`

新生成候选：

| 包 | 改动 | 预计 |
|---|---:|---:|
| `submissions/final_submit_20260520_task2_noun_highconf_plus_task7_core_v3.zip` | 11 条 Task7 | 约 `81.90` 左右 |
| `submissions/final_submit_20260520_task2_noun_highconf_plus_task7_plus2_v3.zip` | 13 条 Task7 | 约 `81.95` 左右 |

优先提交建议：`final_submit_20260520_task2_noun_highconf_plus_task7_plus2_v3.zip`。
