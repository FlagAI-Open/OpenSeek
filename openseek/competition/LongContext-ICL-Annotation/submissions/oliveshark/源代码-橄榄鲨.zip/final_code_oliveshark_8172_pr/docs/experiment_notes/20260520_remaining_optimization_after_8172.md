# 2026-05-20 81.72 后续提分路线

当前官方最佳：`81.72`，排行榜第 10，距离第 9 名 `81.85` 还差 `0.13`。

换算：总分再涨 `0.13`，约等于单个 500 样本任务净多对 6 条左右。

## 最值得尝试：Task6 第二层 N -> Y

上一轮 Task6 `stable N -> Y` 已经把分数从 `80.97` 拉到 `81.52`，证明该方向有效。

当前 Task6 raw 里还有：

- `26` 条：当前基线为 `N`，strict 判 `N`，JSON 复核判 `Y`。
- `11` 条：当前基线为 `Y`，strict 和 JSON 都判 `N`。

其中更值得优先提交的是 `jsonY_extra`：继续扩展 `N -> Y`，方向与已验证收益一致。

生成包：

1. `submissions/final_submit_20260520_task6_jsonY_extra_on_8172.zip`
   - 基于 `81.72`。
   - 改动 `26` 条，全部为额外 `N -> Y`。
   - 预期：`+0.1 ~ +0.5`，目标是跨过 `81.85`。
   - 风险：JSON-only 信号弱于两轮一致信号。

2. `submissions/final_submit_20260520_task6_baseY_stableN_on_8172.zip`
   - 改动 `11` 条，`Y -> N`。
   - 风险更高，因为上一轮验证显示模型判 `N` 的精度不如判 `Y`。

3. `submissions/final_submit_20260520_task6_jsonY_extra_plus_baseYstableN_on_8172.zip`
   - 改动 `37` 条，同时做上面两种。
   - 不建议优先，除非提交机会充足。

## 其他路线判断

### Task2 noun 继续拆包

`±1` 包只从 `81.60` 到 `81.72`，说明方向正但迁移弱。可以继续拆 `down1/up1/特征门控`，但预计多为小幅波动。

### Task8 no_ref

full7 只贡献 `+0.08`，继续盲补 no_ref 不划算。除非先补 reference harness，否则不优先。

### Task7

多轮与 temperature 探针显示候选池 oracle 有空间，但模型裁决弱。短期不适合拿提交次数赌。

## 当前提交优先级

1. `final_submit_20260520_task6_jsonY_extra_on_8172.zip`
2. `final_submit_20260520_task2_noun_highconf_down1_on_8160.zip` 或 Task2 更窄拆包
3. `final_submit_20260520_task6_baseY_stableN_on_8172.zip`
4. Task8 reference 修复线
