#!/usr/bin/env bash
set -euo pipefail

# Start Qwen3-4B through FlagScale on FlagOS OnlineLab.
# Required environment if different from defaults:
#   QWEN3_PATH       Path to Qwen3-4B weights, default /root/FlagScale/Qwen3-4B
#   QWEN3_PORT       OpenAI-compatible API port, default 9010
#   FLAG_SCALE_ROOT  FlagScale checkout path, default /root/FlagScale
#   FLAG_SCALE_CONF  FlagScale serve yaml, default this package's configs/flagscale/serve.yaml

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export QWEN3_PATH="${QWEN3_PATH:-/root/FlagScale/Qwen3-4B}"
export QWEN3_PORT="${QWEN3_PORT:-9010}"
export FLAG_SCALE_ROOT="${FLAG_SCALE_ROOT:-/root/FlagScale}"
export FLAG_SCALE_CONF="${FLAG_SCALE_CONF:-${SCRIPT_DIR}/configs/flagscale/serve.yaml}"
export FLAG_SCALE_LOG="${FLAG_SCALE_LOG:-${SCRIPT_DIR}/logs/flagscale_qwen3_4b_${QWEN3_PORT}.log}"
mkdir -p "$(dirname "$FLAG_SCALE_LOG")"

set +u
source /usr/local/Ascend/ascend-toolkit/set_env.sh 2>/dev/null || true
source /usr/local/Ascend/nnal/atb/set_env.sh 2>/dev/null || true
set -u

cd "$FLAG_SCALE_ROOT"
nohup flagscale serve qwen3 -c "$FLAG_SCALE_CONF" > "$FLAG_SCALE_LOG" 2>&1 &
echo $! > "${FLAG_SCALE_LOG}.pid"
echo "FlagScale Qwen3-4B service starting on port ${QWEN3_PORT}. PID=$(cat "${FLAG_SCALE_LOG}.pid")"
echo "Config: ${FLAG_SCALE_CONF}"
echo "Log: ${FLAG_SCALE_LOG}"
