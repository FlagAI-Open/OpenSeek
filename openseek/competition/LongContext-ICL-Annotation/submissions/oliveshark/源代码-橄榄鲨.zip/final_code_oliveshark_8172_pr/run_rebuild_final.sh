#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 src/build_final_submission.py
python3 src/validate_submission.py outputs/final_submit_rebuilt.zip
