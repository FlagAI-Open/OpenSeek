# Task7 copy-consensus plus2_v3 optional branch

该目录保存一个未纳入默认最终包的 Task7 实验分支。该分支基于 Qwen3-4B 多提示通道复核，目标是修正模型把题面词直接复制成答案的错误。

合规口径：

- 不使用隐藏答案。
- 不使用外部知识库。
- Python 只做格式抽取和一致性门控。
- 该分支没有在 81.72 主基线上完成官方评测，因此默认不开启，也不作为本 PR 对应排行榜成绩。

运行方式见项目根目录 `run_optional_task7_plus2.sh`。
