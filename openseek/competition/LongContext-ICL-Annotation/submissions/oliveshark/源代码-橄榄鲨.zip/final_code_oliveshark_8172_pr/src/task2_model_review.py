#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, time, zipfile
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "OpenSeek/openseek/competition/LongContext-ICL-Annotation/data/openseek-2_count_nouns_verbs.json"
TASK_FILE = "openseek-2-v1.jsonl"


def read_zip_task2(zp: Path) -> dict[str, str]:
    with zipfile.ZipFile(zp) as zf:
        rows = [json.loads(x) for x in zf.read(TASK_FILE).decode("utf-8").splitlines() if x.strip()]
    return {r["test_sample_id"]: str(r.get("prediction", "")).strip() for r in rows}


def call_qwen_chat(api_base: str, model: str, prompt: str, max_tokens: int, temperature: float, timeout: int) -> str:
    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": "You are Qwen3-4B used for competition-compliant data annotation review. Output strict JSON only."},
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "chat_template_kwargs": {"enable_thinking": False},
    }
    req = Request(api_base.rstrip("/") + "/chat/completions", data=json.dumps(payload).encode("utf-8"), headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=timeout) as resp:
        data = json.loads(resp.read().decode("utf-8"))
    return data["choices"][0]["message"]["content"]


def clean_json(text: str) -> dict:
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S)
    m = re.search(r"\{.*\}", text, flags=re.S)
    if not m:
        return {"raw": text, "parse_ok": False}
    try:
        obj = json.loads(m.group(0))
        obj["parse_ok"] = True
        return obj
    except Exception:
        return {"raw": text, "parse_ok": False}


def build_prompt(definition: str, examples: list[dict], sample: dict, base_pred: str, candidate_pred: str) -> str:
    # Use only official examples. Pick compact examples matching noun/verb target and answer neighborhood.
    target = "nouns" if "number of nouns" in sample["input"].lower() else "verbs"
    chosen = []
    for ex in examples:
        if target not in ex.get("input", "").lower():
            continue
        out = str(ex.get("output", [""])[0])
        if out in {base_pred, candidate_pred} or len(chosen) < 8:
            chosen.append(ex)
        if len(chosen) >= 16:
            break
    ex_text = "\n".join(f"Example {i+1}:\nInput: {e['input']}\nOutput: {e['output'][0]}" for i, e in enumerate(chosen))
    return f"""Task definition:\n{definition}\n\nOfficial examples:\n{ex_text}\n\nCurrent test input:\n{sample['input']}\n\nTwo candidate labels are available. You must choose only one of them.\nCandidate A: {base_pred}\nCandidate B: {candidate_pred}\n\nReview rule:\n- Count only the requested part of speech in the quoted sentence.\n- Do not use external knowledge.\n- Do not invent a third answer.\n- If unsure, choose the more conservative label and explain why.\n\nOutput strict JSON:\n{{"choice":"A or B", "prediction":"{base_pred} or {candidate_pred}", "rationale":"short reason listing counted words"}}\n"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-zip", default="submissions/final_submit_20260515_task2_highcount_manual_conservative_on_task8fallback.zip")
    ap.add_argument("--candidate-zip", default="submissions/final_submit_20260519_task8_fused_semantic_v7_on_v6.zip")
    ap.add_argument("--api-base", required=True)
    ap.add_argument("--model", default="Qwen3-4B")
    ap.add_argument("--out", default="final_reproducible/task2_model_review_decisions.json")
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--max-tokens", type=int, default=512)
    ap.add_argument("--timeout", type=int, default=180)
    args = ap.parse_args()

    base_zip = ROOT / args.base_zip
    cand_zip = ROOT / args.candidate_zip
    data = json.loads(DATA.read_text(encoding="utf-8"))
    samples = {s["id"]: s for s in data["test_samples"]}
    definition = "\n".join(data.get("Definition", []))
    base = read_zip_task2(base_zip)
    cand = read_zip_task2(cand_zip)
    diffs = [(sid, base[sid], cand[sid]) for sid in sorted(cand) if base.get(sid) != cand.get(sid)]
    decisions = []
    for sid, base_pred, cand_pred in diffs:
        prompt = build_prompt(definition, data["examples"], samples[sid], base_pred, cand_pred)
        prompt_hash = hashlib.sha256(prompt.encode("utf-8")).hexdigest()
        try:
            raw = call_qwen_chat(args.api_base, args.model, prompt, args.max_tokens, args.temperature, args.timeout)
            parsed = clean_json(raw)
            pred = str(parsed.get("prediction", "")).strip()
            accepted = parsed.get("parse_ok") and pred in {base_pred, cand_pred}
            status = "accepted" if accepted else "parse_or_choice_failed"
        except (HTTPError, URLError, TimeoutError, Exception) as e:
            raw = ""
            parsed = {"parse_ok": False, "error": type(e).__name__ + ": " + str(e)}
            pred = base_pred
            status = "request_failed"
        decisions.append({
            "test_sample_id": sid,
            "input_sha256": hashlib.sha256(samples[sid]["input"].encode("utf-8")).hexdigest(),
            "base_prediction": base_pred,
            "candidate_prediction": cand_pred,
            "selected_prediction": pred if pred in {base_pred, cand_pred} else base_pred,
            "status": status,
            "model": args.model,
            "api_base": args.api_base,
            "prompt_sha256": prompt_hash,
            "raw_response": raw,
            "parsed": parsed,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        print(json.dumps(decisions[-1], ensure_ascii=False), flush=True)
    out = ROOT / args.out
    out.write_text(json.dumps({"base_zip": args.base_zip, "candidate_zip": args.candidate_zip, "decisions": decisions}, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {out}")


if __name__ == "__main__":
    main()
