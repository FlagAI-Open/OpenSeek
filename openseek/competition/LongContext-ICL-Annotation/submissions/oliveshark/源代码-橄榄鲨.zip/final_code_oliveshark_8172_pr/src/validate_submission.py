#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, zipfile
from pathlib import Path

EXPECTED = {**{f"openseek-{i}-v1.jsonl": 500 for i in range(1, 8)}, "openseek-8-v1.jsonl": 166}


def iter_rows(raw: bytes):
    for line_no, line in enumerate(raw.decode("utf-8").splitlines(), 1):
        if not line.strip():
            continue
        yield line_no, json.loads(line)


def validate(path: str | Path) -> dict:
    path = Path(path)
    bad = []
    summary = {}
    with zipfile.ZipFile(path) as zf:
        names = sorted(n for n in zf.namelist() if n.endswith(".jsonl"))
        if names != sorted(EXPECTED):
            bad.append({"kind": "names", "actual": names, "expected": sorted(EXPECTED)})
        for name, expected_rows in EXPECTED.items():
            rows = list(iter_rows(zf.read(name)))
            summary[name] = {
                "rows": len(rows),
                "empty_prediction": sum(1 for _, r in rows if not str(r.get("prediction", "")).strip()),
            }
            if len(rows) != expected_rows:
                bad.append({"file": name, "kind": "row_count", "actual": len(rows), "expected": expected_rows})
            seen = set()
            for line_no, row in rows:
                keys = set(row)
                if keys != {"test_sample_id", "prediction"}:
                    bad.append({"file": name, "line": line_no, "kind": "keys", "keys": sorted(keys)})
                sid = row.get("test_sample_id")
                if sid in seen:
                    bad.append({"file": name, "line": line_no, "kind": "duplicate_id", "test_sample_id": sid})
                seen.add(sid)
                if not str(row.get("prediction", "")).strip():
                    bad.append({"file": name, "line": line_no, "kind": "empty_prediction", "test_sample_id": sid})
    return {"ok": not bad, "bad_count": len(bad), "bad_preview": bad[:50], "summary": summary}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("zip_path")
    args = ap.parse_args()
    print(json.dumps(validate(args.zip_path), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
