#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import time
import urllib.request
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser(description="Call a FlagScale/vLLM OpenAI-compatible endpoint with a saved long prompt and record evidence.")
    ap.add_argument("--prompt", required=True, help="Prompt text file path.")
    ap.add_argument("--api-base", default="http://127.0.0.1:9010/v1")
    ap.add_argument("--model", default="/root/FlagScale/Qwen3-4B")
    ap.add_argument("--max-tokens", type=int, default=128)
    ap.add_argument("--temperature", type=float, default=0.0)
    ap.add_argument("--out", required=True, help="Evidence JSON output path.")
    args = ap.parse_args()

    prompt_path = Path(args.prompt)
    prompt = prompt_path.read_text(encoding="utf-8")
    payload = {
        "model": args.model,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": args.temperature,
        "max_tokens": args.max_tokens,
    }
    url = args.api_base.rstrip("/") + "/chat/completions"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    t0 = time.time()
    raw = urllib.request.urlopen(req, timeout=600).read().decode("utf-8")
    elapsed = time.time() - t0
    obj = json.loads(raw)
    content = obj["choices"][0]["message"].get("content", "")
    record = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "api_base": args.api_base,
        "model": args.model,
        "prompt_path": str(prompt_path),
        "prompt_bytes": len(prompt.encode("utf-8")),
        "prompt_sha256": hashlib.sha256(prompt.encode("utf-8")).hexdigest(),
        "usage": obj.get("usage"),
        "elapsed_sec": round(elapsed, 3),
        "response_preview": content[:500],
        "response_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        "finish_reason": obj["choices"][0].get("finish_reason"),
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(record, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
