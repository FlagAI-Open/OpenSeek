#!/usr/bin/env python3
from __future__ import annotations
import argparse, collections, hashlib, json, os, re, time, urllib.request, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'OpenSeek/openseek/competition/LongContext-ICL-Annotation/data/openseek-2_count_nouns_verbs.json'
CURRENT_ZIP=ROOT/'submissions/final_submit_20260520_task6_stable_n_to_y_plus_task8_full7_on_8097.zip'
OUT=ROOT/'experiments/task2_noun_highconf_rejudge_20260520'; OUT.mkdir(parents=True,exist_ok=True)
BASE_URL=os.environ.get('LMSTUDIO_BASE_URL','http://localhost:1234/v1')
MODEL=os.environ.get('LMSTUDIO_MODEL','qwen3-4b')

def call(prompt,max_tokens=240):
    payload={'model':MODEL,'messages':[{'role':'system','content':'/no_think\nYou are a precise English POS annotation reviewer. Return only requested JSON/integer.'},{'role':'user','content':prompt}], 'temperature':0.0, 'max_tokens':max_tokens, 'stream':False, 'chat_template_kwargs':{'enable_thinking':False}}
    req=urllib.request.Request(BASE_URL.rstrip()+'/chat/completions',data=json.dumps(payload).encode(),headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=180) as r:
        return json.loads(r.read().decode())['choices'][0]['message']['content']

def sentence(inp):
    m=re.search(r"Sentence:\s*'(.*?)'",inp,re.S); return m.group(1) if m else inp

def is_noun_query(inp): return 'number of nouns' in inp.lower()
def norm_int(s):
    s=re.sub(r'<think>.*?</think>','',str(s),flags=re.S|re.I)
    m=re.search(r'"answer"\s*:\s*(-?\d+)',s,re.I)
    if m: return m.group(1)
    nums=re.findall(r'-?\d+',s); return nums[-1] if nums else ''

def parse_json(raw):
    s=re.sub(r'<think>.*?</think>','',str(raw),flags=re.S|re.I).strip()
    m=re.search(r'\{.*\}',s,re.S)
    if m:
        try: return json.loads(m.group(0))
        except Exception: pass
    return {}

def noun_features(inp):
    s=sentence(inp).lower(); toks=re.findall(r"[a-z]+(?:'[a-z]+)?",s)
    feats=[]
    if any(w in toks for w in ['top','side','front','back','background','inside','outside','middle','center','corner','edge','end']): feats.append('location_noun')
    if any(w in toks for w in ['traffic','baseball','tennis','soccer','street','fire','wine','cell','video','game','surf','snow','air','train','bathroom','kitchen','living','parking']): feats.append('compound_noun_modifier')
    if 'with' in toks or 'of' in toks or 'on' in toks or 'in' in toks: feats.append('pp_chain')
    if 'and' in toks or 'or' in toks: feats.append('coordination')
    if len(toks)>=11: feats.append('long')
    if any(w.endswith('ing') or w.endswith('ed') for w in toks): feats.append('participle_noise')
    return feats

def select_examples(examples, query, k=14, exclude=None):
    qf=set(noun_features(query)); qwords=set(re.findall(r"[a-z]+",sentence(query).lower()))
    scored=[]
    for e in examples:
        if exclude and e['id']==exclude: continue
        if not is_noun_query(e['input']): continue
        ew=set(re.findall(r"[a-z]+",sentence(e['input']).lower()))
        ef=set(noun_features(e['input']))
        sc=len(qwords&ew)/max(1,len(qwords|ew))+0.4*len(qf&ef)
        # prefer examples with higher noun counts to remind model not to undercount compounds
        try: sc += 0.04*int(e['output'][0])
        except Exception: pass
        scored.append((sc,e))
    scored.sort(key=lambda x:x[0],reverse=True)
    chosen=[]; used=set()
    # balanced count anchors + nearest tail
    for want in ['2','3','4','5','6','7']:
        for _,e in scored:
            if e['id'] in used: continue
            if str(e['output'][0])==want:
                chosen.append(e); used.add(e['id']); break
    for _,e in scored:
        if len(chosen)>=k: break
        if e['id'] not in used:
            chosen.append(e); used.add(e['id'])
    return chosen[:k]

def prompt1(inp, demos):
    demo='\n\n'.join(f"Input: {e['input']}\nOutput: {e['output'][0]}" for e in demos)
    return f'''Task: Count nouns in the quoted sentence.

Important noun-counting rules matching the official examples:
- Count only words inside the quoted sentence.
- Count common nouns and proper nouns.
- Count noun-like words used as compound modifiers: traffic sign counts traffic and sign; tennis court counts tennis and court; baseball game counts baseball and game.
- Count location/object nouns such as top, side, front, background, field, room, table when they name a thing/place.
- Do not count determiners, adjectives, prepositions, pronouns, or verbs.
- -ing/-ed words are usually verbs/adjectives unless they name a thing.

Official examples:
{demo}

Current input:
{inp}

Return JSON only:
{{"nouns":["word1","word2"],"answer":0,"confidence":"high|medium|low"}}'''

def prompt2(inp, first_answer, first_raw, demos):
    demo='\n'.join(f"{sentence(e['input'])} -> {e['output'][0]}" for e in demos[:10])
    return f'''Second-pass conservative noun review.

Official example style:
{demo}

Current sentence:
{sentence(inp)}
First answer: {first_answer}
First raw: {first_raw[:600]}

Check only whether the first answer missed an obvious noun-like compound modifier or location/object noun.
If uncertain, repeat the first answer unchanged.
Return JSON only: {{"answer":0,"change":"same|up1|down1","reason":"short"}}'''

def rejudge(inp, examples, exclude=None):
    demos=select_examples(examples,inp,exclude=exclude)
    raw1=call(prompt1(inp,demos),260); ans1=norm_int(raw1); obj1=parse_json(raw1); conf=str(obj1.get('confidence','')).lower()
    raw2=call(prompt2(inp,ans1,raw1,demos),160); ans2=norm_int(raw2); obj2=parse_json(raw2); change=str(obj2.get('change','')).lower(); reason=str(obj2.get('reason',''))[:240]
    final=ans1
    stable=(ans1==ans2 and ans1.isdigit())
    # High confidence for candidate replacement: both rounds agree, or second says same and first high confidence.
    high=stable and (conf=='high' or change in {'same',''})
    return {'answer1':ans1,'answer2':ans2,'prediction':final if final.isdigit() else '', 'raw1':raw1, 'raw2':raw2, 'confidence':conf, 'change':change, 'reason':reason, 'stable':stable, 'high_conf':high, 'features':noun_features(inp)}

def validate(starts, n):
    data=json.load(open(DATA)); examples=data['examples']; rows=[]
    for st in starts:
        cand=[e for e in examples[st:st+n] if is_noun_query(e['input'])]
        for e in cand:
            r=rejudge(e['input'],examples,exclude=e['id']); gold=str(e['output'][0]); r.update({'idx':examples.index(e),'id':e['id'],'input':e['input'],'gold':gold,'ok':r['prediction']==gold})
            rows.append(r); print('[VAL]',len(rows),'gold',gold,'pred',r['prediction'],'high',r['high_conf'],flush=True)
    summ=summarize(rows)
    (OUT/'noun_validate.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows)+'\n')
    (OUT/'noun_validate_summary.json').write_text(json.dumps(summ,ensure_ascii=False,indent=2))
    print(json.dumps(summ,ensure_ascii=False,indent=2))

def summarize(rows):
    hc=[r for r in rows if r.get('high_conf')]
    return {'n':len(rows),'acc':sum(r['ok'] for r in rows)/len(rows) if rows else None,'high_n':len(hc),'high_acc':sum(r['ok'] for r in hc)/len(hc) if hc else None,'pred_dist':dict(collections.Counter(r['prediction'] for r in rows)),'gold_dist':dict(collections.Counter(r.get('gold') for r in rows))}

def read_zip_task2(zp):
    with zipfile.ZipFile(zp) as z: return [json.loads(x) for x in z.read('openseek-2-v1.jsonl').decode().splitlines() if x.strip()]

def write_zip(out_zip, task2_rows):
    with zipfile.ZipFile(CURRENT_ZIP) as zin, zipfile.ZipFile(out_zip,'w',compression=zipfile.ZIP_DEFLATED) as zout:
        for name in zin.namelist():
            if name=='openseek-2-v1.jsonl': zout.writestr(name,'\n'.join(json.dumps(r,ensure_ascii=False) for r in task2_rows)+'\n')
            else: zout.writestr(name,zin.read(name))

def full():
    data=json.load(open(DATA)); examples=data['examples']; tests={s['id']:s for s in data['test_samples']}
    base_rows=read_zip_task2(CURRENT_ZIP); out=[]; raw=[]; changed=0
    for i,br in enumerate(base_rows,1):
        sid=br['test_sample_id']; base=str(br['prediction']); inp=tests[sid]['input']; pred=base; rr=None
        if is_noun_query(inp):
            rr=rejudge(inp,examples)
            cand=rr['prediction']
            # Conservative gate: only accept high-confidence noun result within +/-1 of current.
            if rr['high_conf'] and cand.isdigit() and abs(int(cand)-int(base))<=1 and cand!=base:
                pred=cand; changed+=1
        out.append({'test_sample_id':sid,'prediction':pred})
        if rr: raw.append({'test_sample_id':sid,'input':inp,'base':base,'candidate':rr['prediction'],'prediction':pred,'changed':pred!=base,**rr})
        if i%50==0: print('[FULL]',i,'changed',changed,flush=True)
    (OUT/'noun_full_raw.jsonl').write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in raw)+'\n')
    variants=[]
    # already built conservative all high +/-1
    out_zip=ROOT/'submissions/final_submit_20260520_task2_noun_highconf_on_8160.zip'; write_zip(out_zip,out); variants.append(str(out_zip))
    # up-only variant: validation suggests undercount is common, reduce risk
    out2=[]; ch2=0
    raw_by={r['test_sample_id']:r for r in raw}
    for br in base_rows:
        sid=br['test_sample_id']; base=str(br['prediction']); pred=base; rr=raw_by.get(sid)
        if rr and rr['changed'] and int(rr['prediction'])==int(base)+1:
            pred=rr['prediction']; ch2+=1
        out2.append({'test_sample_id':sid,'prediction':pred})
    out_zip2=ROOT/'submissions/final_submit_20260520_task2_noun_highconf_up1_on_8160.zip'; write_zip(out_zip2,out2); variants.append(str(out_zip2))
    rep={'base':str(CURRENT_ZIP),'changed_all':changed,'changed_up1':ch2,'variants':variants,'sha256':{v:hashlib.sha256(Path(v).read_bytes()).hexdigest() for v in variants}}
    (OUT/'noun_full_summary.json').write_text(json.dumps(rep,ensure_ascii=False,indent=2)); print(json.dumps(rep,ensure_ascii=False,indent=2))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('mode',choices=['validate','full']); ap.add_argument('--n',type=int,default=30); args=ap.parse_args()
    if args.mode=='validate': validate([800,1200,1800,2400,3200],args.n)
    else: full()
if __name__=='__main__': main()
