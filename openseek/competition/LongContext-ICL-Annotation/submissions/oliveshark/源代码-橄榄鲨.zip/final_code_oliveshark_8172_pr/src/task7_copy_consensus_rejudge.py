#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import time
import urllib.request
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "OpenSeek/openseek/competition/LongContext-ICL-Annotation/data/openseek-7_jeopardy_answer_generation_all.json"
BASE_ZIP = ROOT / "submissions/final_submit_20260520_task6_jsonY_extra_on_8172.zip"
OUT_DIR = ROOT / "experiments/task7_anticopy_rejudge_20260520"
BASE_URL = os.environ.get("LMSTUDIO_BASE_URL", "http://localhost:1234/v1")
MODEL = os.environ.get("LMSTUDIO_MODEL", "qwen3-4b")


def strip_think(s: str) -> str:
    s = str(s or "")
    s = re.sub(r"<think>.*?</think>", "", s, flags=re.S | re.I)
    if "</think>" in s:
        s = s.split("</think>", 1)[-1]
    return s


def norm(s: str) -> str:
    s = strip_think(str(s or ""))
    m = re.search(r"(?i)(?:final answer|answer|best_answer)\s*[:：]\s*([^\n]+)", s)
    if m:
        s = m.group(1)
    else:
        lines = [x.strip() for x in s.splitlines() if x.strip()]
        s = lines[-1] if lines else s
    s = s.lower().strip().strip(".").strip('"').strip("'").strip("`")
    s = re.sub(r"^(what is|who is|what are|who are)\s+", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip()


def loose_eq(a: str, b: str) -> bool:
    return norm(a) == norm(b)


def cat_clue(inp: str) -> tuple[str, str]:
    mc = re.search(r"Category:\s*(.*?)\s+Clue:", inp, re.S | re.I)
    ml = re.search(r"Clue:\s*(.*)$", inp, re.S | re.I)
    return (mc.group(1).strip() if mc else "", ml.group(1).strip() if ml else inp)


def candidate_in_input(pred: str, inp: str) -> bool:
    p = norm(pred)
    if not p or len(p) < 3:
        return False
    # Direct phrase copy. This catches the high-risk "Upper Peru -> peru" pattern.
    t = inp.lower()
    return re.search(r"(?<![a-z0-9])" + re.escape(p) + r"(?![a-z0-9])", t) is not None


def suspicious_copy(pred: str, inp: str) -> bool:
    p = norm(pred)
    if not candidate_in_input(p, inp):
        return False
    cat, clue = cat_clue(inp)
    s = (cat + " " + clue).lower()
    # These clues are usually asking for something related to the copied term, not the copied term itself.
    cue_patterns = [
        r"\bthis\b",
        r"\bthese\b",
        r"\bone of these\b",
        r"\bcalled\b",
        r"\bknown as\b",
        r"\bnicknamed\b",
        r"\bliterally\b",
        r"\bpart of\b",
        r"\bbelongs? to\b",
        r"\bfrom\b",
        r"\bfor this\b",
        r"\bon this\b",
        r"\bat this\b",
        r"\bin this\b",
    ]
    if any(re.search(x, s) for x in cue_patterns):
        return True
    # Long copied phrases are often explanatory text rather than canonical answers.
    return len(p.split()) >= 3


def call_llm(prompt: str, max_tokens: int = 96, temperature: float = 0.0) -> str:
    payload = {
        "model": MODEL,
        "messages": [
            {
                "role": "system",
                "content": "/no_think\nYou answer Jeopardy-style clues. Return only the final lowercase answer.",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
        "chat_template_kwargs": {"enable_thinking": False},
    }
    req = urllib.request.Request(
        BASE_URL.rstrip() + "/chat/completions",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=180) as r:
        return json.loads(r.read().decode())["choices"][0]["message"]["content"]


def rejudge_prompt(inp: str, current: str) -> str:
    return f"""You are solving a Jeopardy answer-generation task.

The current candidate answer is copied from the category or clue:
current_candidate: {norm(current)}

This is suspicious: in Jeopardy, the clue often mentions a related word/name and asks for a different target. Re-solve the clue from scratch.

Rules:
- If the copied candidate is truly the requested answer, keep it.
- If the clue says "this/these/one of these", identify what those words refer to.
- Do not explain.
- Return one concise lowercase answer only.

Input:
{inp}

Final answer:"""


def load_validation_rows() -> list[dict]:
    rows: list[dict] = []
    p = ROOT / "experiments/task7_zero_vs_icl_probe_20260520.json"
    if p.exists():
        obj = json.loads(p.read_text())
        for r in obj.get("rows", []):
            rows.append(
                {
                    "source": "zero_vs_icl.zero_typed",
                    "idx": r["idx"],
                    "id": r["id"],
                    "input": r["input"],
                    "gold": r["gold"],
                    "base": r["preds"].get("zero_typed", ""),
                }
            )
            rows.append(
                {
                    "source": "zero_vs_icl.icl_type_bm25",
                    "idx": r["idx"],
                    "id": r["id"],
                    "input": r["input"],
                    "gold": r["gold"],
                    "base": r["preds"].get("icl_type_bm25", ""),
                }
            )
    for p in sorted((ROOT / "experiments/task7_shadow_big_branch_20260520").glob("start*_n20.json")):
        obj = json.loads(p.read_text())
        for r in obj.get("rows", []):
            rows.append(
                {
                    "source": p.name + ".judge_pool",
                    "idx": r["idx"],
                    "id": r["id"],
                    "input": r["input"],
                    "gold": r["gold"],
                    "base": r["candidates"].get("judge_pool", ""),
                }
            )
    return rows


def validate(limit: int = 80) -> dict:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    pool = [r for r in load_validation_rows() if suspicious_copy(r["base"], r["input"])]
    # De-duplicate by sample/source/base to avoid overweighting repeated old probes.
    seen = set()
    uniq = []
    for r in pool:
        key = (r["id"], norm(r["base"]))
        if key in seen:
            continue
        seen.add(key)
        uniq.append(r)
    rows = []
    for i, r in enumerate(uniq[:limit], 1):
        raw = call_llm(rejudge_prompt(r["input"], r["base"]))
        new = norm(raw)
        base = norm(r["base"])
        gold = norm(r["gold"])
        rec = dict(r)
        rec.update(
            {
                "base_norm": base,
                "rejudge_raw": raw,
                "rejudge_norm": new,
                "base_ok": base == gold,
                "rejudge_ok": new == gold,
                "changed": new != base,
            }
        )
        rows.append(rec)
        print(
            f"[VAL {i}/{min(limit, len(uniq))}] {base}->{new} gold={gold} "
            f"base_ok={rec['base_ok']} new_ok={rec['rejudge_ok']}",
            flush=True,
        )
        time.sleep(0.02)
    summary = {
        "n_trigger": len(uniq),
        "n_eval": len(rows),
        "base_acc": sum(r["base_ok"] for r in rows) / len(rows) if rows else None,
        "rejudge_acc": sum(r["rejudge_ok"] for r in rows) / len(rows) if rows else None,
        "changed": sum(r["changed"] for r in rows),
        "good_changes": sum((not r["base_ok"]) and r["rejudge_ok"] for r in rows),
        "bad_changes": sum(r["base_ok"] and (not r["rejudge_ok"]) for r in rows),
    }
    out = {"summary": summary, "rows": rows}
    (OUT_DIR / "validation_anticopy.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return out


def generate_test_package(max_changes: int = 999, require_change: bool = True) -> dict:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    data = json.loads(DATA.read_text())
    tests = {r["id"]: r for r in data["test_samples"]}
    with zipfile.ZipFile(BASE_ZIP) as zin:
        files = {n: zin.read(n).decode() for n in zin.namelist()}
    task7 = [json.loads(x) for x in files["openseek-7-v1.jsonl"].splitlines() if x.strip()]
    changes = []
    for i, r in enumerate(task7):
        inp = tests[r["test_sample_id"]]["input"]
        base = norm(r["prediction"])
        if not suspicious_copy(base, inp):
            continue
        raw = call_llm(rejudge_prompt(inp, base))
        new = norm(raw)
        if require_change and new == base:
            continue
        changes.append(
            {
                "row_index": i,
                "test_sample_id": r["test_sample_id"],
                "input": inp,
                "base": base,
                "rejudge_raw": raw,
                "new": new,
            }
        )
        print(f"[TEST {len(changes)}] idx={i} {base} -> {new}", flush=True)
        if len(changes) >= max_changes:
            break
        time.sleep(0.02)
    for c in changes:
        task7[c["row_index"]]["prediction"] = c["new"]
    out_name = "final_submit_20260520_task7_anticopy_on_task6jsonY_8172.zip"
    out_zip = ROOT / "submissions" / out_name
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for n in sorted(files):
            if n == "openseek-7-v1.jsonl":
                text = "\n".join(json.dumps(x, ensure_ascii=False) for x in task7) + "\n"
            else:
                text = files[n]
            zout.writestr(n, text)
    report = {
        "base_zip": str(BASE_ZIP.relative_to(ROOT)),
        "out_zip": str(out_zip.relative_to(ROOT)),
        "n_changes": len(changes),
        "changes": changes,
    }
    (OUT_DIR / "test_package_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2))
    print(json.dumps({"out_zip": str(out_zip), "n_changes": len(changes)}, ensure_ascii=False, indent=2))
    return report


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["validate", "package"], required=True)
    ap.add_argument("--limit", type=int, default=80)
    ap.add_argument("--max-changes", type=int, default=999)
    args = ap.parse_args()
    if args.mode == "validate":
        validate(args.limit)
    else:
        generate_test_package(args.max_changes)


if __name__ == "__main__":
    main()
