#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, math, re, sys, time
from pathlib import Path
from typing import Callable

ROOT = Path(__file__).resolve().parents[1]
def first_existing(*paths: Path) -> Path:
    for p in paths:
        if p.exists():
            return p
    return paths[0]

DATA_DIR = first_existing(
    ROOT / "OpenSeek/openseek/competition/LongContext-ICL-Annotation/data",
    ROOT / "data",
    Path("/root/all_tasks_flagscale_runner/data"),
)
OUT_DIR = ROOT / "final_reproducible/long_context_evidence"
MODEL_DIR = first_existing(
    ROOT / "modelscope_cache/Qwen/Qwen3-4B",
    Path("/root/FlagScale/Qwen3-4B"),
    Path("/root/Qwen3-4B"),
)

TASK_FILES = [
    DATA_DIR / "openseek-1_closest_integers.json",
    DATA_DIR / "openseek-2_count_nouns_verbs.json",
    DATA_DIR / "openseek-3_collatz_conjecture.json",
    DATA_DIR / "openseek-4_conala_concat_strings.json",
    DATA_DIR / "openseek-5_semeval_2018_task1_tweet_sadness_detection.json",
    DATA_DIR / "openseek-6_mnli_same_genre_classification.json",
    DATA_DIR / "openseek-7_jeopardy_answer_generation_all.json",
    DATA_DIR / "openseek-8_kernel_generation.json",
]


def simple_tokens(text: str) -> list[str]:
    return re.findall(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]", str(text).lower())


def load_token_counter(model_dir: Path) -> tuple[Callable[[str], int], str]:
    try:
        from transformers import AutoTokenizer  # type: ignore
        tok = AutoTokenizer.from_pretrained(str(model_dir), trust_remote_code=True, local_files_only=True)
        return (lambda text: len(tok.encode(text, add_special_tokens=False))), f"qwen_tokenizer:{model_dir}"
    except Exception as e:
        # Conservative-ish fallback. English/code tokenization is rough; final run should use Qwen tokenizer.
        def approx(text: str) -> int:
            ascii_words = re.findall(r"[A-Za-z0-9_]+|[^\sA-Za-z0-9_]", text)
            return max(1, int(len(ascii_words) * 1.25))
        return approx, "fallback_regex_estimator:" + type(e).__name__ + ":" + str(e)[:160]


def normalize_output(out) -> str:
    if isinstance(out, list):
        return " | ".join(str(x) for x in out)
    return str(out)


def format_example(ex: dict, idx: int) -> str:
    return (
        f"[Example {idx}]\n"
        f"id: {ex.get('id','')}\n"
        f"input:\n{ex.get('input','')}\n"
        f"output:\n{normalize_output(ex.get('output',''))}\n"
    )


def example_score(query: str, ex_input: str, task_id: str) -> float:
    q = simple_tokens(query)
    e = simple_tokens(ex_input)
    if not q or not e:
        return 0.0
    qs, es = set(q), set(e)
    overlap = len(qs & es) / max(1, len(qs | es))
    length = min(len(q), len(e)) / max(len(q), len(e), 1)
    score = overlap + 0.12 * length
    if task_id == "openseek-2":
        qn = "number of nouns" in query.lower()
        en = "number of nouns" in ex_input.lower()
        qv = "number of verbs" in query.lower()
        ev = "number of verbs" in ex_input.lower()
        if (qn and en) or (qv and ev):
            score += 0.5
    elif task_id == "openseek-7":
        for key in ["Category:", "Clue:"]:
            if key.lower() in query.lower() and key.lower() in ex_input.lower():
                score += 0.05
    elif task_id == "openseek-8":
        qw = re.search(r"Wrapper Entry Information:\s*(.*?)(?:\.\s*Args:|\n|$)", query, flags=re.S)
        ew = re.search(r"Wrapper Entry Information:\s*(.*?)(?:\.\s*Args:|\n|$)", ex_input, flags=re.S)
        if qw and ew:
            qname = qw.group(1).split("(", 1)[0].strip().lower()
            ename = ew.group(1).split("(", 1)[0].strip().lower()
            if qname and qname == ename:
                score += 1.0
            elif qname and ename and qname.split("_")[0] == ename.split("_")[0]:
                score += 0.2
    return score


def select_examples(task: dict, sample: dict, target_tokens: int, count_tokens: Callable[[str], int], reserve_tokens: int, max_examples: int) -> tuple[list[dict], dict]:
    examples = list(task.get("examples", []))
    task_id = task.get("task_id", "")
    query = sample.get("input", "")
    scored = sorted(
        ((example_score(query, ex.get("input", ""), task_id), i, ex) for i, ex in enumerate(examples)),
        key=lambda x: (-x[0], x[1]),
    )
    selected: list[dict] = []
    seen = set()

    # 1) Put a small relevant block near the top.
    for _, _, ex in scored[: min(24, len(scored))]:
        if ex.get("id") not in seen:
            selected.append(ex); seen.add(ex.get("id"))

    # 2) Add strided coverage examples so the 30K context is not just local-nearest duplicates.
    if examples:
        stride = max(1, len(examples) // 96)
        for i in range(0, len(examples), stride):
            ex = examples[i]
            if ex.get("id") not in seen:
                selected.append(ex); seen.add(ex.get("id"))
            if len(selected) >= max_examples:
                break

    # 3) Fill by next-best similarity until target budget is reached.
    for _, _, ex in scored:
        if len(selected) >= max_examples:
            break
        if ex.get("id") not in seen:
            selected.append(ex); seen.add(ex.get("id"))

    final: list[dict] = []
    token_acc = reserve_tokens
    for idx, ex in enumerate(selected, 1):
        text = format_example(ex, idx)
        tok = count_tokens(text)
        if final and token_acc + tok > target_tokens + 1200:
            break
        final.append(ex)
        token_acc += tok
        if token_acc >= target_tokens:
            break

    meta = {
        "candidate_pool": len(examples),
        "selected_count": len(final),
        "selection_policy": "top-similarity block + strided coverage fill + similarity fill",
        "reserve_tokens": reserve_tokens,
    }
    return final, meta


def build_round1_prompt(task: dict, sample: dict, selected_examples: list[dict], task_target_tokens: int) -> str:
    task_id = task.get("task_id", "")
    definition = "\n".join(task.get("Definition", []))
    example_block = "\n".join(format_example(ex, i + 1) for i, ex in enumerate(selected_examples))
    if task_id == "openseek-8":
        output_schema = '{"task_understanding":"...", "relevant_patterns":["..."], "implementation_plan":"...", "repair_checks":["..."]}'
        purpose = "Analyze the long-context examples and derive code-generation rules. Do not output final code in this round."
    else:
        output_schema = '{"task_understanding":"...", "label_rules":["..."], "relevant_example_ids":["..."], "final_answer_plan":"..."}'
        purpose = "Analyze the long-context examples and derive annotation rules. Do not output the final label in this round."
    return f"""You are Qwen3-4B participating in the LongContext ICL Annotation competition.\nThis is ROUND 1, the mandatory long-context evidence round.\nTarget context budget: about {task_target_tokens} tokens.\nOnly use the official task definition, official examples, and current input below.\n\n[Task]\ntask_id: {task_id}\ntask_name: {task.get('task_name','')}\n\n[Definition]\n{definition}\n\n[Long Context: Official ICL Examples]\n{example_block}\n\n[Current Test Input]\nid: {sample.get('id','')}\ninput:\n{sample.get('input','')}\n\n[Round 1 Instruction]\n{purpose}\nReturn strict JSON only with this shape:\n{output_schema}\n"""


def build_round2_prompt(task: dict, sample: dict, round1_placeholder: str = "<ROUND1_JSON_SUMMARY>") -> str:
    task_id = task.get("task_id", "")
    definition = "\n".join(task.get("Definition", []))
    if task_id == "openseek-8":
        final = "Output only executable code for the requested wrapper."
    else:
        final = "Output only the final label/prediction."
    return f"""You are Qwen3-4B. This is ROUND 2, the short stable-output round.\nUse the official definition, the current input, and the ROUND 1 long-context summary.\n\n[Task]\n{task_id} {task.get('task_name','')}\n\n[Definition]\n{definition}\n\n[ROUND 1 Summary]\n{round1_placeholder}\n\n[Current Test Input]\nid: {sample.get('id','')}\ninput:\n{sample.get('input','')}\n\n[Final Output Instruction]\n{final}\n"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sample-limit", type=int, default=3, help="samples per task; ignored with --all")
    ap.add_argument("--all", action="store_true", help="build evidence metadata for every test sample")
    ap.add_argument("--target-tokens-text", type=int, default=30000)
    ap.add_argument("--target-tokens-task8", type=int, default=16000)
    ap.add_argument("--max-examples-text", type=int, default=640)
    ap.add_argument("--max-examples-task8", type=int, default=184)
    ap.add_argument("--write-prompts", action="store_true", help="write full round1/round2 prompts to disk")
    ap.add_argument("--out-dir", default=str(OUT_DIR))
    ap.add_argument("--data-dir", default=str(DATA_DIR))
    ap.add_argument("--model-dir", default=str(MODEL_DIR))
    args = ap.parse_args()

    data_dir = Path(args.data_dir)
    model_dir = Path(args.model_dir)
    task_files = [data_dir / p.name for p in TASK_FILES]
    out_dir = Path(args.out_dir)
    prompt_dir = out_dir / "prompts"
    out_dir.mkdir(parents=True, exist_ok=True)
    if args.write_prompts:
        prompt_dir.mkdir(parents=True, exist_ok=True)

    count_tokens, tokenizer_info = load_token_counter(model_dir)
    evidence_path = out_dir / "long_context_evidence.jsonl"
    summary_path = out_dir / "long_context_evidence_summary.json"
    md_path = out_dir / "long_context_evidence_preview.md"

    records = []
    with evidence_path.open("w", encoding="utf-8") as f:
        for task_file in task_files:
            task = json.loads(task_file.read_text(encoding="utf-8"))
            task_id = task["task_id"]
            target = args.target_tokens_task8 if task_id == "openseek-8" else args.target_tokens_text
            max_examples = args.max_examples_task8 if task_id == "openseek-8" else args.max_examples_text
            samples = task.get("test_samples", []) if args.all else task.get("test_samples", [])[: args.sample_limit]
            for sample in samples:
                skeleton = build_round1_prompt(task, sample, [], target)
                reserve = count_tokens(skeleton) + 256
                selected, sel_meta = select_examples(task, sample, target, count_tokens, reserve, max_examples)
                round1 = build_round1_prompt(task, sample, selected, target)
                r1_tokens = count_tokens(round1)
                # Hard compliance top-up: token estimates inside selection can be slightly off
                # because final prompt adds headers and ordering. Keep adding official examples
                # until the actual Qwen tokenizer count reaches the target budget.
                if r1_tokens < target:
                    selected_ids = {ex.get("id") for ex in selected}
                    query = sample.get("input", "")
                    extras = sorted(
                        ((example_score(query, ex.get("input", ""), task_id), i, ex) for i, ex in enumerate(task.get("examples", [])) if ex.get("id") not in selected_ids),
                        key=lambda x: (-x[0], x[1]),
                    )
                    topup_added = 0
                    for _, _, ex in extras:
                        if len(selected) >= max_examples:
                            break
                        selected.append(ex)
                        topup_added += 1
                        round1 = build_round1_prompt(task, sample, selected, target)
                        r1_tokens = count_tokens(round1)
                        if r1_tokens >= target + 128:
                            break
                    sel_meta["topup_added"] = topup_added
                else:
                    sel_meta["topup_added"] = 0
                round2 = build_round2_prompt(task, sample)
                r2_tokens = count_tokens(round2)
                r1_hash = hashlib.sha256(round1.encode("utf-8")).hexdigest()
                r2_hash = hashlib.sha256(round2.encode("utf-8")).hexdigest()
                prompt_paths = {}
                if args.write_prompts:
                    safe = sample["id"]
                    r1p = prompt_dir / f"{task_id}_{safe}_round1.txt"
                    r2p = prompt_dir / f"{task_id}_{safe}_round2.txt"
                    r1p.write_text(round1, encoding="utf-8")
                    r2p.write_text(round2, encoding="utf-8")
                    prompt_paths = {"round1_prompt_path": str(r1p.relative_to(ROOT)), "round2_prompt_path": str(r2p.relative_to(ROOT))}
                rec = {
                    "task_id": task_id,
                    "task_name": task.get("task_name", ""),
                    "test_sample_id": sample.get("id", ""),
                    "target_tokens": target,
                    "round1_tokens": r1_tokens,
                    "round2_tokens": r2_tokens,
                    "round1_prompt_sha256": r1_hash,
                    "round2_prompt_sha256": r2_hash,
                    "tokenizer_info": tokenizer_info,
                    "selected_example_count": len(selected),
                    "selected_example_ids": [ex.get("id", "") for ex in selected],
                    "selected_example_ids_sha256": hashlib.sha256("\n".join(ex.get("id", "") for ex in selected).encode("utf-8")).hexdigest(),
                    "definition_sha256": hashlib.sha256("\n".join(task.get("Definition", [])).encode("utf-8")).hexdigest(),
                    "input_sha256": hashlib.sha256(str(sample.get("input", "")).encode("utf-8")).hexdigest(),
                    "build_strategy": sel_meta,
                    "long_context_requirement_status": "pass" if r1_tokens >= target else "below_target",
                    "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    **prompt_paths,
                }
                f.write(json.dumps(rec, ensure_ascii=False) + "\n")
                records.append(rec)
                print(f"{task_id} {sample.get('id')} round1_tokens={r1_tokens} examples={len(selected)} status={rec['long_context_requirement_status']}", flush=True)

    by_task = {}
    for r in records:
        s = by_task.setdefault(r["task_id"], {"count": 0, "min_round1_tokens": math.inf, "max_round1_tokens": 0, "below_target": 0, "example_counts": []})
        s["count"] += 1
        s["min_round1_tokens"] = min(s["min_round1_tokens"], r["round1_tokens"])
        s["max_round1_tokens"] = max(s["max_round1_tokens"], r["round1_tokens"])
        s["below_target"] += int(r["long_context_requirement_status"] != "pass")
        s["example_counts"].append(r["selected_example_count"])
    for s in by_task.values():
        s["avg_selected_examples"] = round(sum(s["example_counts"]) / max(1, len(s["example_counts"])), 2)
        del s["example_counts"]
    summary = {
        "mode": "all" if args.all else f"sample_limit={args.sample_limit}",
        "tokenizer_info": tokenizer_info,
        "target_tokens_text": args.target_tokens_text,
        "target_tokens_task8": args.target_tokens_task8,
        "write_prompts": args.write_prompts,
        "record_count": len(records),
        "by_task": by_task,
        "evidence_jsonl": str(evidence_path.relative_to(ROOT)),
    }
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    lines = ["# 30K 长上下文证据链预览", "", f"- tokenizer: `{tokenizer_info}`", f"- records: `{len(records)}`", f"- evidence: `{evidence_path.relative_to(ROOT)}`", "", "| task | count | min round1 tokens | max round1 tokens | below target | avg examples |", "|---|---:|---:|---:|---:|---:|"]
    for task_id, s in sorted(by_task.items()):
        lines.append(f"| {task_id} | {s['count']} | {s['min_round1_tokens']} | {s['max_round1_tokens']} | {s['below_target']} | {s['avg_selected_examples']} |")
    lines.append("\n## 样例记录\n")
    for r in records[: min(12, len(records))]:
        lines.append(f"- `{r['task_id']}` `{r['test_sample_id']}`: round1={r['round1_tokens']} tokens, examples={r['selected_example_count']}, hash=`{r['round1_prompt_sha256'][:16]}...`")
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
