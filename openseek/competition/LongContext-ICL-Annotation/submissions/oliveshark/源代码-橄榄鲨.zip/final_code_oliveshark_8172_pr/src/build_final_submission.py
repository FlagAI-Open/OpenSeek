#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path

EXPECTED = {**{f"openseek-{i}-v1.jsonl": 500 for i in range(1, 8)}, "openseek-8-v1.jsonl": 166}


def read_rows(text: str) -> list[dict]:
    return [json.loads(x) for x in text.splitlines() if x.strip()]


def validate(zip_path: Path) -> dict:
    bad = []
    summary = {}
    with zipfile.ZipFile(zip_path) as zf:
        names = sorted(n for n in zf.namelist() if n.endswith(".jsonl"))
        if names != sorted(EXPECTED):
            bad.append({"kind": "names", "actual": names, "expected": sorted(EXPECTED)})
        for name, expected in EXPECTED.items():
            rows = read_rows(zf.read(name).decode("utf-8"))
            summary[name] = {"rows": len(rows), "empty": sum(1 for r in rows if not str(r.get("prediction", "")).strip())}
            if len(rows) != expected:
                bad.append({"file": name, "kind": "row_count", "actual": len(rows), "expected": expected})
            for i, row in enumerate(rows, 1):
                if set(row) != {"test_sample_id", "prediction"}:
                    bad.append({"file": name, "line": i, "kind": "keys", "keys": sorted(row)})
    return {"ok": not bad, "bad_count": len(bad), "bad_preview": bad[:20], "summary": summary}


def main() -> None:
    ap = argparse.ArgumentParser(description="Build the final leaderboard-matched submission zip.")
    ap.add_argument("--base-zip", default="artifacts/base_task2_noun_highconf_8172.zip")
    ap.add_argument("--enable-optional-task7-plus2", action="store_true", help="Enable the unsubmitted Task7 copy-consensus plus2_v3 experimental branch. Disabled by default so the rebuilt zip matches the official 81.72 leaderboard package.")
    ap.add_argument("--task7-decisions", default="experiments_optional/task7_copy_consensus_plus2_v3/task7_copy_consensus_plus2_v3_decisions.json")
    ap.add_argument("--out-zip", default="outputs/final_submit_rebuilt.zip")
    ap.add_argument("--manifest", default="outputs/final_submit_rebuilt_manifest.json")
    args = ap.parse_args()

    root = Path(__file__).resolve().parents[1]
    base_zip = (root / args.base_zip).resolve()
    decisions_path = (root / args.task7_decisions).resolve()
    out_zip = (root / args.out_zip).resolve()
    manifest_path = (root / args.manifest).resolve()
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    manifest_path.parent.mkdir(parents=True, exist_ok=True)

    decisions = {}
    if args.enable_optional_task7_plus2:
        decisions_obj = json.loads(decisions_path.read_text(encoding="utf-8"))
        decisions = {d["test_sample_id"]: d for d in decisions_obj.get("decisions", [])}
    changes = []

    with zipfile.ZipFile(base_zip) as zin, zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zout:
        for name in sorted(zin.namelist()):
            raw = zin.read(name).decode("utf-8")
            if args.enable_optional_task7_plus2 and name == "openseek-7-v1.jsonl":
                rows = []
                for row in read_rows(raw):
                    sid = row["test_sample_id"]
                    decision = decisions.get(sid)
                    if decision:
                        old = str(row.get("prediction", "")).strip()
                        new = str(decision["selected_prediction"]).strip()
                        row = {"test_sample_id": sid, "prediction": new}
                        if old != new:
                            changes.append({"test_sample_id": sid, "from": old, "to": new, "reason": decision.get("selected_reason", "")})
                    rows.append(row)
                zout.writestr(name, "\n".join(json.dumps(r, ensure_ascii=False) for r in rows) + "\n")
            else:
                zout.writestr(name, raw)

    val = validate(out_zip)
    manifest = {
        "base_zip": str(base_zip.relative_to(root)),
        "official_leaderboard_score": 81.72,
        "default_matches_official_leaderboard_package": not args.enable_optional_task7_plus2,
        "optional_task7_plus2_enabled": args.enable_optional_task7_plus2,
        "task7_decisions": str(decisions_path.relative_to(root)) if args.enable_optional_task7_plus2 else None,
        "out_zip": str(out_zip.relative_to(root)),
        "sha256": hashlib.sha256(out_zip.read_bytes()).hexdigest(),
        "task7_changed_count": len(changes),
        "task7_changes": changes,
        "validation": val,
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"out_zip": str(out_zip), "sha256": manifest["sha256"], "task7_changed_count": len(changes), "validation_ok": val["ok"], "manifest": str(manifest_path)}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
