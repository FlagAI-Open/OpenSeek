More Resources
==============

Last updated: 06/30/2025.

- Introduction to verl (`Slides <https://tongyx361.github.io/blogs/posts/verl-intro>`_)
- verl Code Walkthrough (`Slides <https://tongyx361.github.io/blogs/posts/verl-tutorial>`_, `Talk in Chinese <https://hcqnc.xetlk.com/sl/3vACOK>`_) 
